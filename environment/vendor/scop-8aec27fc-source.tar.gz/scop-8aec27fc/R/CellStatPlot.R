#' @title Statistical plot of cells
#'
#' @md
#' @inheritParams FeatureStatPlot
#' @inheritParams scop-params
#' @param force Draw even when a grouping has more than 100 levels.
#' @param NA_color The color to use for missing values.
#' @param NA_stat Whether to include missing values in the plot.
#' @param stat_level The level(s) of the variable(s) specified in `stat.by` to include in the plot.
#' @param stat_type The type of statistic to compute for the plot.
#' Can be one of `"percent"` or `"count"`.
#' @param plot_type The type of plot to create.
#' Can be one of `"bar"`, `"rose"`, `"ring"`, `"pie"`, `"trend"`,
#' `"trend_alluvial"`, `"area"`, `"dot"`, `"sankey"`, `"chord"`,
#' `"venn"`, or `"upset"`.
#' @param x_text_angle Rotation angle for x-axis labels.
#' @param position The position adjustment for the plot.
#' Can be one of `"stack"` or `"dodge"`.
#' @param label Whether to add labels on the plot.
#' @param label.size The size of the labels.
#' @param label.fg The foreground color of the labels.
#' @param label.bg The background color of the labels.
#' @param label.bg.r The radius of the rounded corners of the label background.
#' @param grid_major Whether to show major panel grid lines.
#' @param grid_major_colour Color of major panel grid lines.
#' @param grid_major_linetype Linetype of major panel grid lines.
#' @param grid_major_linewidth Line width of major panel grid lines.
#'
#' @seealso [FeatureStatPlot]
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' p1 <- CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "SubCellType",
#'   label = TRUE
#' )
#' p1
#'
#' thisplot::panel_fix(
#'   p1,
#'   height = 2, width = 3
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "SubCellType",
#'   stat_type = "count",
#'   position = "dodge",
#'   label = TRUE
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "SubCellType",
#'   bg.by = "CellType",
#'   palette = "Set1",
#'   stat_type = "count",
#'   position = "dodge"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   plot_type = "bar"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   plot_type = "rose"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   plot_type = "ring"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   plot_type = "pie"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   plot_type = "dot"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "bar"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "rose"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "ring"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "area"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "dot"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "trend"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "trend_alluvial"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   plot_type = "bar",
#'   individual = TRUE
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "bar"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "rose"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "ring"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "area"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "dot"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "trend"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "bar",
#'   position = "dodge",
#'   label = TRUE
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "rose",
#'   position = "dodge",
#'   label = TRUE
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = "Phase",
#'   group.by = "CellType",
#'   stat_type = "count",
#'   plot_type = "ring",
#'   position = "dodge",
#'   label = TRUE
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = c("CellType", "Phase"),
#'   plot_type = "sankey"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = c("CellType", "Phase"),
#'   plot_type = "chord"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = c("CellType", "Phase"),
#'   plot_type = "venn",
#'   stat_level = list(
#'     CellType = c("Ductal", "Ngn3-low-EP"),
#'     Phase = "S"
#'   )
#' )
#'
#' pancreas_sub$Progenitor <- pancreas_sub$CellType %in% c("Ngn3-low-EP", "Ngn3-high-EP")
#' pancreas_sub$G2M <- pancreas_sub$Phase == "G2M"
#' pancreas_sub$Fancb_Expressed <- GetAssayData5(
#'   pancreas_sub,
#'   assay = "RNA",
#'   layer = "counts"
#' )["Fancb", ] > 0
#' pancreas_sub$Dlg3_Expressed <- GetAssayData5(
#'   pancreas_sub,
#'   assay = "RNA",
#'   layer = "counts"
#' )["Dlg3", ] > 0
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = c(
#'     "Progenitor", "G2M", "Fancb_Expressed", "Dlg3_Expressed"
#'   ),
#'   plot_type = "venn",
#'   stat_level = "TRUE"
#' )
#'
#' CellStatPlot(
#'   pancreas_sub,
#'   stat.by = c(
#'     "Progenitor", "G2M", "Fancb_Expressed", "Dlg3_Expressed"
#'   ),
#'   plot_type = "upset",
#'   stat_level = "TRUE"
#' )
#'
#' sum(
#'   pancreas_sub$Progenitor == "FALSE" &
#'     pancreas_sub$G2M == "FALSE" &
#'     pancreas_sub$Fancb_Expressed == "TRUE" &
#'     pancreas_sub$Dlg3_Expressed == "FALSE"
#' )
CellStatPlot <- function(
  object,
  stat.by,
  group.by = NULL,
  split.by = NULL,
  bg.by = NULL,
  cells = NULL,
  flip = FALSE,
  NA_color = "grey",
  NA_stat = TRUE,
  keep_empty = FALSE,
  individual = FALSE,
  stat_level = NULL,
  plot_type = c("bar", "rose", "ring", "pie", "trend", "trend_alluvial", "area", "dot", "sankey", "chord", "venn", "upset"),
  stat_type = c("percent", "count"),
  position = c("stack", "dodge"),
  palette = "Chinese",
  palcolor = NULL,
  alpha = 1,
  bg_palette = "Chinese",
  bg_palcolor = NULL,
  bg_alpha = 0.2,
  label = FALSE,
  label.size = 3.5,
  label.fg = "black",
  label.bg = "white",
  label.bg.r = 0.1,
  aspect.ratio = NULL,
  title = NULL,
  subtitle = NULL,
  xlab = NULL,
  ylab = NULL,
  legend.position = "right",
  legend.direction = "vertical",
  theme_use = "theme_scop",
  theme_args = list(),
  x_text_angle = 45,
  grid_major = TRUE,
  grid_major_colour = "grey80",
  grid_major_linetype = 2,
  grid_major_linewidth = 0.3,
  combine = TRUE,
  nrow = NULL,
  ncol = NULL,
  byrow = TRUE,
  force = FALSE,
  seed = 11,
  ...,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  cells <- cells %||% colnames(srt@assays[[1]])
  meta_data <- srt@meta.data[cells, , drop = FALSE]
  plot_type <- match.arg(plot_type)
  stat_type <- match.arg(stat_type)
  position <- match.arg(position)
  theme_use <- resolve_plot_theme_use(theme_use)
  if (identical(plot_type, "chord") && length(stat.by) != 2L) {
    cli::cli_abort("{.arg stat.by} must contain exactly two metadata columns when {.arg plot_type = 'chord'}")
  }
  check_r("geomtextpath", verbose = FALSE)

  if (identical(plot_type, "trend_alluvial")) {
    check_r("ggalluvial", verbose = FALSE)
  }
  if (identical(plot_type, "venn")) {
    check_r("ggVennDiagram", verbose = FALSE)
  }
  if (identical(plot_type, "upset")) {
    check_r("ggupset", verbose = FALSE)
  }
  plot <- StatPlot(
    meta_data,
    stat.by = stat.by,
    group.by = group.by,
    split.by = split.by,
    bg.by = bg.by,
    flip = flip,
    NA_color = NA_color,
    NA_stat = NA_stat,
    keep_empty = keep_empty,
    individual = individual,
    stat_level = stat_level,
    plot_type = plot_type,
    stat_type = stat_type,
    position = position,
    palette = palette,
    palcolor = palcolor,
    alpha = alpha,
    bg_palette = bg_palette,
    bg_palcolor = bg_palcolor,
    bg_alpha = bg_alpha,
    label = label,
    label.size = label.size,
    label.fg = label.fg,
    label.bg = label.bg,
    label.bg.r = label.bg.r,
    aspect.ratio = aspect.ratio,
    title = title,
    subtitle = subtitle,
    xlab = xlab,
    ylab = ylab,
    legend.position = legend.position,
    legend.direction = legend.direction,
    theme_use = theme_use,
    theme_args = theme_args,
    x_text_angle = x_text_angle,
    grid_major = grid_major,
    grid_major_colour = grid_major_colour,
    grid_major_linetype = grid_major_linetype,
    grid_major_linewidth = grid_major_linewidth,
    combine = combine,
    nrow = nrow,
    ncol = ncol,
    byrow = byrow,
    force = force,
    seed = seed,
    ...
  )

  return(plot)
}
