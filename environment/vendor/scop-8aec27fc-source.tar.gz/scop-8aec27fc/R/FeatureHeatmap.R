#' @title Feature Heatmap
#'
#' @md
#' @inheritParams GroupHeatmap
#' @param max_cells An integer, maximum number of cells to sample per group.
#' @param cell_order A vector of cell names defining the order of cells.
#'
#' @seealso [RunDEtest]
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' pancreas_sub <- RunDEtest(
#'   pancreas_sub,
#'   group.by = "CellType"
#' )
#' de_filter <- dplyr::filter(
#'   pancreas_sub@tools$DEtest_CellType$AllMarkers_wilcox,
#'   p_val_adj < 0.05 & avg_log2FC > 1
#' )
#' ht1 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   group.by = "CellType",
#'   split.by = "Phase",
#'   cell_split_palette = "Dark2"
#' )
#' ht1$plot
#'
#' thisplot::panel_fix(
#'   ht1$plot,
#'   height = 4,
#'   width = 6,
#'   raster = TRUE,
#'   dpi = 50
#' )
#'
#' ht2 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   group.by = c("CellType", "SubCellType"),
#'   n_split = 4,
#'   cluster_rows = TRUE,
#'   cluster_row_slices = TRUE,
#'   cluster_columns = TRUE,
#'   cluster_column_slices = TRUE,
#'   ht_params = list(row_gap = grid::unit(0, "mm")),
#'   use_raster = FALSE
#' )
#' ht2$plot
#'
#' ht3 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   feature_split = de_filter$group1,
#'   group.by = "CellType",
#'   species = "Mus_musculus",
#'   db = "GO_BP",
#'   anno_terms = TRUE,
#'   anno_keys = TRUE,
#'   anno_features = TRUE
#' )
#' ht3$plot
#'
#' pancreas_sub <- RunSlingshot(
#'   pancreas_sub,
#'   group.by = "SubCellType",
#'   reduction = "UMAP"
#' )
#' ht4 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   nlabel = 10,
#'   cell_order = names(sort(pancreas_sub$Lineage1)),
#'   cell_annotation = c("SubCellType", "Lineage1"),
#'   cell_annotation_palette = c("Chinese", "cividis")
#' )
#' ht4$plot
#'
#' pancreas_sub <- AnnotateFeatures(
#'   pancreas_sub,
#'   species = "Mus_musculus",
#'   db = c("CSPA", "TF")
#' )
#'
#' ht5 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   n_split = 4,
#'   group.by = "CellType",
#'   heatmap_palette = "viridis",
#'   feature_annotation = c("TF", "CSPA"),
#'   feature_annotation_palcolor = list(
#'     c("gold", "steelblue"), c("forestgreen")
#'   ),
#'   cell_annotation = c("Phase", "G2M_score"),
#'   cell_annotation_palette = c("Dark2", "Purples")
#' )
#' ht5$plot
#'
#' ht6 <- FeatureHeatmap(
#'   pancreas_sub,
#'   features = de_filter$gene,
#'   n_split = 4,
#'   group.by = "CellType",
#'   heatmap_palette = "viridis",
#'   feature_annotation = c("TF", "CSPA"),
#'   feature_annotation_palcolor = list(
#'     c("gold", "steelblue"), c("forestgreen")
#'   ),
#'   cell_annotation = c("Phase", "G2M_score"),
#'   cell_annotation_palette = c("Dark2", "Purples"),
#'   flip = TRUE,
#'   column_title_rot = 45
#' )
#' ht6$plot
FeatureHeatmap <- function(
  object,
  features = NULL,
  cells = NULL,
  group.by = NULL,
  split.by = NULL,
  within_groups = FALSE,
  max_cells = 100,
  cell_order = NULL,
  border = TRUE,
  heatmap_border = NULL,
  cell_annotation_border = NULL,
  feature_annotation_border = NULL,
  heatmap_border_palcolor = "black",
  cell_annotation_border_palcolor = "black",
  feature_annotation_border_palcolor = "black",
  heatmap_border_size = 1,
  cell_annotation_border_size = 1,
  feature_annotation_border_size = 1,
  flip = FALSE,
  layer = "counts",
  assay = NULL,
  exp_method = c("zscore", "raw", "fc", "log2fc", "log1p"),
  exp_legend_title = NULL,
  limits = NULL,
  lib_normalize = identical(layer, "counts"),
  libsize = NULL,
  feature_split = NULL,
  feature_split_by = NULL,
  n_split = NULL,
  split_order = NULL,
  split_method = c("kmeans", "hclust", "mfuzz"),
  decreasing = FALSE,
  fuzzification = NULL,
  cluster_features_by = NULL,
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  cluster_row_slices = FALSE,
  cluster_column_slices = FALSE,
  show_row_names = FALSE,
  row_names_wrap = NULL,
  show_column_names = FALSE,
  row_names_side = ifelse(flip, "left", "right"),
  column_names_side = ifelse(flip, "bottom", "top"),
  row_names_rot = 0,
  column_names_rot = 90,
  row_title = NULL,
  column_title = NULL,
  row_title_side = "left",
  column_title_side = "top",
  row_title_rot = 0,
  column_title_rot = ifelse(flip, 90, 0),
  anno_terms = FALSE,
  anno_keys = FALSE,
  anno_features = FALSE,
  terms_width = grid::unit(4, "in"),
  terms_stat_width = grid::unit(1.35, "in"),
  terms_fontsize = 8,
  terms_stat = "none",
  terms_stat_digits = 2,
  terms_stat_label = "value",
  terms_stat_axis = FALSE,
  terms_stat_background_palcolor = NULL,
  terms_stat_border = NULL,
  terms_stat_border_palcolor = NULL,
  terms_stat_border_size = NULL,
  terms_stat_label_palcolor = NULL,
  terms_group_background = FALSE,
  terms_background_palcolor = "grey98",
  terms_background_alpha = 1,
  terms_border = TRUE,
  terms_border_palcolor = "black",
  terms_border_size = 0.8,
  terms_text_palcolor = NULL,
  terms_bar_palcolor = NULL,
  keys_width = grid::unit(2, "in"),
  keys_fontsize = c(6, 10),
  features_width = grid::unit(2, "in"),
  features_fontsize = c(6, 10),
  IDtype = "symbol",
  species = "Homo_sapiens",
  db_update = FALSE,
  db_version = "latest",
  db_combine = FALSE,
  convert_species = FALSE,
  Ensembl_version = NULL,
  mirror = NULL,
  db = "GO_BP",
  TERM2GENE = NULL,
  TERM2NAME = NULL,
  minGSSize = 10,
  maxGSSize = 500,
  GO_simplify = FALSE,
  GO_simplify_cutoff = "p.adjust < 0.05",
  simplify_method = "Wang",
  simplify_similarityCutoff = 0.7,
  pvalueCutoff = NULL,
  padjustCutoff = 0.05,
  topTerm = 5,
  show_termid = FALSE,
  topWord = 20,
  words_excluded = NULL,
  nlabel = 20,
  features_label = NULL,
  label_size = 10,
  label_color = "black",
  heatmap_palette = "RdBu",
  heatmap_palcolor = NULL,
  group_palette = "Chinese",
  group_palcolor = NULL,
  cell_split_palette = "simspec",
  cell_split_palcolor = NULL,
  feature_split_palette = "simspec",
  feature_split_palcolor = NULL,
  cell_annotation = NULL,
  cell_annotation_palette = "Chinese",
  cell_annotation_palcolor = NULL,
  cell_annotation_params = if (flip) {
    list(width = grid::unit(5, "mm"))
  } else {
    list(height = grid::unit(5, "mm"))
  },
  feature_annotation = NULL,
  feature_annotation_palette = "Dark2",
  feature_annotation_palcolor = NULL,
  feature_annotation_params = if (flip) {
    list(height = grid::unit(5, "mm"))
  } else {
    list(width = grid::unit(5, "mm"))
  },
  use_raster = NULL,
  raster_device = "png",
  raster_by_magick = FALSE,
  height = NULL,
  width = NULL,
  units = "inch",
  seed = 11,
  legend.position = "right",
  ht_params = list(),
  verbose = TRUE,
  ...,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  set.seed(seed)
  heatmap_border <- heatmap_border %||% border
  cell_annotation_border <- cell_annotation_border %||% border
  feature_annotation_border <- feature_annotation_border %||% border
  heatmap_border_color <- heatmap_border_color(
    heatmap_border,
    heatmap_border_palcolor
  )
  cell_annotation_border_color <- heatmap_border_color(
    cell_annotation_border,
    cell_annotation_border_palcolor
  )
  feature_annotation_border_color <- heatmap_border_color(
    feature_annotation_border,
    feature_annotation_border_palcolor
  )
  heatmap_border_size <- heatmap_border_size_value(heatmap_border_size)
  cell_annotation_border_size <- heatmap_border_size_value(cell_annotation_border_size)
  feature_annotation_border_size <- heatmap_border_size_value(feature_annotation_border_size)
  heatmap_border <- heatmap_border_enabled(heatmap_border)
  cell_annotation_border <- heatmap_border_enabled(cell_annotation_border)
  feature_annotation_border <- heatmap_border_enabled(feature_annotation_border)
  if (isTRUE(raster_by_magick)) {
    check_r("magick", verbose = FALSE)
  }

  split_method <- match.arg(split_method)
  data_nm <- c(ifelse(isTRUE(lib_normalize), "normalized", ""), layer)
  data_nm <- paste(data_nm[data_nm != ""], collapse = " ")
  if (length(exp_method) == 1 && is.function(exp_method)) {
    exp_name <- paste0(
      as.character(x = formals()$exp_method),
      "(",
      data_nm,
      ")"
    )
  } else {
    exp_method <- match.arg(exp_method)
    exp_name <- paste0(exp_method, "(", data_nm, ")")
  }
  exp_name <- exp_legend_title %||% exp_name

  assay <- assay %||% DefaultAssay(srt)
  if (length(feature_split) != 0 && length(feature_split) != length(features)) {
    log_message(
      "feature_split must be the same length as features",
      message_type = "error"
    )
  }
  if (is.null(group.by)) {
    srt@meta.data[["All.groups"]] <- factor("")
    group.by <- "All.groups"
  }
  if (any(!group.by %in% colnames(srt@meta.data))) {
    log_message(
      group.by[!group.by %in% colnames(srt@meta.data)],
      " is not in the meta data of {.cls Seurat}.",
      message_type = "error"
    )
  }
  if (!is.null(group.by)) {
    for (g in group.by) {
      if (!is.factor(srt@meta.data[[g]])) {
        srt@meta.data[[g]] <- factor(
          srt@meta.data[[g]],
          levels = unique(srt@meta.data[[g]])
        )
      }
    }
  }
  if (length(split.by) > 1) {
    log_message(
      "'split.by' only support one variable.",
      message_type = "error"
    )
  }
  if (any(!split.by %in% colnames(srt@meta.data))) {
    log_message(
      split.by[!split.by %in% colnames(srt@meta.data)],
      " is not in the meta data of {.cls Seurat}.",
      message_type = "error"
    )
  }
  if (!is.null(split.by)) {
    if (!is.factor(srt@meta.data[[split.by]])) {
      srt@meta.data[[split.by]] <- factor(
        srt@meta.data[[split.by]],
        levels = unique(srt@meta.data[[split.by]])
      )
    }
  }
  if (length(group_palette) == 1) {
    group_palette <- rep(group_palette, length(group.by))
  }
  if (length(group_palette) != length(group.by)) {
    log_message(
      "'group_palette' must be the same length as 'group.by'",
      message_type = "error"
    )
  }
  group_palette <- stats::setNames(group_palette, nm = group.by)
  if (!is.null(group_palcolor)) {
    if (!is.list(group_palcolor)) {
      if (length(group.by) == 1) {
        group_palcolor <- list(group_palcolor)
      } else {
        log_message(
          "'group_palcolor' must be a list of the same length as 'group.by' when specifying custom colors for multiple groups.",
          message_type = "error"
        )
      }
    }
    if (length(group_palcolor) != length(group.by)) {
      log_message(
        "'group_palcolor' must be the same length as 'group.by'.",
        message_type = "error"
      )
    }
  }
  raw.group.by <- group.by
  raw.group_palette <- group_palette
  if (isTRUE(within_groups)) {
    new.group.by <- c()
    new.group_palette <- group_palette
    new.group_palcolor <- if (!is.null(group_palcolor)) list() else NULL
    for (g in group.by) {
      j <- match(g, group.by)
      groups <- split(colnames(srt), srt[[g, drop = TRUE]])
      new.group_palette[g] <- list(rep(new.group_palette[g], length(groups)))
      for (nm in names(groups)) {
        srt[[make.names(nm)]] <- factor(
          NA,
          levels = levels(srt[[g, drop = TRUE]])
        )
        srt[[make.names(nm)]][colnames(srt) %in% groups[[nm]], ] <- nm
        new.group.by <- c(new.group.by, make.names(nm))
        if (!is.null(new.group_palcolor)) {
          new.group_palcolor <- c(new.group_palcolor, list(group_palcolor[[j]]))
        }
      }
    }
    group.by <- new.group.by
    group_palette <- unlist(new.group_palette)
    if (!is.null(new.group_palcolor)) {
      group_palcolor <- new.group_palcolor
    }
  }
  if (is.null(feature_split_by)) {
    feature_split_by <- group.by
  }
  if (any(!feature_split_by %in% group.by)) {
    log_message(
      "feature_split_by must be a subset of group.by",
      message_type = "error"
    )
  }
  if (!is.null(feature_split) && !is.factor(feature_split)) {
    feature_split <- factor(feature_split, levels = unique(feature_split))
  }
  if (length(feature_split) != 0 && length(feature_split) != length(features)) {
    log_message(
      "feature_split must be the same length as features",
      message_type = "error"
    )
  }
  if (!is.null(cell_annotation)) {
    if (length(cell_annotation_palette) == 1) {
      cell_annotation_palette <- rep(
        cell_annotation_palette,
        length(cell_annotation)
      )
    }
    if (length(cell_annotation_palcolor) == 1) {
      cell_annotation_palcolor <- rep(
        cell_annotation_palcolor,
        length(cell_annotation)
      )
    }
    npal <- unique(c(
      length(cell_annotation_palette),
      length(cell_annotation_palcolor),
      length(cell_annotation)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "cell_annotation_palette and cell_annotation_palcolor must be the same length as cell_annotation",
        message_type = "error"
      )
    }
    if (
      any(
        !cell_annotation %in%
          c(colnames(srt@meta.data), rownames(Seurat::GetAssay(
            srt,
            assay = assay
          )))
      )
    ) {
      log_message(
        "cell_annotation: ",
        paste0(
          cell_annotation[
            !cell_annotation %in%
              c(colnames(srt@meta.data), rownames(Seurat::GetAssay(
                srt,
                assay = assay
              )))
          ],
          collapse = ","
        ),
        " is not in {.cls Seurat}.",
        message_type = "error"
      )
    }
  }
  if (!is.null(feature_annotation)) {
    if (length(feature_annotation_palette) == 1) {
      feature_annotation_palette <- rep(
        feature_annotation_palette,
        length(feature_annotation)
      )
    }
    if (length(feature_annotation_palcolor) == 1) {
      feature_annotation_palcolor <- rep(
        feature_annotation_palcolor,
        length(feature_annotation)
      )
    }
    npal <- unique(c(
      length(feature_annotation_palette),
      length(feature_annotation_palcolor),
      length(feature_annotation)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "feature_annotation_palette and feature_annotation_palcolor must be the same length as feature_annotation",
        message_type = "error"
      )
    }
    if (
      any(!feature_annotation %in% colnames(GetFeaturesData(srt, assay = assay)))
    ) {
      log_message(
        "feature_annotation: ",
        paste0(
          feature_annotation[
            !feature_annotation %in% colnames(GetFeaturesData(srt, assay = assay))
          ],
          collapse = ","
        ),
        " is not in the meta data of the ",
        assay,
        " assay in {.cls Seurat}.",
        message_type = "error"
      )
    }
  }
  if (length(width) == 1) {
    width <- rep(width, length(group.by))
  }
  if (length(height) == 1) {
    height <- rep(height, length(group.by))
  }
  if (length(width) >= 1) {
    names(width) <- group.by
  }
  if (length(height) >= 1) {
    names(height) <- group.by
  }

  if (isTRUE(flip)) {
    cluster_rows_raw <- cluster_rows
    cluster_columns_raw <- cluster_columns
    cluster_row_slices_raw <- cluster_row_slices
    cluster_column_slices_raw <- cluster_column_slices
    cluster_rows <- cluster_columns_raw
    cluster_columns <- cluster_rows_raw
    cluster_row_slices <- cluster_column_slices_raw
    cluster_column_slices <- cluster_row_slices_raw
  }

  if (!flip && show_row_names && !is.null(features)) {
    row_name_gp <- ht_params$row_names_gp %||% grid::gpar(fontsize = 10)
    fontsize <- row_name_gp$fontsize %||% 10
    max_nchar_val <- max(nchar(features), na.rm = TRUE)
    row_name_width_inch <- max_nchar_val * fontsize * 0.6 / 72
  } else {
    row_name_width_inch <- 0
  }

  if (is.null(cells)) {
    cells <- colnames(srt@assays[[1]])
  }
  if (all(!cells %in% colnames(srt@assays[[1]]))) {
    log_message(
      "No cells found.",
      message_type = "error"
    )
  }
  if (!all(cells %in% colnames(srt@assays[[1]]))) {
    log_message(
      "Some cells not found.",
      message_type = "warning"
    )
  }
  cells <- intersect(cells, colnames(srt@assays[[1]]))

  if (is.null(features)) {
    features <- SeuratObject::VariableFeatures(srt, assay = assay)
  }
  index <- features %in%
    c(rownames(Seurat::GetAssay(
      srt,
      assay = assay
    )), colnames(srt@meta.data))
  features <- features[index]
  features_unique <- make.unique(features)
  if (!is.null(feature_split)) {
    feature_split <- feature_split[index]
    names(feature_split) <- features_unique
  }

  cell_groups <- list()
  for (cell_group in group.by) {
    if (!is.factor(srt@meta.data[[cell_group]])) {
      srt@meta.data[[cell_group]] <- factor(
        srt@meta.data[[cell_group]],
        levels = unique(srt@meta.data[[cell_group]])
      )
    }
    if (is.null(split.by)) {
      cell_groups[[cell_group]] <- unlist(
        lapply(levels(srt@meta.data[[cell_group]]), function(x) {
          cells_sub <- colnames(srt@assays[[1]])[which(
            srt@meta.data[[cell_group]] == x
          )]
          cells_sub <- intersect(cells, cells_sub)
          size <- ifelse(
            length(cells_sub) > max_cells,
            max_cells,
            length(cells_sub)
          )
          cells_sample <- sample(cells_sub, size)
          out <- stats::setNames(rep(x, size), cells_sample)
          return(out)
        }),
        use.names = TRUE
      )
      levels <- levels(srt@meta.data[[cell_group]])
      cell_groups[[cell_group]] <- factor(
        cell_groups[[cell_group]],
        levels = levels[levels %in% cell_groups[[cell_group]]]
      )
    } else {
      if (!is.factor(srt@meta.data[[split.by]])) {
        srt@meta.data[[split.by]] <- factor(
          srt@meta.data[[split.by]],
          levels = unique(srt@meta.data[[split.by]])
        )
      }
      cell_groups[[cell_group]] <- unlist(
        lapply(levels(srt@meta.data[[cell_group]]), function(x) {
          cells_sub <- colnames(srt@assays[[1]])[
            srt@meta.data[[cell_group]] == x
          ]
          cells_sub <- intersect(cells, cells_sub)
          cells_tmp <- NULL
          for (sp in levels(srt@meta.data[[split.by]])) {
            cells_sp <- cells_sub[srt@meta.data[cells_sub, split.by] == sp]
            size <- ifelse(
              length(cells_sp) > max_cells,
              max_cells,
              length(cells_sp)
            )
            cells_sample <- sample(cells_sp, size)
            cells_tmp <- c(
              cells_tmp,
              stats::setNames(rep(paste0(x, " : ", sp), size), cells_sample)
            )
          }
          size <- ifelse(
            length(cells_tmp) > max_cells,
            max_cells,
            length(cells_tmp)
          )
          out <- sample(cells_tmp, size)
          return(out)
        }),
        use.names = TRUE
      )
      levels <- apply(
        expand.grid(
          levels(srt@meta.data[[split.by]]),
          levels(srt@meta.data[[cell_group]])
        ),
        1,
        function(x) paste0(x[2:1], collapse = " : ")
      )
      cell_groups[[cell_group]] <- factor(
        cell_groups[[cell_group]],
        levels = levels[levels %in% cell_groups[[cell_group]]]
      )
    }
    if (!is.null(cell_order)) {
      cell_groups[[cell_group]] <- cell_groups[[cell_group]][intersect(
        cell_order,
        names(cell_groups[[cell_group]])
      )]
    }
  }

  gene <- features[features %in% rownames(Seurat::GetAssay(
    srt,
    assay = assay
  ))]
  gene_unique <- features_unique[features %in% rownames(Seurat::GetAssay(
    srt,
    assay = assay
  ))]
  meta <- features[features %in% colnames(srt@meta.data)]
  all_cells <- unique(unlist(lapply(cell_groups, names)))
  gene_mat <- if (length(gene) > 0) {
    GetAssayData5(
      srt,
      assay = assay,
      layer = layer,
      features = gene,
      cells = all_cells
    )[gene, all_cells, drop = FALSE]
  } else {
    matrix(0, nrow = 0, ncol = length(all_cells), dimnames = list(character(0), all_cells))
  }
  meta_mat <- if (length(meta) > 0) {
    Matrix::t(srt@meta.data[all_cells, meta, drop = FALSE])
  } else {
    matrix(0, nrow = 0, ncol = length(all_cells), dimnames = list(character(0), all_cells))
  }
  mat_raw <- as_matrix(rbind(gene_mat, meta_mat))[features, , drop = FALSE]
  rownames(mat_raw) <- features_unique
  if (isTRUE(lib_normalize) && min(mat_raw, na.rm = TRUE) >= 0) {
    if (!is.null(libsize)) {
      libsize_use <- libsize
    } else {
      count_col <- paste0("nCount_", assay)
      if (count_col %in% colnames(srt@meta.data)) {
        libsize_use <- srt@meta.data[colnames(mat_raw), count_col]
      } else {
        libsize_use <- Matrix::colSums(
          GetAssayData5(
            srt,
            assay = assay,
            layer = "counts",
            cells = colnames(mat_raw)
          )
        )
      }
      isfloat <- any(libsize_use %% 1 != 0, na.rm = TRUE)
      if (isTRUE(isfloat)) {
        libsize_use <- rep(1, length(libsize_use))
        log_message(
          "The values in the 'counts' layer are non-integer. Set the library size to 1.",
          message_type = "warning"
        )
      }
    }
    mat_raw[gene_unique, ] <- Matrix::t(
      Matrix::t(mat_raw[gene_unique, , drop = FALSE]) /
        libsize_use *
        stats::median(libsize_use)
    )
  }

  mat_list <- list()
  for (cell_group in group.by) {
    mat_tmp <- mat_raw[, names(cell_groups[[cell_group]])]
    mat_tmp <- matrix_process(mat_tmp, method = exp_method)
    mat_tmp[is.infinite(mat_tmp)] <- max(
      abs(mat_tmp[!is.infinite(mat_tmp)]),
      na.rm = TRUE
    ) *
      ifelse(mat_tmp[is.infinite(mat_tmp)] > 0, 1, -1)
    mat_tmp[is.na(mat_tmp)] <- mean(mat_tmp, na.rm = TRUE)
    mat_list[[cell_group]] <- mat_tmp
  }

  mat_split <- do.call(cbind, mat_list[feature_split_by])
  combined_mat <- do.call(cbind, mat_list)
  col_groups <- rep(names(mat_list), times = vapply(mat_list, ncol, integer(1)))

  if (is.null(limits)) {
    if (!is.function(exp_method) && exp_method %in% c("zscore", "log2fc")) {
      b <- ceiling(
        min(
          abs(
            stats::quantile(
              combined_mat, c(0.01, 0.99),
              na.rm = TRUE
            )
          ),
          na.rm = TRUE
        ) *
          2
      ) /
        2
      colors <- circlize::colorRamp2(
        seq(-b, b, length = 100),
        palette_colors(
          palette = heatmap_palette,
          palcolor = heatmap_palcolor
        )
      )
    } else {
      b <- stats::quantile(
        combined_mat, c(0.01, 0.99),
        na.rm = TRUE
      )
      colors <- circlize::colorRamp2(
        seq(b[1], b[2], length = 100),
        palette_colors(
          palette = heatmap_palette,
          palcolor = heatmap_palcolor
        )
      )
    }
  } else {
    colors <- circlize::colorRamp2(
      seq(limits[1], limits[2], length = 100),
      palette_colors(
        palette = heatmap_palette,
        palcolor = heatmap_palcolor
      )
    )
  }

  ann_use <- intersect(
    cell_annotation,
    rownames(Seurat::GetAssay(srt, assay = assay))
  )
  cell_metadata <- cbind.data.frame(
    data.frame(
      row.names = colnames(mat_raw),
      cells = colnames(mat_raw)
    ),
    cbind.data.frame(
      srt@meta.data[
        colnames(mat_raw),
        c(
          group.by,
          intersect(cell_annotation, colnames(srt@meta.data))
        ),
        drop = FALSE
      ],
      Matrix::t(
        if (length(ann_use) > 0) {
          GetAssayData5(
            srt,
            assay = assay,
            layer = "data",
            features = ann_use,
            cells = colnames(mat_raw)
          )[ann_use, colnames(mat_raw), drop = FALSE]
        } else {
          matrix(
            0,
            nrow = 0,
            ncol = ncol(mat_raw),
            dimnames = list(character(0), colnames(mat_raw))
          )
        }
      )
    )
  )

  feature_metadata <- cbind.data.frame(
    data.frame(
      row.names = features_unique,
      features = features,
      features_uique = features_unique
    ),
    GetFeaturesData(srt, assay = assay)[
      features,
      c(feature_annotation),
      drop = FALSE
    ]
  )

  feature_metadata[, "duplicated"] <- feature_metadata[["features"]] %in%
    features[duplicated(features)]

  lgd <- list()
  lgd[["ht"]] <- ComplexHeatmap::Legend(
    title = exp_name,
    col_fun = colors,
    legend_gp = heatmap_border_gp(
      heatmap_border,
      heatmap_border_color,
      heatmap_border_size
    ),
    border = heatmap_legend_border(
      heatmap_border,
      heatmap_border_color
    )
  )

  ha_top_list <- NULL
  cluster_columns_list <- list()
  column_split_list <- list()
  for (i in seq_along(group.by)) {
    cell_group <- group.by[i]
    cluster_columns_list[[cell_group]] <- cluster_columns
    column_split_list[[cell_group]] <- cell_groups[[cell_group]]
    if (isTRUE(cluster_column_slices)) {
      if (isFALSE(cluster_columns)) {
        if (nlevels(column_split_list[[cell_group]]) == 1) {
          log_message(
            "cluster_column_slices=TRUE can not be used when there is only one group.",
            message_type = "error"
          )
        }
        dend <- ComplexHeatmap::cluster_within_group(
          mat_list[[cell_group]],
          column_split_list[[cell_group]]
        )
        cluster_columns_list[[cell_group]] <- dend
        column_split_list[[cell_group]] <- length(
          unique(
            column_split_list[[cell_group]]
          )
        )
      }
    }
    if (cell_group != "All.groups") {
      block_graphics <- thisplot::annotation_block_fill_graphics(
        levels = levels(srt@meta.data[[cell_group]]),
        palette = group_palette[i],
        palcolor = group_palcolor[[i]],
        border = cell_annotation_border,
        border_color = cell_annotation_border_color,
        border_size = cell_annotation_border_size
      )

      anno <- list()
      anno[[cell_group]] <- ComplexHeatmap::anno_block(
        align_to = split(
          seq_along(cell_groups[[cell_group]]),
          gsub(
            pattern = " : .*",
            replacement = "",
            x = cell_groups[[cell_group]]
          )
        ),
        panel_fun = block_graphics,
        which = ifelse(flip, "row", "column"),
        show_name = FALSE
      )
      ha_cell_group <- do.call(
        ComplexHeatmap::HeatmapAnnotation,
        args = c(
          anno,
          which = ifelse(flip, "row", "column"),
          show_annotation_name = TRUE,
          annotation_name_side = ifelse(flip, "top", "left"),
          border = cell_annotation_border
        )
      )
      ha_top_list[[cell_group]] <- ha_cell_group
    }

    if (!is.null(split.by)) {
      block_graphics <- thisplot::annotation_block_fill_graphics(
        levels = levels(srt@meta.data[[split.by]]),
        palette = cell_split_palette,
        palcolor = unlist(cell_split_palcolor),
        border = cell_annotation_border,
        border_color = cell_annotation_border_color,
        border_size = cell_annotation_border_size
      )

      anno <- list()
      anno[[split.by]] <- ComplexHeatmap::anno_block(
        align_to = split(
          seq_along(cell_groups[[cell_group]]),
          gsub(
            pattern = ".* : ",
            replacement = "",
            x = cell_groups[[cell_group]]
          )
        ),
        panel_fun = block_graphics,
        which = ifelse(flip, "row", "column"),
        show_name = i == 1
      )
      ha_split_by <- do.call(
        ComplexHeatmap::HeatmapAnnotation,
        args = c(
          anno,
          which = ifelse(flip, "row", "column"),
          show_annotation_name = TRUE,
          annotation_name_side = ifelse(flip, "top", "left"),
          border = cell_annotation_border
        )
      )
      if (is.null(ha_top_list[[cell_group]])) {
        ha_top_list[[cell_group]] <- ha_split_by
      } else {
        ha_top_list[[cell_group]] <- c(ha_top_list[[cell_group]], ha_split_by)
      }
    }
  }
  for (i in seq_along(raw.group.by)) {
    cell_group <- raw.group.by[i]
    if (cell_group != "All.groups") {
      lgd[[cell_group]] <- ComplexHeatmap::Legend(
        title = cell_group,
        labels = levels(srt@meta.data[[cell_group]]),
        legend_gp = grid::gpar(
          fill = palette_colors(
            levels(srt@meta.data[[cell_group]]),
            palette = raw.group_palette[i],
            palcolor = group_palcolor[[i]]
          )
        ),
        border = TRUE
      )
    }
  }
  if (!is.null(split.by)) {
    lgd[[split.by]] <- ComplexHeatmap::Legend(
      title = split.by,
      labels = levels(srt@meta.data[[split.by]]),
      legend_gp = grid::gpar(
        fill = palette_colors(
          levels(srt@meta.data[[split.by]]),
          palette = cell_split_palette,
          palcolor = cell_split_palcolor
        )
      ),
      border = TRUE
    )
  }

  if (!is.null(cell_annotation)) {
    for (i in seq_along(cell_annotation)) {
      cellan <- cell_annotation[i]
      palette <- cell_annotation_palette[i]
      palcolor <- cell_annotation_palcolor[[i]]
      cell_anno <- cell_metadata[, cellan]
      names(cell_anno) <- rownames(cell_metadata)
      if (!is.numeric(cell_anno)) {
        if (is.logical(cell_anno)) {
          cell_anno <- factor(cell_anno, levels = c(TRUE, FALSE))
        } else if (!is.factor(cell_anno)) {
          cell_anno <- factor(cell_anno, levels = unique(cell_anno))
        }
        for (cell_group in group.by) {
          ha_cell <- list()
          ha_cell[[cellan]] <- ComplexHeatmap::anno_simple(
            x = as.character(cell_anno[names(cell_groups[[cell_group]])]),
            col = palette_colors(
              cell_anno,
              palette = palette,
              palcolor = palcolor
            ),
            which = ifelse(flip, "row", "column"),
            na_col = "transparent",
            border = cell_annotation_border
          )
          ha_top <- build_heatmap_annotation(
            annotations = ha_cell,
            which = ifelse(flip, "row", "column"),
            show_annotation_name = cell_group == group.by[1],
            annotation_name_side = ifelse(flip, "top", "left"),
            params = cell_annotation_params
          )
          if (is.null(ha_top_list[[cell_group]])) {
            ha_top_list[[cell_group]] <- ha_top
          } else {
            ha_top_list[[cell_group]] <- c(ha_top_list[[cell_group]], ha_top)
          }
        }
        lgd[[cellan]] <- ComplexHeatmap::Legend(
          title = cellan,
          labels = levels(cell_anno),
          legend_gp = grid::gpar(
            fill = palette_colors(
              cell_anno,
              palette = palette,
              palcolor = palcolor
            )
          ),
          border = cell_annotation_border
        )
      } else {
        col_fun <- circlize::colorRamp2(
          breaks = seq(
            min(cell_anno, na.rm = TRUE),
            max(cell_anno, na.rm = TRUE),
            length = 100
          ),
          colors = palette_colors(palette = palette, palcolor = palcolor)
        )
        for (cell_group in group.by) {
          ha_cell <- list()
          ha_cell[[cellan]] <- ComplexHeatmap::anno_simple(
            x = cell_anno[names(cell_groups[[cell_group]])],
            col = col_fun,
            which = ifelse(flip, "row", "column"),
            na_col = "transparent",
            border = TRUE
          )
          ha_top <- build_heatmap_annotation(
            annotations = ha_cell,
            which = ifelse(flip, "row", "column"),
            show_annotation_name = cell_group == group.by[1],
            annotation_name_side = ifelse(flip, "top", "left"),
            params = cell_annotation_params
          )
          if (is.null(ha_top_list[[cell_group]])) {
            ha_top_list[[cell_group]] <- ha_top
          } else {
            ha_top_list[[cell_group]] <- c(ha_top_list[[cell_group]], ha_top)
          }
        }
        lgd[[cellan]] <- ComplexHeatmap::Legend(
          title = cellan,
          col_fun = col_fun,
          legend_gp = heatmap_border_gp(
            cell_annotation_border,
            cell_annotation_border_color,
            cell_annotation_border_size
          ),
          border = heatmap_legend_border(
            cell_annotation_border,
            cell_annotation_border_color
          )
        )
      }
    }
  }

  if (is.null(feature_split)) {
    if (is.null(n_split) || isTRUE(nrow(mat_split) <= n_split)) {
      row_split_raw <- row_split <- feature_split <- NULL
    } else {
      if (n_split == 1) {
        row_split_raw <- row_split <- feature_split <- stats::setNames(
          rep(1, nrow(mat_split)),
          rownames(mat_split)
        )
      } else {
        if (split_method == "mfuzz") {
          check_r("e1071", verbose = FALSE)
          mat_split_tmp <- mat_split
          colnames(mat_split_tmp) <- make.unique(colnames(mat_split_tmp))
          mat_split_tmp <- standardise(mat_split_tmp)
          min_fuzzification <- mestimate(mat_split_tmp)
          if (is.null(fuzzification)) {
            fuzzification <- min_fuzzification + 0.1
          } else {
            if (fuzzification <= min_fuzzification) {
              log_message(
                "{.arg fuzzification} value is samller than estimated: {.val {round(min_fuzzification, 2)}}",
                message_type = "warning",
                verbose = verbose
              )
            }
          }
          cl <- e1071::cmeans(
            mat_split_tmp,
            centers = n_split,
            method = "cmeans",
            m = fuzzification
          )
          if (length(cl$cluster) == 0) {
            log_message(
              "Clustering with mfuzz failed (fuzzification=",
              round(fuzzification, 2),
              "). Please set a larger fuzzification parameter manually.",
              message_type = "error"
            )
          }
          row_split <- feature_split <- cl$cluster
        }
        if (split_method == "kmeans") {
          km <- stats::kmeans(
            mat_split,
            centers = n_split,
            iter.max = 1e4,
            nstart = 20
          )
          row_split <- feature_split <- km$cluster
        }
        if (split_method == "hclust") {
          hc <- stats::hclust(
            stats::as.dist(
              proxyC::dist(mat_split)
            )
          )
          row_split <- feature_split <- stats::cutree(hc, k = n_split)
        }
      }
      groupmean <- stats::aggregate(
        Matrix::t(mat_split),
        by = list(unlist(cell_groups[feature_split_by])),
        mean
      )
      maxgroup <- groupmean[, 1][apply(
        groupmean[, names(row_split)],
        2,
        which.max
      )]
      df <- data.frame(row_split = row_split, order_by = maxgroup)
      df_order <- stats::aggregate(
        df[["order_by"]],
        by = list(df[, "row_split"]),
        FUN = function(x) names(sort(table(x), decreasing = TRUE))[1]
      )
      df_order[, "row_split"] <- df_order[, "Group.1"]
      df_order[["order_by"]] <- as.numeric(factor(
        df_order[["x"]],
        levels = levels(maxgroup)
      ))
      df_order <- df_order[
        order(df_order[["order_by"]], decreasing = decreasing), ,
        drop = FALSE
      ]
      if (!is.null(split_order)) {
        df_order <- df_order[split_order, , drop = FALSE]
      }
      split_levels <- c()
      for (i in seq_len(nrow(df_order))) {
        raw_nm <- df_order[i, "row_split"]
        feature_split[feature_split == raw_nm] <- paste0("C", i)
        level <- paste0("C", i, "(", sum(row_split == raw_nm), ")")
        row_split[row_split == raw_nm] <- level
        split_levels <- c(split_levels, level)
      }
      row_split_raw <- row_split <- factor(row_split, levels = split_levels)
      feature_split <- factor(
        feature_split,
        levels = paste0("C", seq_len(nrow(df_order)))
      )
    }
  } else {
    row_split_raw <- row_split <- feature_split <- feature_split[row.names(
      mat_split
    )]
  }
  if (!is.null(feature_split)) {
    feature_metadata[["feature_split"]] <- feature_split
  } else {
    feature_metadata[["feature_split"]] <- NA
  }

  ha_left <- NULL
  if (!is.null(row_split)) {
    if (isTRUE(cluster_row_slices)) {
      if (isFALSE(cluster_rows)) {
        dend <- ComplexHeatmap::cluster_within_group(
          Matrix::t(mat_split), row_split_raw
        )
        cluster_rows <- dend
        row_split <- length(unique(row_split_raw))
      }
    }
    block_graphics <- thisplot::annotation_block_fill_graphics(
      levels = levels(row_split_raw),
      palette = feature_split_palette,
      palcolor = unlist(feature_split_palcolor),
      border = feature_annotation_border,
      border_color = feature_annotation_border_color,
      border_size = feature_annotation_border_size
    )
    ha_clusters <- ComplexHeatmap::HeatmapAnnotation(
      features_split = ComplexHeatmap::anno_block(
        align_to = split(seq_along(row_split_raw), row_split_raw),
        panel_fun = block_graphics,
        width = grid::unit(0.1, "in"),
        height = grid::unit(0.1, "in"),
        show_name = FALSE,
        which = ifelse(flip, "column", "row")
      ),
      which = ifelse(flip, "column", "row"),
      border = feature_annotation_border,
      gp = heatmap_border_gp(
        feature_annotation_border,
        feature_annotation_border_color
      )
    )
    if (is.null(ha_left)) {
      ha_left <- ha_clusters
    } else {
      ha_left <- c(ha_left, ha_clusters)
    }
    lgd[["Cluster"]] <- ComplexHeatmap::Legend(
      title = "Cluster",
      labels = intersect(levels(row_split_raw), row_split_raw),
      legend_gp = grid::gpar(
        fill = palette_colors(
          intersect(levels(row_split_raw), row_split_raw),
          type = "discrete",
          palette = feature_split_palette,
          palcolor = feature_split_palcolor,
          matched = TRUE
        )
      ),
      border = TRUE
    )
  }

  if (isTRUE(cluster_rows) && !is.null(cluster_features_by)) {
    mat_cluster <- combined_mat[, unlist(lapply(cluster_features_by, function(g) which(col_groups == g))), drop = FALSE]
    if (is.null(row_split)) {
      dend <- stats::as.dendrogram(
        stats::hclust(
          stats::as.dist(
            proxyC::dist(mat_cluster)
          )
        )
      )
      dend_ordered <- stats::reorder(
        dend,
        wts = colMeans(mat_cluster),
        agglo.FUN = mean
      )
      cluster_rows <- dend_ordered
    } else {
      row_split <- length(unique(row_split_raw))
      dend <- cluster_within_group2(Matrix::t(mat_cluster), row_split_raw)
      cluster_rows <- dend
    }
  }

  need_feature_order <- !is.null(features_label) || nlabel > 0
  if (isTRUE(need_feature_order)) {
    cell_group <- group.by[1]
    ht_args <- list(
      name = cell_group,
      matrix = mat_list[[cell_group]],
      col = colors,
      row_split = row_split,
      column_split = column_split_list[[cell_group]],
      cluster_rows = cluster_rows,
      cluster_columns = cluster_columns_list[[cell_group]],
      cluster_row_slices = cluster_row_slices,
      cluster_column_slices = cluster_column_slices,
      use_raster = TRUE
    )
    ht_args <- c(ht_args, ht_params[setdiff(names(ht_params), names(ht_args))])
    ht_list <- do.call(ComplexHeatmap::Heatmap, args = ht_args)
    features_ordered <- rownames(
      mat_list[[1]]
    )[unlist(
      suppressWarnings(
        ComplexHeatmap::row_order(
          ht_list
        )
      )
    )]
  } else {
    features_ordered <- rownames(mat_list[[1]])
  }
  feature_metadata[["index"]] <- stats::setNames(
    object = seq_along(features_ordered),
    nm = features_ordered
  )[rownames(feature_metadata)]

  if (is.null(features_label)) {
    if (nlabel > 0) {
      if (length(features) > nlabel) {
        index_from <- ceiling((length(features_ordered) / nlabel) / 2)
        index_to <- length(features_ordered)
        index <- unique(round(seq(
          from = index_from,
          to = index_to,
          length.out = nlabel
        )))
      } else {
        index <- seq_along(features_ordered)
      }
    } else {
      index <- NULL
    }
  } else {
    index <- which(features_ordered %in% features_label)
    drop <- setdiff(features_label, features_ordered)
    if (length(drop) > 0) {
      log_message(
        "{.val {drop}} was not found in the features",
        message_type = "warning"
      )
    }
  }
  if (length(index) > 0) {
    mark_labels <- feature_metadata[
      which(rownames(feature_metadata) %in% features_ordered[index]),
      "features"
    ]
    if (!is.null(row_names_wrap)) {
      mark_labels <- heatmap_wrap_row_labels(
        mark_labels,
        width = row_names_wrap
      )
    }
    ha_mark <- ComplexHeatmap::HeatmapAnnotation(
      gene = ComplexHeatmap::anno_mark(
        at = which(rownames(feature_metadata) %in% features_ordered[index]),
        labels = mark_labels,
        side = ifelse(flip, "top", "left"),
        labels_gp = grid::gpar(fontsize = label_size, col = label_color),
        link_gp = grid::gpar(fontsize = label_size, col = label_color),
        which = ifelse(flip, "column", "row")
      ),
      which = ifelse(flip, "column", "row"),
      show_annotation_name = FALSE
    )
    if (is.null(ha_left)) {
      ha_left <- ha_mark
    } else {
      ha_left <- c(ha_mark, ha_left)
    }
  }

  ha_right <- NULL
  if (!is.null(feature_annotation)) {
    for (i in seq_along(feature_annotation)) {
      featan <- feature_annotation[i]
      palette <- feature_annotation_palette[i]
      palcolor <- feature_annotation_palcolor[[i]]
      feature <- build_heatmap_feature_annotation(
        annotation_name = featan,
        values = feature_metadata[, featan],
        palette = palette,
        palcolor = palcolor,
        flip = flip,
        border = feature_annotation_border,
        border_color = feature_annotation_border_color,
        border_size = feature_annotation_border_size,
        params = feature_annotation_params
      )
      ha_right <- if (is.null(ha_right)) {
        feature$annotation
      } else {
        c(ha_right, feature$annotation)
      }
      lgd[[featan]] <- feature$legend
    }
  }

  enrichment <- heatmap_enrichment(
    geneID = feature_metadata[["features"]],
    geneID_groups = feature_metadata[["feature_split"]],
    feature_split_palette = feature_split_palette,
    feature_split_palcolor = feature_split_palcolor,
    ha_right = ha_right,
    flip = flip,
    anno_terms = anno_terms,
    anno_keys = anno_keys,
    anno_features = anno_features,
    terms_width = terms_width,
    terms_stat_width = terms_stat_width,
    terms_fontsize = terms_fontsize,
    terms_stat = terms_stat,
    terms_stat_digits = terms_stat_digits,
    terms_stat_label = terms_stat_label,
    terms_stat_axis = terms_stat_axis,
    terms_stat_background_palcolor = terms_stat_background_palcolor,
    terms_stat_border = terms_stat_border,
    terms_stat_border_palcolor = terms_stat_border_palcolor,
    terms_stat_border_size = terms_stat_border_size,
    terms_stat_label_palcolor = terms_stat_label_palcolor,
    terms_group_background = terms_group_background,
    terms_background_palcolor = terms_background_palcolor,
    terms_background_alpha = terms_background_alpha,
    terms_border = terms_border,
    terms_border_palcolor = terms_border_palcolor,
    terms_border_size = terms_border_size,
    terms_text_palcolor = terms_text_palcolor,
    terms_bar_palcolor = terms_bar_palcolor,
    keys_width = keys_width,
    keys_fontsize = keys_fontsize,
    features_width = features_width,
    features_fontsize = features_fontsize,
    IDtype = IDtype,
    species = species,
    db_update = db_update,
    db_version = db_version,
    db_combine = db_combine,
    convert_species = convert_species,
    Ensembl_version = Ensembl_version,
    mirror = mirror,
    db = db,
    TERM2GENE = TERM2GENE,
    TERM2NAME = TERM2NAME,
    minGSSize = minGSSize,
    maxGSSize = maxGSSize,
    GO_simplify = GO_simplify,
    GO_simplify_cutoff = GO_simplify_cutoff,
    simplify_method = simplify_method,
    simplify_similarityCutoff = simplify_similarityCutoff,
    pvalueCutoff = pvalueCutoff,
    padjustCutoff = padjustCutoff,
    topTerm = topTerm,
    show_termid = show_termid,
    topWord = topWord,
    words_excluded = words_excluded,
    ...
  )
  res <- enrichment$res
  ha_right <- enrichment$ha_right
  lgd <- c(lgd, enrichment$lgd)

  ht_list <- NULL
  for (cell_group in group.by) {
    if (cell_group == group.by[1]) {
      left_annotation <- ha_left
    } else {
      left_annotation <- NULL
    }
    if (cell_group == group.by[length(group.by)]) {
      right_annotation <- ha_right
    } else {
      right_annotation <- NULL
    }

    matrix_use <- if (flip) {
      Matrix::t(mat_list[[cell_group]])
    } else {
      mat_list[[cell_group]]
    }
    ht_args <- list(
      name = cell_group,
      matrix = matrix_use,
      col = colors,
      row_title = row_title %||%
        if (flip) {
          ifelse(cell_group != "All.groups", cell_group, "")
        } else {
          character(0)
        },
      row_title_side = row_title_side,
      column_title = column_title %||%
        if (flip) {
          character(0)
        } else {
          ifelse(cell_group != "All.groups", cell_group, "")
        },
      column_title_side = column_title_side,
      row_title_rot = row_title_rot,
      column_title_rot = column_title_rot,
      row_split = if (flip) column_split_list[[cell_group]] else row_split,
      column_split = if (flip) row_split else column_split_list[[cell_group]],
      cluster_rows = if (flip) {
        cluster_columns_list[[cell_group]]
      } else {
        cluster_rows
      },
      cluster_columns = if (flip) {
        cluster_rows
      } else {
        cluster_columns_list[[cell_group]]
      },
      cluster_row_slices = if (flip) {
        cluster_column_slices
      } else {
        cluster_row_slices
      },
      cluster_column_slices = if (flip) {
        cluster_row_slices
      } else {
        cluster_column_slices
      },
      show_row_names = show_row_names,
      show_column_names = show_column_names,
      row_names_side = row_names_side,
      column_names_side = column_names_side,
      row_names_rot = row_names_rot,
      column_names_rot = column_names_rot,
      top_annotation = if (flip) left_annotation else ha_top_list[[cell_group]],
      left_annotation = if (flip) {
        ha_top_list[[cell_group]]
      } else {
        left_annotation
      },
      bottom_annotation = if (flip) right_annotation else NULL,
      right_annotation = if (flip) NULL else right_annotation,
      show_heatmap_legend = FALSE,
      border = heatmap_border,
      border_gp = heatmap_border_gp(heatmap_border, heatmap_border_color, heatmap_border_size),
      use_raster = use_raster,
      raster_device = raster_device,
      raster_by_magick = raster_by_magick,
      width = if (is.numeric(width[cell_group])) {
        grid::unit(width[cell_group], units = units)
      } else {
        NULL
      },
      height = if (is.numeric(height[cell_group])) {
        grid::unit(height[cell_group], units = units)
      } else {
        NULL
      }
    )
    if (!is.null(row_names_wrap)) {
      row_labels <- heatmap_wrap_row_labels(
        rownames(matrix_use),
        width = row_names_wrap
      )
      ht_args[["row_labels"]] <- row_labels
      if (!"row_names_max_width" %in% names(ht_params)) {
        ht_args[["row_names_max_width"]] <- heatmap_row_labels_max_width(
          row_labels,
          gp = ht_params[["row_names_gp"]]
        )
      }
    }
    if (!is.null(split.by) && isFALSE(cluster_column_slices)) {
      n_slices <- length(levels(column_split_list[[cell_group]]))
      groups_order <- sapply(
        strsplit(levels(column_split_list[[cell_group]]), " : "),
        function(x) x[[1]]
      )
      gaps_order <- paste(
        groups_order[2:length(groups_order)],
        groups_order[1:(length(groups_order) - 1)],
        sep = "->"
      )
      gaps <- rep(grid::unit(1, "mm"), length(gaps_order))
      gaps[
        groups_order[2:length(groups_order)] ==
          groups_order[1:(length(groups_order) - 1)]
      ] <- grid::unit(0, "mm")
      if (length(gaps) != 1L && length(gaps) != n_slices) {
        gaps <- grid::unit(1, "mm")
      }
      if (isTRUE(flip)) {
        ht_args[["row_gap"]] <- gaps
      } else {
        ht_args[["column_gap"]] <- gaps
      }
    }
    if (any(names(ht_params) %in% names(ht_args))) {
      log_message(
        "ht_params: ",
        paste0(intersect(names(ht_params), names(ht_args)), collapse = ","),
        " were duplicated and will not be used.",
        message_type = "warning"
      )
    }
    ht_args <- c(ht_args, ht_params[setdiff(names(ht_params), names(ht_args))])
    if (isTRUE(flip)) {
      if (is.null(ht_list)) {
        ht_list <- do.call(ComplexHeatmap::Heatmap, args = ht_args)
      } else {
        ht_list <- ht_list %v% do.call(ComplexHeatmap::Heatmap, args = ht_args)
      }
    } else {
      ht_list <- ht_list + do.call(ComplexHeatmap::Heatmap, args = ht_args)
    }
  }

  if (
    (!is.null(row_split) && length(index) > 0) ||
      any(c(anno_terms, anno_keys, anno_features)) ||
      !is.null(width) ||
      !is.null(height)
  ) {
    fix <- TRUE
    if (is.null(width) || is.null(height)) {
      log_message(
        "The size of the heatmap is fixed because certain elements are not scalable."
      )
      log_message(
        "The width and height of the heatmap are determined by the size of the current viewport."
      )
      log_message(
        "If you want to have more control over the size, you can manually set the parameters 'width' and 'height'."
      )
    }
  } else {
    fix <- FALSE
  }
  rendersize <- heatmap_rendersize(
    width = width,
    height = height,
    units = units,
    ha_top_list = ha_top_list,
    ha_left = ha_left,
    ha_right = ha_right,
    ht_list = ht_list,
    legend_list = lgd,
    flip = flip
  )
  width_sum <- rendersize[["width_sum"]]
  height_sum <- rendersize[["height_sum"]]

  if (isTRUE(fix)) {
    fixsize_env <- new.env(parent = emptyenv())
    invisible(grid::grid.grabExpr({
      fixsize_env[["value"]] <- heatmap_fixsize(
        width = width,
        width_sum = width_sum,
        height = height,
        height_sum = height_sum,
        units = units,
        ht_list = ht_list,
        legend_list = lgd
      )
    }))
    fixsize <- fixsize_env[["value"]]
    rm(fixsize_env)
    ht_width <- fixsize[["ht_width"]]
    ht_height <- fixsize[["ht_height"]]

    g_tree <- grid::grid.grabExpr(
      {
        ComplexHeatmap::draw(ht_list,
          annotation_legend_list = lgd,
          annotation_legend_side = legend.position
        )
        for (enrich in db) {
          enrich_anno <- names(ha_right)[grep(
            paste0("_split_", enrich),
            names(ha_right)
          )]
          if (length(enrich_anno) > 0) {
            for (enrich_anno_element in enrich_anno) {
              enrich_obj <- strsplit(enrich_anno_element, "_split_")[[1]][1]
              ComplexHeatmap::decorate_annotation(
                enrich_anno_element,
                slice = 1,
                {
                  grid::grid.text(
                    paste0(enrich, " (", enrich_obj, ")"),
                    x = grid::unit(1, "npc"),
                    y = grid::unit(1, "npc") + grid::unit(2.5, "mm"),
                    just = c("left", "bottom")
                  )
                }
              )
            }
          }
        }
      },
      width = ht_width,
      height = ht_height,
      wrap = TRUE,
      wrap.grobs = TRUE
    )
  } else {
    ht_width <- grid::unit(width_sum, units = units)
    ht_height <- grid::unit(height_sum, units = units)
    g_tree <- grid::grid.grabExpr(
      {
        ComplexHeatmap::draw(ht_list,
          annotation_legend_list = lgd,
          annotation_legend_side = legend.position
        )
        for (enrich in db) {
          enrich_anno <- names(ha_right)[grep(
            paste0("_split_", enrich),
            names(ha_right)
          )]
          if (length(enrich_anno) > 0) {
            for (enrich_anno_element in enrich_anno) {
              enrich_obj <- strsplit(enrich_anno_element, "_split_")[[1]][1]
              ComplexHeatmap::decorate_annotation(
                enrich_anno_element,
                slice = 1,
                {
                  grid::grid.text(
                    paste0(enrich, " (", enrich_obj, ")"),
                    x = grid::unit(1, "npc"),
                    y = grid::unit(1, "npc") + grid::unit(2.5, "mm"),
                    just = c("left", "bottom")
                  )
                }
              )
            }
          }
        }
      },
      width = ht_width,
      height = ht_height,
      wrap = TRUE,
      wrap.grobs = TRUE
    )
  }

  if (isTRUE(fix)) {
    p <- panel_fix_overall(
      g_tree,
      width = as.numeric(ht_width),
      height = as.numeric(ht_height),
      units = units
    )
  } else {
    p <- patchwork::wrap_plots(g_tree)
  }

  return(
    list(
      plot = p,
      matrix_list = mat_list,
      feature_split = feature_split,
      cell_metadata = cell_metadata,
      feature_metadata = feature_metadata,
      enrichment = res
    )
  )
}
