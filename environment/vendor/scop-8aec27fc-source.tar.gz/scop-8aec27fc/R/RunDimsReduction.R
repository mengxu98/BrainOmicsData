#' @title Run dimension reduction
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams GroupHeatmap
#' @inheritParams RunStandardWorkflow
#' @inheritParams scop-params
#' @param prefix The prefix used to name the result.
#' @param linear_reduction_dims Total number of dimensions to compute and store for `linear_reduction`.
#' @param linear_reduction_params Other parameters passed to the `linear_reduction` method.
#' @param force_linear_reduction Whether force to do linear dimension reduction.
#' @param nonlinear_reduction_dims Total number of dimensions to compute and store for `nonlinear_reduction`.
#' @param reduction_use Which dimensional reduction to use as input for `nonlinear_reduction`.
#' @param reduction_dims Which dimensions to use as input for `nonlinear_reduction`, used only if `features` is `NULL`.
#' @param neighbor_use Name of neighbor to use for the `nonlinear_reduction`.
#' @param graph_use Name of graph to use for the `nonlinear_reduction`.
#' @param nonlinear_reduction_params Other parameters passed to the `nonlinear_reduction` method.
#' @param force_nonlinear_reduction Whether force to do nonlinear dimension reduction.
#'
#' @seealso
#' [DefaultReduction]
#'
#' @export
RunDimsReduction <- function(
  object,
  prefix = "",
  features = NULL,
  assay = NULL,
  layer = "data",
  linear_reduction = NULL,
  linear_reduction_dims = 50,
  linear_reduction_params = list(),
  force_linear_reduction = FALSE,
  nonlinear_reduction = NULL,
  nonlinear_reduction_dims = 2,
  reduction_use = NULL,
  reduction_dims = NULL,
  graph_use = NULL,
  neighbor_use = NULL,
  nonlinear_reduction_params = list(),
  force_nonlinear_reduction = TRUE,
  verbose = TRUE,
  seed = 11,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  set.seed(seed)
  assay <- assay %||% SeuratObject::DefaultAssay(srt)
  if (inherits(srt[[assay]], "ChromatinAssay")) {
    type <- "Chromatin"
  } else {
    type <- "RNA"
  }

  linear_reduction_dims <- min(
    linear_reduction_dims,
    nrow(srt[[assay]]) - 1,
    ncol(srt[[assay]]) - 1,
    na.rm = TRUE
  )
  nonlinear_reduction_dims <- min(
    nonlinear_reduction_dims,
    nrow(srt[[assay]]) - 1,
    ncol(srt[[assay]]) - 1,
    na.rm = TRUE
  )

  linear_reductions <- c(
    "pca",
    "svd",
    "ica",
    "nmf",
    "mds",
    "glmpca"
  )
  reduction_exist <- SeuratObject::Reductions(srt)
  if (!is.null(linear_reduction)) {
    if (
      any(!linear_reduction %in% c(linear_reductions, reduction_exist)) ||
        length(linear_reduction) > 1
    ) {
      log_message(
        "{.arg linear_reduction} must be one of {.val {linear_reductions}}",
        message_type = "error"
      )
    }
  }
  nonlinear_reductions <- c(
    "umap",
    "umap-naive",
    "tsne",
    "dm",
    "phate",
    "pacmap",
    "trimap",
    "largevis",
    "fr"
  )
  if (!is.null(nonlinear_reduction)) {
    if (
      any(!nonlinear_reduction %in% c(nonlinear_reductions, reduction_exist)) ||
        length(nonlinear_reduction) > 1
    ) {
      log_message(
        "{.arg nonlinear_reduction} must be one of {.val {nonlinear_reductions}}",
        message_type = "error"
      )
    }

    if (
      is.null(features) &&
        is.null(reduction_use) &&
        is.null(neighbor_use) &&
        is.null(graph_use)
    ) {
      inputs <- c("features", "reduction_use", "neighbor_use", "graph_use")
      log_message(
        "One of {.arg {inputs}} must be provided when performing nonlinear dimension reduction",
        message_type = "error"
      )
    }

    base_message <- "Perform {.pkg {nonlinear_reduction}} nonlinear dimension reduction using "
    graph_message <- paste0(
      base_message,
      "{.pkg {graph_use}}"
    )
    neighbor_message <- paste0(
      base_message,
      "{.pkg {neighbor_use}}"
    )
    features_message <- paste0(
      base_message,
      "{.val {length(features)}} features"
    )
    reduction_message <- paste0(
      base_message,
      "{.pkg {reduction_use}} ({.val {min(reduction_dims)}}:{.val {max(reduction_dims)}})"
    )
    if (nonlinear_reduction %in% c("fr")) {
      if (!is.null(graph_use)) {
        log_message(
          graph_message,
          verbose = verbose
        )
      } else if (!is.null(neighbor_use)) {
        log_message(
          neighbor_message,
          verbose = verbose
        )
      } else if (!is.null(features)) {
        log_message(
          features_message,
          verbose = verbose
        )
      } else if (!is.null(reduction_use)) {
        log_message(
          reduction_message,
          verbose = verbose
        )
      }
    } else {
      if (!is.null(features)) {
        log_message(
          features_message,
          verbose = verbose
        )
      } else if (!is.null(reduction_use)) {
        log_message(
          reduction_message,
          verbose = verbose
        )
      } else if (!is.null(neighbor_use)) {
        log_message(
          neighbor_message,
          verbose = verbose
        )
      } else if (!is.null(graph_use)) {
        log_message(
          graph_message,
          verbose = verbose
        )
      }
    }
  }

  if (!is.null(linear_reduction)) {
    if (isFALSE(force_linear_reduction)) {
      if (linear_reduction %in% reduction_exist) {
        if (srt[[linear_reduction]]@assay.used == assay) {
          log_message(
            "{.arg linear_reduction} {.pkg {linear_reduction}} is already existed. Skip calculation"
          )
          reduc <- srt[[linear_reduction]]
          SeuratObject::Key(reduc) <- paste0(prefix, linear_reduction, "_")
          srt[[paste0(prefix, linear_reduction)]] <- reduc
          srt@reductions[[paste0(prefix, linear_reduction)]]@misc[[
            "dims_estimate"
          ]] <- RunDimsEstimate(
            object = srt,
            reduction = paste0(prefix, linear_reduction),
            reduction_method = linear_reduction,
            use_stored = TRUE,
            verbose = FALSE
          )
          srt@misc[["Default_reduction"]] <- paste0(prefix, linear_reduction)
          return(srt)
        } else {
          log_message(
            "{.arg assay.used} is {.val {srt[[linear_reduction]]@assay.used}}, which is not the same as the {.val {assay}} specified. Recalculate {.pkg pca} linear reduction"
          )
          linear_reduction <- "pca"
        }
      }
    }

    if (is.null(features) || length(features) == 0) {
      log_message("No features provided. Use variable features")
      if (length(SeuratObject::DefaultAssay(srt)) == 0) {
        srt <- FindVariableFeatures(srt, assay = assay, verbose = FALSE)
      }
      features <- SeuratObject::VariableFeatures(srt, assay = assay)
    }
    fun_use <- switch(linear_reduction,
      "pca" = "RunPCA",
      "svd" = "RunSVD",
      "ica" = "RunICA",
      "nmf" = "RunNMF",
      "mds" = "RunMDS",
      "glmpca" = "RunGLMPCA"
    )
    key_use <- switch(linear_reduction,
      "pca" = "PC_",
      "svd" = "LSI_",
      "ica" = "IC_",
      "nmf" = "BE_",
      "mds" = "MDS_",
      "glmpca" = "GLMPC_"
    )
    components_nm <- switch(linear_reduction,
      "pca" = "npcs",
      "svd" = "n",
      "ica" = "nics",
      "nmf" = "nbes",
      "mds" = "nmds",
      "glmpca" = "L"
    )
    params <- list(
      object = srt,
      assay = assay,
      layer = layer,
      features = features,
      components_nm = linear_reduction_dims,
      reduction.name = paste0(prefix, linear_reduction),
      reduction.key = paste0(prefix, key_use),
      verbose = verbose,
      seed.use = seed
    )
    if (fun_use == "RunPCA") {
      params[["slot"]] <- params[["layer"]]
      params[["verbose"]] <- FALSE
      params <- params[!names(params) %in% "layer"]
    }
    if (fun_use %in% c("RunSVD", "RunICA")) {
      params <- params[!names(params) %in% "layer"]
    }
    if (fun_use == "RunGLMPCA") {
      params[["layer"]] <- "counts"
    }
    names(params)[names(params) == "components_nm"] <- components_nm
    for (nm in names(linear_reduction_params)) {
      params[[nm]] <- linear_reduction_params[[nm]]
    }
    srt <- if (
      identical(fun_use, "RunPCA") &&
        length(linear_reduction_params) == 0L
    ) {
      RunPCA(
        object = srt,
        assay = assay,
        features = features,
        npcs = linear_reduction_dims,
        reduction.name = paste0(prefix, linear_reduction),
        reduction.key = paste0(prefix, key_use),
        verbose = FALSE,
        seed.use = seed
      )
    } else if (identical(fun_use, "RunPCA")) {
      do.call(RunPCA, params)
    } else {
      invoke_fun(.fn = fun_use, .args = params)
    }

    if (is.null(rownames(srt[[paste0(prefix, linear_reduction)]]))) {
      rownames(
        srt[[paste0(prefix, linear_reduction)]]@cell.embeddings
      ) <- colnames(srt)
    }
    if (linear_reduction == "pca") {
      pca_out <- srt[[paste0(prefix, linear_reduction)]]
      if (inherits(srt[[assay]], "Assay5")) {
        scale_mat <- SeuratObject::LayerData(
          object = srt[[assay]],
          layer = "scale.data"
        )
      } else {
        scale_mat <- GetAssayData5(srt, assay = assay, layer = "scale.data")
      }
      scale_features <- rownames(scale_mat)
      features_use <- intersect(features, scale_features)
      if (length(features_use) != length(features)) {
        dropped <- setdiff(features, features_use)
        log_message(
          "Some PCA features are absent from scale.data and will be dropped: {.val {dropped}}",
          message_type = "warning",
          verbose = verbose
        )
      }
      center <- rowMeans(scale_mat[features_use, , drop = FALSE])
      model <- list(
        sdev = pca_out@stdev,
        rotation = pca_out@feature.loadings,
        center = center,
        scale = FALSE,
        x = pca_out@cell.embeddings
      )
      class(model) <- "prcomp"
      srt@reductions[[paste0(prefix, linear_reduction)]]@misc[[
        "model"
      ]] <- model
    }
    dims_estimate <- RunDimsEstimate(
      object = srt,
      reduction = paste0(prefix, linear_reduction),
      reduction_method = linear_reduction,
      use_stored = FALSE,
      verbose = FALSE
    )
    srt@reductions[[paste0(prefix, linear_reduction)]]@misc[[
      "dims_estimate"
    ]] <- dims_estimate
    srt@misc[["Default_reduction"]] <- paste0(prefix, linear_reduction)
  } else if (!is.null(nonlinear_reduction)) {
    if (isFALSE(force_nonlinear_reduction)) {
      if (nonlinear_reduction %in% reduction_exist) {
        if (srt[[nonlinear_reduction]]@assay.used == assay) {
          log_message(
            "{.arg nonlinear_reduction} {.pkg {nonlinear_reduction}} is already existed. Skip calculation",
            message_type = "warning",
            verbose = verbose
          )
          reduc <- srt[[nonlinear_reduction]]
          SeuratObject::Key(reduc) <- paste0(prefix, nonlinear_reduction, "_")
          srt[[paste0(prefix, nonlinear_reduction)]] <- reduc
          srt@misc[["Default_reduction"]] <- paste0(prefix, nonlinear_reduction)
          return(srt)
        } else {
          log_message(
            "{.arg assay.used} is {.val {srt[[nonlinear_reduction]]@assay.used}}, which is not the same as the {.val {assay}} specified. Recalculate {.pkg umap} nonlinear reduction",
            message_type = "warning",
            verbose = verbose
          )
          nonlinear_reduction <- "umap"
        }
      }
    }

    fun_use <- switch(
      EXPR = nonlinear_reduction,
      "umap" = "RunUMAP2",
      "umap-naive" = "RunUMAP2",
      "tsne" = "RunTSNE",
      "dm" = "RunDM",
      "phate" = "RunPHATE",
      "pacmap" = "RunPaCMAP",
      "trimap" = "RunTriMap",
      "largevis" = "RunLargeVis",
      "fr" = "RunFR"
    )
    components_nm <- switch(
      EXPR = nonlinear_reduction,
      "umap" = "n.components",
      "umap-naive" = "n.components",
      "tsne" = "dim.embed",
      "dm" = "ndcs",
      "phate" = "n_components",
      "pacmap" = "n_components",
      "trimap" = "n_components",
      "largevis" = "n_components",
      "fr" = "ndim"
    )
    other_params <- switch(
      EXPR = nonlinear_reduction,
      "umap" = list(umap.method = "uwot", return.model = TRUE),
      "umap-naive" = list(umap.method = "naive", return.model = TRUE),
      "tsne" = list(
        tsne.method = "Rtsne",
        num_threads = 0,
        check_duplicates = FALSE
      ),
      "dm" = list(),
      "phate" = list(),
      "pacmap" = list(),
      "trimap" = list(),
      "largevis" = list(),
      "fr" = list()
    )
    nonlinear_reduction_sim <- toupper(
      gsub(
        pattern = "-.*",
        replacement = "",
        x = nonlinear_reduction
      )
    )
    params <- list(
      object = srt,
      assay = assay,
      layer = layer,
      components_nm = nonlinear_reduction_dims,
      features = features,
      reduction = reduction_use,
      dims = reduction_dims,
      reduction.name = paste0(
        prefix,
        nonlinear_reduction_sim,
        nonlinear_reduction_dims,
        "D"
      ),
      reduction.key = paste0(
        prefix,
        nonlinear_reduction_sim,
        nonlinear_reduction_dims,
        "D_"
      ),
      verbose = FALSE,
      seed.use = seed
    )
    if (!is.null(neighbor_use)) {
      params[["neighbor"]] <- neighbor_use
    }
    if (!is.null(graph_use)) {
      params[["graph"]] <- graph_use
    }
    names(params)[names(params) == "components_nm"] <- components_nm
    for (nm in names(other_params)) {
      params[[nm]] <- other_params[[nm]]
    }
    for (nm in names(nonlinear_reduction_params)) {
      params[[nm]] <- nonlinear_reduction_params[[nm]]
    }
    srt <- invoke_fun(.fn = fun_use, .args = params)

    srt@reductions[[paste0(
      prefix,
      nonlinear_reduction_sim,
      nonlinear_reduction_dims,
      "D"
    )]]@misc[["reduction_dims"]] <- reduction_dims
    srt@reductions[[paste0(
      prefix,
      nonlinear_reduction_sim,
      nonlinear_reduction_dims,
      "D"
    )]]@misc[["reduction_use"]] <- reduction_use
    srt@misc[["Default_reduction"]] <- paste0(prefix, nonlinear_reduction_sim)
  }

  return(srt)
}
