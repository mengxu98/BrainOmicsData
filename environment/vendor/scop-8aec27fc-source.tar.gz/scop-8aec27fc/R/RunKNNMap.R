#' @title Single-cell reference mapping with KNN method
#'
#' @description
#' Performs single-cell reference mapping using the K-nearest neighbor (KNN) method.
#' It takes two single-cell datasets as input: srt_query and srt_ref.
#' The function maps cells from the srt_query dataset to the srt_ref dataset based on their similarity or distance.
#'
#' @md
#' @inheritParams CellCorHeatmap
#' @inheritParams RunKNNPredict
#' @inheritParams thisutils::log_message
#' @param ref_umap Name of the UMAP reduction in the reference object.
#' If not provided, the first UMAP reduction found in the reference object will be used.
#' @param query_reduction Name of a dimensionality reduction in the query object to use for calculating the distance metric.
#' @param ref_reduction Name of a dimensionality reduction in the reference object to use for calculating the distance metric.
#' @param query_dims Dimension indices from the query reduction to be used for calculating the distance metric.
#' @param ref_dims Dimension indices from the reference reduction to be used for calculating the distance metric.
#' @param projection_method Projection method to use.
#' Options are "model" and "knn". If "model" is selected, the function will try to use a pre-trained UMAP model in the reference object for projection.
#' If "knn" is selected, the function will directly find the nearest neighbors using the distance metric.
#' @param k A number of nearest neighbors to find for each cell in the query object.
#' @param distance_metric The distance metric to use for calculating the pairwise distances between cells.
#' Options include: "pearson", "spearman", "cosine", "correlation", "jaccard", "ejaccard",
#' "dice", "edice", "hamman", "simple matching", and "faith".
#' Additional distance metrics can also be used, such as "euclidean", "manhattan", "hamming", etc.
#' @param vote_fun Function to be used for aggregating the nearest neighbors in the reference object.
#' Options are "mean", "median", "sum", "min", "max", "sd", "var", etc.
#' If not provided, the default is "mean".
#'
#' @return
#' A Seurat object with the projection results stored in the "ref.embeddings" reduction.
#' If `ref_group` is provided, the function will also add a new metadata column called "predicted_ref_group" to the query object.
#'
#' @seealso
#' [RunKNNPredict], [RunSingleR], [CellCorHeatmap]
#'
#' @export
#'
#' @examples
#' data(panc8_sub)
#' keep <- panc8_sub$celltype %in% c("ductal", "alpha", "beta")
#' panc8_sub <- panc8_sub[, keep]
#' panc8_sub <- RunStandardWorkflow(
#'   panc8_sub,
#'   verbose = FALSE, linear_reduction_dims = 10
#' )
#' srt_ref <- panc8_sub[, panc8_sub$tech != "fluidigmc1"]
#' srt_query <- panc8_sub[, panc8_sub$tech == "fluidigmc1"]
#' srt_query <- RunKNNMap(
#'   srt_query = srt_query,
#'   srt_ref = srt_ref,
#'   ref_umap = "StandardUMAP2D",
#'   k = 10,
#'   verbose = FALSE
#' )
#' ProjectionPlot(
#'   srt_query = srt_query,
#'   srt_ref = srt_ref,
#'   query_group = "celltype",
#'   ref_group = "celltype"
#' )
RunKNNMap <- function(
  srt_query,
  srt_ref,
  query_assay = NULL,
  ref_assay = NULL,
  ref_umap = NULL,
  ref_group = NULL,
  features = NULL,
  nfeatures = 2000,
  query_reduction = NULL,
  ref_reduction = NULL,
  query_dims = 1:30,
  ref_dims = 1:30,
  projection_method = c("model", "knn"),
  nn_method = NULL,
  k = 30,
  distance_metric = "cosine",
  vote_fun = "mean",
  verbose = TRUE
) {
  query_assay <- query_assay %||% SeuratObject::DefaultAssay(srt_query)
  ref_assay <- ref_assay %||% SeuratObject::DefaultAssay(srt_ref)
  if (!is.null(ref_group)) {
    if (length(ref_group) == ncol(srt_ref)) {
      srt_ref[["ref_group"]] <- ref_group
    } else if (length(ref_group) == 1) {
      if (!ref_group %in% colnames(srt_ref@meta.data)) {
        log_message(
          "{.arg ref_group} must be one of the column names in the meta.data",
          message_type = "error"
        )
      } else {
        srt_ref[["ref_group"]] <- srt_ref[[ref_group]]
      }
    } else {
      log_message(
        "Length of {.arg ref_group} must be one or length of {.arg srt_ref}",
        message_type = "error"
      )
    }
    ref_group <- "ref_group"
  }
  if (is.null(ref_umap)) {
    ref_umap <- sort(
      SeuratObject::Reductions(srt_ref)[grep(
        "umap",
        SeuratObject::Reductions(srt_ref),
        ignore.case = TRUE
      )]
    )[1]
    if (length(ref_umap) == 0) {
      log_message(
        "Cannot find UMAP reduction in the {.arg srt_ref}",
        message_type = "error"
      )
    } else {
      log_message("Set {.arg ref_umap} to {.val {ref_umap}}", verbose = verbose)
    }
  }
  projection_method <- match.arg(projection_method)
  if (projection_method == "model" && !"model" %in% names(srt_ref[[ref_umap]]@misc)) {
    log_message(
      "No UMAP model detected. Set the {.arg projection_method} to {.val knn}",
      verbose = verbose
    )
    projection_method <- "knn"
  }
  distance_metrics <- c("euclidean", "cosine", "manhattan", "hamming")
  if (projection_method == "model" && !distance_metric %in% distance_metrics) {
    log_message(
      "{.arg distance_metric} must be one of {.val {distance_metrics}} when projection_method = 'model'",
      message_type = "error"
    )
  }
  simil_method <- c(
    "pearson",
    "spearman",
    "cosine",
    "correlation",
    "jaccard",
    "ejaccard",
    "dice",
    "edice",
    "hamman",
    "simple matching",
    "faith"
  )
  dist_method <- c(
    "euclidean",
    "chisquared",
    "kullback",
    "manhattan",
    "maximum",
    "canberra",
    "minkowski",
    "hamming"
  )
  all_metrics <- c(simil_method, dist_method)
  if (!distance_metric %in% all_metrics) {
    log_message(
      "{.arg distance_metric} must be one of {.val {all_metrics}}",
      message_type = "error"
    )
  }
  if (projection_method == "model") {
    model <- srt_ref[[ref_umap]]@misc$model
    if ("layout" %in% names(model)) {
      if (k != model$config$n_neighbors) {
        k <- model$config$n_neighbors
        log_message("Set k to {.val k} which is used in the umap model", verbose = verbose)
      }
    } else if ("embedding" %in% names(model)) {
      if (k != model$n_neighbors) {
        k <- model$n_neighbors
        log_message("Set k to {.val k} which is used in the umap model", verbose = verbose)
      }
    }
  }

  if (!is.null(query_reduction) && !is.null(ref_reduction)) {
    log_message("Use the reduction to calculate distance metric", verbose = verbose)
    if (!is.null(query_dims) && !is.null(ref_dims) && length(query_dims) == length(ref_dims)) {
      query <- Seurat::Embeddings(srt_query, reduction = query_reduction)
      query <- query[, query_dims]
      ref <- Seurat::Embeddings(srt_ref, reduction = ref_reduction)
      ref <- ref[, ref_dims]
    } else {
      log_message(
        "{.arg query_dims} and {.arg ref_dims} must be provided with the same length",
        message_type = "error"
      )
    }
  } else {
    log_message("Use the features to calculate distance metric", verbose = verbose)
    query_data <- GetAssayData5(srt_query, layer = "data", assay = query_assay)
    ref_data <- GetAssayData5(srt_ref, layer = "data", assay = ref_assay)
    status_query <- CheckDataType(object = query_data)
    status_ref <- CheckDataType(object = ref_data)
    if (status_ref != status_query) {
      log_message(
        "Data type is different between {.arg srt_query} and {.arg srt_ref}",
        message_type = "warning",
        verbose = verbose
      )
    }
    if (any(status_query == "unknown", status_ref == "unknown")) {
      log_message(
        "Data type is unknown in {.arg srt_query} or {.arg srt_ref}",
        message_type = "warning",
        verbose = verbose
      )
    }
    if (length(features) == 0) {
      vf_ref <- SeuratObject::VariableFeatures(
        srt_ref,
        assay = ref_assay
      )
      if (length(vf_ref) == 0) {
        srt_ref <- FindVariableFeatures(
          srt_ref,
          nfeatures = nfeatures,
          assay = ref_assay
        )
        vf_ref <- SeuratObject::VariableFeatures(
          srt_ref,
          assay = ref_assay
        )
      }
      vf_query <- SeuratObject::VariableFeatures(
        srt_query,
        assay = query_assay
      )
      if (length(vf_query) == 0) {
        srt_query <- FindVariableFeatures(
          srt_query,
          nfeatures = nfeatures,
          assay = query_assay
        )
        vf_query <- SeuratObject::VariableFeatures(
          srt_query,
          assay = query_assay
        )
      }
      features <- intersect(
        vf_query,
        vf_ref
      )
    }
    features_common <- Reduce(
      intersect,
      list(
        features,
        rownames(srt_query[[query_assay]]),
        rownames(srt_ref[[ref_assay]])
      )
    )
    log_message(
      "Use {.val {length(features_common)}} features to calculate distance",
      verbose = verbose
    )
    query <- Matrix::t(
      query_data[features_common, , drop = FALSE]
    )
    ref <- Matrix::t(
      ref_data[features_common, , drop = FALSE]
    )
  }

  if (
    projection_method == "model" &&
      "layout" %in% names(model) &&
      is.null(ref_group)
  ) {
    srt_query[["ref.embeddings"]] <- RunUMAP2(
      object = query,
      reduction.model = srt_ref[[ref_umap]],
      assay = query_assay
    )
    srt_query[["ref.embeddings"]]@misc[["reduction.model"]] <- ref_umap
    return(srt_query)
  }

  if (is.null(nn_method)) {
    if (as.numeric(nrow(query)) * as.numeric(nrow(ref)) >= 1e8) {
      nn_method <- "annoy"
    } else {
      nn_method <- "raw"
    }
  }
  log_message("Use {.pkg {nn_method}} method to find neighbors", verbose = verbose)
  if (!nn_method %in% c("raw", "annoy", "rann")) {
    log_message(
      "{.arg nn_method} must be one of {.val {c('raw', 'annoy', 'rann')}}",
      message_type = "error"
    )
  }
  if (nn_method == "annoy" && !distance_metric %in% distance_metrics) {
    log_message(
      "{.arg distance_metric} must be one of {.val {distance_metrics}} when {.arg nn_method = 'annoy'}",
      message_type = "error"
    )
  }

  native_knn <- if (identical(nn_method, "raw")) {
    knn_cross_topk_native(
      reference = ref,
      query = query,
      k = k,
      distance_metric = distance_metric
    )
  } else {
    NULL
  }
  if (!is.null(native_knn)) {
    match_k <- native_knn[["idx"]]
    rownames(match_k) <- rownames(query)
    match_k_cell <- matrix(
      rownames(ref)[match_k],
      nrow = nrow(match_k),
      ncol = ncol(match_k),
      dimnames = list(rownames(query), NULL)
    )
    knn_cells <- match_k_cell
    match_k_distance <- native_knn[["distance"]]
    rownames(match_k_distance) <- rownames(query)
    refumap_all <- srt_ref[[ref_umap]]@cell.embeddings[
      knn_cells, ,
      drop = FALSE
    ]
    group <- rep(rownames(query), k)
  } else if (nn_method %in% c("annoy", "rann")) {
    query_neighbor <- FindNeighbors(
      query = query,
      object = ref,
      k.param = k,
      nn.method = nn_method,
      annoy.metric = distance_metric,
      return.neighbor = TRUE
    )
    match_k <- query_neighbor@nn.idx
    rownames(match_k) <- rownames(query)
    match_k_cell <- knn_indices_to_names(match_k, rownames(ref))
    knn_cells <- c(match_k_cell)
    match_k_distance <- query_neighbor@nn.dist
    rownames(match_k_distance) <- rownames(query)
    refumap_all <- srt_ref[[ref_umap]]@cell.embeddings[knn_cells, ]
    group <- rep(query_neighbor@cell.names, ncol(query_neighbor@nn.idx))
  } else {
    if (distance_metric %in% c(simil_method, "pearson", "spearman")) {
      if (distance_metric %in% c("pearson", "spearman")) {
        if (distance_metric == "spearman") {
          ref <- knn_rank_rows(ref)
          query <- knn_rank_rows(query)
        }
        distance_metric <- "correlation"
      }
      d <- 1 -
        proxyC::simil(
          x = SeuratObject::as.sparse(ref),
          y = SeuratObject::as.sparse(query),
          method = distance_metric,
          use_nan = TRUE
        )
    } else if (distance_metric %in% dist_method) {
      d <- proxyC::dist(
        x = SeuratObject::as.sparse(ref),
        y = SeuratObject::as.sparse(query),
        method = distance_metric,
        use_nan = TRUE
      )
    }
    knn_topk <- run_dense_topk(
      x = d,
      k = k,
      by = "col",
      decreasing = FALSE
    )
    match_k <- knn_topk[["idx"]]
    rownames(match_k) <- colnames(d)
    match_k_cell <- matrix(
      rownames(d)[match_k],
      nrow = nrow(match_k),
      ncol = ncol(match_k),
      dimnames = list(colnames(d), NULL)
    )
    match_k_distance <- knn_topk[["value"]]
    rownames(match_k_distance) <- colnames(d)
    knn_cells <- match_k_cell
    refumap_all <- srt_ref[[ref_umap]]@cell.embeddings[
      knn_cells, ,
      drop = FALSE
    ]
    group <- rep(colnames(d), k)
  }

  if (projection_method == "model") {
    if ("layout" %in% names(model)) {
      srt_query[["ref.embeddings"]] <- RunUMAP2(
        object = query,
        reduction.model = srt_ref[[ref_umap]],
        assay = query_assay
      )
      srt_query[["ref.embeddings"]]@misc[["reduction.model"]] <- ref_umap
    } else if ("embedding" %in% names(model)) {
      match_k <- as_matrix(match_k)
      match_k_distance <- as_matrix(match_k_distance)

      invalid_idx <- match_k < 1 | match_k > nrow(ref) | is.na(match_k)
      if (any(invalid_idx)) {
        n_invalid <- sum(invalid_idx, na.rm = TRUE)
        match_k[invalid_idx] <- sample(
          seq_len(nrow(ref)),
          size = n_invalid, replace = TRUE
        )
      }

      if (any(is.na(match_k_distance))) {
        match_k_distance <- knn_fill_missing_distances(match_k_distance)
      }

      if (any(!is.finite(match_k_distance))) {
        finite_max <- if (any(is.finite(match_k_distance))) {
          max(match_k_distance[is.finite(match_k_distance)], na.rm = TRUE)
        } else {
          1.0
        }
        match_k_distance[!is.finite(match_k_distance)] <- finite_max
      }

      neighborlist <- list(idx = match_k, dist = match_k_distance)
      srt_query[["ref.embeddings"]] <- RunUMAP2(
        object = neighborlist,
        reduction.model = srt_ref[[ref_umap]],
        assay = query_assay
      )
      srt_query[["ref.embeddings"]]@misc[["reduction.model"]] <- ref_umap
    }
  } else {
    refumap <- stats::aggregate(refumap_all, by = list(group), FUN = vote_fun)
    rownames(refumap) <- refumap[, 1]
    refumap[, 1] <- NULL
    colnames(refumap) <- paste0("Dim_", seq_len(ncol(refumap)))
    refumap <- as_matrix(refumap)
    srt_query[["ref.embeddings"]] <- SeuratObject::CreateDimReducObject(
      embeddings = refumap,
      key = "Dim_",
      assay = query_assay,
      misc = list(reduction.model = ref_umap)
    )
  }

  if (!is.null(ref_group)) {
    log_message(
      "Predicting cell types based on ref_group",
      verbose = verbose
    )
    level <- as.character(unique(srt_ref[["ref_group", drop = TRUE]]))
    if (k == 1) {
      match_best <- srt_ref[["ref_group", drop = TRUE]][match_k_cell[, 1]]
      names(match_best) <- names(match_k_cell[, 1])
    } else {
      rn <- rownames(match_k_cell)
      match_k_cell <- matrix(
        srt_ref[["ref_group", drop = TRUE]][match_k_cell],
        nrow = nrow(match_k_cell),
        ncol = ncol(match_k_cell)
      )
      rownames(match_k_cell) <- rn
      vote <- knn_vote_labels(match_k_cell, levels = level)
      match_prob <- vote$probability
      rownames(match_prob) <- rn
      match_best <- vote$best
    }
    srt_query[[paste0("predicted_", ref_group)]] <- match_best[colnames(
      srt_query
    )]
  }

  return(srt_query)
}

knn_fill_missing_distances <- function(x) {
  if (!anyNA(x)) {
    return(x)
  }
  check_r("matrixStats", verbose = FALSE)
  global_max <- if (any(is.finite(x))) max(x, na.rm = TRUE) else 1.0
  all_missing <- rowSums(!is.na(x)) == 0L
  fill_values <- matrixStats::rowMaxs(x, na.rm = TRUE)
  fill_values[all_missing] <- global_max
  missing <- which(is.na(x), arr.ind = TRUE)
  x[missing] <- fill_values[missing[, 1L]]
  x
}
