#' @title Prepare gene annotation databases
#'
#' @description
#' Build TERM2GENE / TERM2NAME (and GO semantic-similarity) databases for a
#' species from annotation packages, cached downloads, or local files.
#'
#' @md
#' @inheritParams GeneConvert
#' @inheritParams thisutils::log_message
#' @param species `"Homo_sapiens"` or `"Mus_musculus"`.
#' @param db Annotation sources. One or more of `"GO"`, `"GO_BP"`, `"GO_CC"`,
#' `"GO_MF"`, `"KEGG"`, `"WikiPathway"`, `"Reactome"`, `"CORUM"`, `"MP"`, `"DO"`,
#' `"HPO"`, `"PFAM"`, `"CSPA"`, `"Surfaceome"`, `"SPRomeDB"`, `"VerSeDa"`,
#' `"TFLink"`, `"hTFtarget"`, `"TRRUST"`, `"JASPAR"`, `"ENCODE"`, `"MSigDB"`,
#' `"CellTalk"`, `"CellChat"`, `"Chromosome"`, `"GeneType"`, `"Enzyme"`, `"TF"`,
#' `"CytoTRACE2"`. MSigDB collections use `"MSigDB_<collection>"`, with `:`
#' replaced by `_`. Top-level names such as `"MSigDB_H"` (human hallmark),
#' `"MSigDB_MH"` (mouse hallmark) and `"MSigDB_M2"` stay available and include
#' their nested collections. Nested names include each prefix, for example
#' `"MSigDB_M2_CGP"`, `"MSigDB_M2_CP"` and `"MSigDB_M2_CP_BIOCARTA"`. Colon
#' forms such as `"MSigDB_M2:CGP"` are accepted. `"CytoTRACE2"` is
#' species-independent and is required by [RunCytoTRACE].
#' @param db_IDtypes Gene ID types to include.
#' @param db_version Database version to retrieve.
#' @param db_update Force a refresh. `FALSE` loads the cache when available.
#' @param data_dir Directory or named list of local source files. Searches
#' `data_dir/<db>/` then `data_dir`. Named lists override a path, e.g.
#' `list(MSigDB = "~/db/msigdb")`.
#' @param convert_species Use a species-converted database when the annotation is
#' missing for `species`.
#' @param Ensembl_version Ensembl version. `NULL` uses the latest.
#' @param custom_TERM2GENE,custom_TERM2NAME Custom mappings for `custom_species`.
#' @param custom_species,custom_IDtype,custom_version Metadata for a custom database.
#' @param ... Passed to helper functions.
#'
#' @return A list containing the prepared gene annotation databases:
#' \itemize{
#'   \item `TERM2GENE`: mapping of gene identifiers to terms.
#'   \item `TERM2NAME`: mapping of terms to their names.
#'   \item `semData`: semantic similarity data for gene sets (only for Gene Ontology terms).
#' }
#'
#' @seealso [ListDB]
#'
#' @export
#'
#' @examples
#' db_list <- PrepareDB(
#'   species = "Homo_sapiens",
#'   db = "GO_BP"
#' )
#' ListDB(
#'   species = "Homo_sapiens",
#'   db = "GO_BP"
#' )
#' head(
#'   db_list[["Homo_sapiens"]][["GO_BP"]][["TERM2GENE"]]
#' )
#'
#' # Based on homologous gene conversion,
#' # prepare a gene annotation database that originally does not exist in the species.
#' db_list <- PrepareDB(
#'   species = "Homo_sapiens",
#'   db = "MP"
#' )
#' ListDB(
#'   species = "Homo_sapiens",
#'   db = "MP"
#' )
#' head(
#'   db_list[["Homo_sapiens"]][["MP"]][["TERM2GENE"]]
#' )
#'
#' # You can also build a custom database based on the gene sets you have
#' ccgenes <- CycGenePrefetch("Homo_sapiens")
#' custom_TERM2GENE <- rbind(
#'   data.frame(
#'     term = "S_genes",
#'     gene = ccgenes[["cc_S_genes"]]
#'   ),
#'   data.frame(
#'     term = "G2M_genes",
#'     gene = ccgenes[["cc_G2M_genes"]]
#'   )
#' )
#' str(custom_TERM2GENE)
#'
#' # Set convert_species = TRUE to build a custom database for both species,
#' # with the name "CellCycle"
#' db_list <- PrepareDB(
#'   species = c("Homo_sapiens", "Mus_musculus"),
#'   db = "CellCycle",
#'   convert_species = TRUE,
#'   custom_TERM2GENE = custom_TERM2GENE,
#'   custom_species = "Homo_sapiens",
#'   custom_IDtype = "symbol",
#'   custom_version = "Seurat_v5"
#' )
#' ListDB(db = "CellCycle")
#'
#' db_list <- PrepareDB(species = "Mus_musculus", db = "CellCycle")
#' head(
#'   db_list[["Mus_musculus"]][["CellCycle"]][["TERM2GENE"]]
#' )
PrepareDB <- function(
  species = c("Homo_sapiens", "Mus_musculus"),
  db = c(
    "GO",
    "GO_BP",
    "GO_CC",
    "GO_MF",
    "KEGG",
    "WikiPathway",
    "Reactome",
    "CORUM",
    "MP",
    "DO",
    "HPO",
    "PFAM",
    "CSPA",
    "Surfaceome",
    "SPRomeDB",
    "VerSeDa",
    "TFLink",
    "hTFtarget",
    "TRRUST",
    "JASPAR",
    "ENCODE",
    "MSigDB",
    "CellTalk",
    "CellChat",
    "Chromosome",
    "GeneType",
    "Enzyme",
    "TF",
    "CytoTRACE2"
  ),
  db_IDtypes = c("symbol", "entrez_id", "ensembl_id"),
  db_version = "latest",
  db_update = FALSE,
  data_dir = NULL,
  convert_species = TRUE,
  Ensembl_version = NULL,
  mirror = NULL,
  biomart = NULL,
  max_tries = 5,
  custom_TERM2GENE = NULL,
  custom_TERM2NAME = NULL,
  custom_species = NULL,
  custom_IDtype = NULL,
  custom_version = NULL,
  verbose = TRUE,
  ...
) {
  check_r("R.cache", verbose = FALSE)
  species <- normalize_species_name(species)
  db_list <- list()

  if ("CytoTRACE2" %in% db) {
    db <- setdiff(db, "CytoTRACE2")
    cyto_version <- "1.1.0"
    cyto_cache_key <- list(cyto_version, "CytoTRACE2", "CytoTRACE2")
    cyto_data_dir <- file.path(
      tools::R_user_dir("scop", "data"),
      "CytoTRACE2"
    )
    cyto_files <- c(
      "model_parameters.rds",
      "features_model_training_17.csv",
      "mt_dict_human_to_mouse.csv",
      "mt_human_alias.csv",
      "mt_mouse_alias.csv"
    )
    cyto_url <- "https://raw.githubusercontent.com/mengxu98/datasets/main/CytoTRACE2"

    if (isFALSE(db_update)) {
      cyto_cached <- R.cache::loadCache(key = cyto_cache_key)
      cyto_cached_dir <- if (!is.null(cyto_cached$data_dir)) {
        normalizePath(cyto_cached$data_dir, mustWork = FALSE)
      } else {
        NULL
      }
      cyto_data_dir_norm <- normalizePath(cyto_data_dir, mustWork = FALSE)
      if (
        !is.null(cyto_cached) &&
          identical(cyto_cached_dir, cyto_data_dir_norm) &&
          dir.exists(cyto_cached_dir) &&
          all(file.exists(file.path(cyto_cached_dir, cyto_files)))
      ) {
        log_message(
          "Loading cached: {.pkg CytoTRACE2} version: {.pkg {cyto_version}}",
          verbose = verbose
        )
        db_list[["CytoTRACE2"]] <- cyto_cached
      } else if (!is.null(cyto_cached_dir) && dir.exists(cyto_cached_dir)) {
        log_message(
          "Ignoring legacy CytoTRACE2 cache outside the datasets cache: {.path {cyto_cached_dir}}",
          verbose = verbose
        )
      }
    }

    if (is.null(db_list[["CytoTRACE2"]])) {
      log_message(
        "Preparing {.pkg CytoTRACE2} database",
        verbose = verbose
      )

      if (!dir.exists(cyto_data_dir) ||
        !all(file.exists(file.path(cyto_data_dir, cyto_files))) ||
        isTRUE(db_update)) {
        log_message(
          "Downloading CytoTRACE2 model data from datasets GitHub repository...",
          verbose = verbose
        )
        dir.create(cyto_data_dir, showWarnings = FALSE, recursive = TRUE)
        old_timeout <- getOption("timeout")
        options(timeout = max(600, old_timeout))
        on.exit(options(timeout = old_timeout), add = TRUE)
        for (fname in cyto_files) {
          url <- paste0(cyto_url, "/", fname)
          dest <- file.path(cyto_data_dir, fname)
          log_message(
            "  Downloading {.path {fname}} ...",
            verbose = verbose
          )
          utils::download.file(
            url = url,
            destfile = dest,
            mode = "wb",
            quiet = !verbose
          )
        }
        log_message(
          "CytoTRACE2 data cached at {.path {cyto_data_dir}}",
          message_type = "success",
          verbose = verbose
        )
      } else {
        log_message(
          "Using cached CytoTRACE2 data from {.path {cyto_data_dir}}",
          verbose = verbose
        )
      }

      cyto_cache <- list(
        data_dir = cyto_data_dir,
        files = cyto_files,
        version = cyto_version
      )
      R.cache::saveCache(
        cyto_cache,
        key = cyto_cache_key,
        comment = paste0(
          cyto_version,
          " nterm:",
          length(cyto_files),
          "|CytoTRACE2-CytoTRACE2"
        )
      )
      db_list[["CytoTRACE2"]] <- cyto_cache
    }
  }

  if (!is.null(db)) {
    db <- as.character(db)
  }
  db_requested <- db
  db <- normalize_msigdb_db_names(db)

  for (sps in species) {
    log_message(
      "Species: {.val {sps}}",
      verbose = verbose
    )
    default_id_types <- list(
      "GO" = "entrez_id",
      "GO_BP" = "entrez_id",
      "GO_CC" = "entrez_id",
      "GO_MF" = "entrez_id",
      "KEGG" = "entrez_id",
      "WikiPathway" = "entrez_id",
      "Reactome" = "entrez_id",
      "CORUM" = "symbol",
      "MP" = "symbol",
      "DO" = "symbol",
      "HPO" = "symbol",
      "PFAM" = "entrez_id",
      "Chromosome" = "entrez_id",
      "GeneType" = "entrez_id",
      "Enzyme" = "entrez_id",
      "TF" = "symbol",
      "CSPA" = "symbol",
      "Surfaceome" = "symbol",
      "SPRomeDB" = "entrez_id",
      "VerSeDa" = "symbol",
      "TFLink" = "symbol",
      "hTFtarget" = "symbol",
      "TRRUST" = "symbol",
      "JASPAR" = "symbol",
      "ENCODE" = "symbol",
      "MSigDB" = "symbol",
      "CellTalk" = "symbol",
      "CellChat" = "symbol"
    )
    if (!is.null(custom_TERM2GENE)) {
      if (length(db) > 1) {
        log_message(
          "When building a custom database, the length of {.arg db} must be 1",
          message_type = "error"
        )
      }
      if (is.null(custom_IDtype) || is.null(custom_species) || is.null(custom_version)) {
        log_message(
          "When building a custom database, {.arg custom_IDtype}, {.arg custom_species} and {.arg custom_version} must be provided",
          message_type = "error"
        )
      }
      custom_IDtype <- match.arg(
        custom_IDtype,
        choices = c("symbol", "entrez_id", "ensembl_id")
      )
      default_id_types[[db]] <- custom_IDtype
    }

    if (isFALSE(db_update) && is.null(custom_TERM2GENE)) {
      for (term in db) {
        dbinfo <- list_db_cache_entries(species = sps, db = term)
        if (nrow(dbinfo) > 0 && !is.null(dbinfo)) {
          if (db_version == "latest") {
            pathname <- dbinfo[
              order(dbinfo[["timestamp"]], decreasing = TRUE)[1],
              "file"
            ]
          } else {
            pathname <- dbinfo[
              grep(db_version, dbinfo[["db_version"]], fixed = TRUE)[1],
              "file"
            ]
            if (is.na(pathname)) {
              log_message(
                "There is no {.val {db_version}} version of the database. Use the latest version",
                message_type = "warning",
                verbose = verbose
              )
              pathname <- dbinfo[
                order(dbinfo[["timestamp"]], decreasing = TRUE)[1],
                "file"
              ]
            }
          }
          if (!is.na(pathname)) {
            header <- R.cache::readCacheHeader(pathname)
            cached_version <- strsplit(header[["comment"]], "\\|")[[1]][1]
            timestamp <- format(header[["timestamp"]], "%Y-%m-%d %H:%M:%S")
            log_message(
              "Loading cached: {.pkg {term}} version: {.pkg {cached_version}} created: {.pkg {timestamp}}",
              verbose = verbose
            )
            db_loaded <- R.cache::loadCache(pathname = pathname)
            Sys.sleep(0.5)
            db_list[[sps]][[term]] <- db_loaded
          }
        }
      }
    }

    db_species <- stats::setNames(object = rep(sps, length(db)), nm = db)
    if (any(grepl("^MSigDB($|_)", db)) && !"MSigDB" %in% names(db_species)) {
      db_species["MSigDB"] <- sps
    }

    sp <- unlist(strsplit(sps, split = "_"))
    org_sp <- paste0(
      "org.",
      paste0(substring(sp, 1, 1), collapse = ""),
      ".eg.db"
    )
    org_key <- "ENTREZID"
    if (sps == "Arabidopsis_thaliana") {
      biomart <- "plants_mart"
      org_sp <- "org.At.tair.db"
      org_key <- "TAIR"
      default_id_types[c(
        "GO",
        "GO_BP",
        "GO_CC",
        "GO_MF",
        "PFAM",
        "Chromosome",
        "GeneType",
        "Enzyme"
      )] <- "tair_locus"
    }
    if (sps == "Saccharomyces_cerevisiae") {
      org_sp <- "org.Sc.sgd.db"
    }

    if (any(!sps %in% names(db_list)) || any(!db %in% names(db_list[[sps]]))) {
      orgdb_dependent <- c(
        "GO",
        "GO_BP",
        "GO_CC",
        "GO_MF",
        "PFAM",
        "Chromosome",
        "GeneType",
        "Enzyme"
      )
      if (any(orgdb_dependent %in% db)) {
        check_r(c(org_sp, "GO.db", "GOSemSim"), verbose = FALSE)
        if (!isTRUE(all(unlist(check_r(org_sp, install = FALSE, verbose = FALSE), use.names = FALSE)))) {
          log_message(
            "Annotation package {.pkg {org_sp}} is not installed. Install it with {.code BiocManager::install('{org_sp}')}.",
            message_type = "warning"
          )
          if (isTRUE(convert_species)) {
            db_to_convert <- intersect(db, orgdb_dependent)
            log_message(
              "Use the human annotation to create the {.pkg {db_to_convert}} database for {.val {sps}}",
              message_type = "warning"
            )
            org_sp <- "org.Hs.eg.db"
            db_species[db_to_convert] <- "Homo_sapiens"
          } else {
            log_message(
              "Stop the preparation",
              message_type = "error"
            )
            log_message(
              "Required annotation package is not available: ",
              org_sp,
              message_type = "error"
            )
          }
        }
        check_r(org_sp, verbose = FALSE)
        orgdb <- get_namespace_fun(org_sp, org_sp)
      }
      if ("PFAM" %in% db) {
        check_r("PFAM.db", verbose = FALSE)
      }
      if ("Reactome" %in% db) {
        check_r("reactome.db", verbose = FALSE)
      }

      if (is.null(custom_TERM2GENE)) {
        go_categories <- c("GO", "GO_BP", "GO_CC", "GO_MF")
        if (any(db %in% go_categories) &&
          any(!intersect(db, go_categories) %in% names(db_list[[sps]]))
        ) {
          terms <- db[db %in% go_categories]
          bg <- suppressMessages(
            AnnotationDbi::select(
              orgdb,
              keys = AnnotationDbi::keys(orgdb),
              columns = c("GOALL", org_key)
            )
          )
          bg <- unique(bg[
            !is.na(bg[["GOALL"]]),
            c("GOALL", "ONTOLOGYALL", org_key),
            drop = FALSE
          ])
          go_db <- get_namespace_fun("GO.db", "GO.db")
          bg2 <- suppressMessages(
            AnnotationDbi::select(
              go_db,
              keys = AnnotationDbi::keys(go_db),
              columns = c("GOID", "TERM")
            )
          )
          bg <- merge(
            x = bg,
            by.x = "GOALL",
            y = bg2,
            by.y = "GOID",
            all.x = TRUE
          )
          for (subterm in terms) {
            log_message("Preparing database: {.pkg {subterm}}", verbose = verbose)
            if (subterm == "GO") {
              TERM2GENE <- bg[, c("GOALL", org_key)]
              TERM2NAME <- bg[, c("GOALL", "TERM")]
              colnames(TERM2GENE) <- c("Term", default_id_types[[subterm]])
              colnames(TERM2NAME) <- c("Term", "Name")
              TERM2NAME[["ONTOLOGY"]] <- bg[["ONTOLOGYALL"]]
              semData <- NULL
            } else {
              simpleterm <- unlist(strsplit(subterm, split = "_"))[2]
              TERM2GENE <- bg[
                which(bg[["ONTOLOGYALL"]] %in% simpleterm),
                c("GOALL", org_key)
              ]
              TERM2NAME <- bg[
                which(bg[["ONTOLOGYALL"]] %in% simpleterm),
                c("GOALL", "TERM")
              ]
              colnames(TERM2GENE) <- c("Term", default_id_types[[subterm]])
              colnames(TERM2NAME) <- c("Term", "Name")
              TERM2NAME[["ONTOLOGY"]] <- simpleterm
              godata_args <- list(ont = simpleterm)
              if ("annoDb" %in% names(formals(GOSemSim::godata))) {
                godata_args[["annoDb"]] <- orgdb
              } else {
                godata_args[["OrgDb"]] <- orgdb
              }
              semData <- suppressMessages(
                do.call(GOSemSim::godata, godata_args)
              )
            }
            TERM2GENE <- stats::na.omit(unique(TERM2GENE))
            TERM2NAME <- stats::na.omit(unique(TERM2NAME))
            version <- utils::packageVersion(org_sp)
            db_list[[db_species[subterm]]][[subterm]][[
              "TERM2GENE"
            ]] <- TERM2GENE
            db_list[[db_species[subterm]]][[subterm]][[
              "TERM2NAME"
            ]] <- TERM2NAME
            db_list[[db_species[subterm]]][[subterm]][["semData"]] <- semData
            db_list[[db_species[subterm]]][[subterm]][["version"]] <- version
            if (sps == db_species[subterm]) {
              R.cache::saveCache(
                db_list[[db_species[subterm]]][[subterm]],
                key = list(version, as.character(db_species[subterm]), subterm),
                comment = paste0(
                  version,
                  " nterm:",
                  length(TERM2NAME[[1]]),
                  "|",
                  db_species[subterm],
                  "-",
                  subterm
                )
              )
            }
          }
        }

        if (any(db == "KEGG") && (!"KEGG" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg KEGG} database", verbose = verbose)
          check_r("httr", verbose = FALSE)
          orgs <- kegg_get("https://rest.kegg.jp/list/genome")
          orgs_parsed <- strsplit(orgs[, 2], "; ")
          orgs_code <- vapply(orgs_parsed, `[`, "", 1)
          orgs_species <- vapply(orgs_parsed, `[`, "", 2)
          kegg_sp <- orgs_code[
            grep(gsub(pattern = "_", replacement = " ", x = sps), orgs_species)
          ]
          if (length(kegg_sp) == 0) {
            db_species_name <- db_species["KEGG"]
            log_message(
              "Failed to prepare the KEGG database for {.val {db_species_name}}",
              message_type = "warning",
              verbose = verbose
            )
            if (isTRUE(convert_species) && db_species_name != "Homo_sapiens") {
              log_message(
                "Use the human annotation to create the KEGG database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["KEGG"] <- "Homo_sapiens"
              kegg_sp <- "hsa"
              return(NULL)
            } else {
              log_message(
                "Stop the preparation",
                message_type = "error"
              )
            }
          }
          kegg_db <- "pathway"

          kegg_pathwaygene_url <- paste0(
            "https://rest.kegg.jp/link/",
            kegg_sp,
            "/",
            kegg_db,
            collapse = ""
          )
          TERM2GENE <- kegg_get(kegg_pathwaygene_url)
          colnames(TERM2GENE) <- c("Pathway", "KEGG_ID")
          kegg_geneconversion_url <- paste0(
            "https://rest.kegg.jp/conv/ncbi-geneid/",
            kegg_sp
          )
          GENECONV <- kegg_get(kegg_geneconversion_url)
          colnames(GENECONV) <- c("KEGG_ID", "ENTREZID")
          TERM2GENE <- merge(
            x = TERM2GENE,
            y = GENECONV,
            by = "KEGG_ID",
            all.x = TRUE
          )
          TERM2GENE[, "Pathway"] <- gsub(
            pattern = "[^:]+:",
            replacement = "",
            x = TERM2GENE[, "Pathway"]
          )
          TERM2GENE[, "ENTREZID"] <- gsub(
            pattern = "[^:]+:",
            replacement = "",
            x = TERM2GENE[, "ENTREZID"]
          )
          TERM2GENE <- TERM2GENE[, c("Pathway", "ENTREZID")]

          kegg_pathwayname_url <- paste0(
            "https://rest.kegg.jp/list/",
            kegg_db,
            "/",
            kegg_sp,
            collapse = ""
          )
          TERM2NAME <- kegg_get(kegg_pathwayname_url)
          colnames(TERM2NAME) <- c("Pathway", "Name")
          TERM2NAME[, "Pathway"] <- gsub(
            pattern = "[^:]+:",
            replacement = "",
            x = TERM2NAME[, "Pathway"]
          )
          TERM2NAME[, "Name"] <- gsub(
            pattern = paste0(
              " - ",
              paste0(
                unlist(strsplit(db_species["KEGG"], split = "_")),
                collapse = " "
              ),
              ".*$"
            ),
            replacement = "",
            x = TERM2NAME[, "Name"]
          )
          TERM2NAME <- TERM2NAME[
            TERM2NAME[, "Pathway"] %in% TERM2GENE[, "Pathway"], ,
            drop = FALSE
          ]

          colnames(TERM2GENE) <- c("Term", default_id_types[["KEGG"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          kegg_info <- strsplit(
            httr::content(httr::GET(paste0(
              "https://rest.kegg.jp/info/",
              kegg_sp
            ))),
            split = "\n"
          )[[1]]
          version <- kegg_release_version(kegg_info)
          db_list[[db_species["KEGG"]]][["KEGG"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["KEGG"]]][["KEGG"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["KEGG"]]][["KEGG"]][["version"]] <- version
          if (sps == db_species["KEGG"]) {
            R.cache::saveCache(
              db_list[[db_species["KEGG"]]][["KEGG"]],
              key = list(version, as.character(db_species["KEGG"]), "KEGG"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["KEGG"],
                "-KEGG"
              )
            )
          }
        }

        if (
          any(db == "WikiPathway") &&
            (!"WikiPathway" %in% names(db_list[[sps]]))
        ) {
          log_message("Preparing {.pkg WikiPathway} database", verbose = verbose)
          tempdir <- tempdir()
          gmt_files <- list.files(tempdir)[grep(
            ".gmt",
            x = list.files(tempdir)
          )]
          if (length(gmt_files) > 0) {
            file.remove(paste0(tempdir, "/", gmt_files))
          }
          temp <- tempfile()
          wiki_source_url <- if (is.null(mirror)) {
            "https://data.wikipathways.org/current/gmt"
          } else {
            mirror
          }
          wiki_source_url <- sub("/+$", "", wiki_source_url)
          wiki_file_url <- NULL
          download(
            url = wiki_source_url,
            destfile = temp
          )
          lines <- paste0(readLines(temp, warn = FALSE), collapse = " ")
          gmtfiles <- unlist(regmatches(
            lines,
            m = gregexpr(
              "wikipathways-[^\"'<>[:space:]]+\\.gmt\\b",
              lines,
              perl = TRUE
            )
          ))
          gmtfiles <- unique(gmtfiles)
          if (
            length(gmtfiles) == 0 &&
              identical(
                wiki_source_url,
                "https://wikipathways-data.wmcloud.org/current/gmt"
              )
          ) {
            wiki_source_url <- "https://data.wikipathways.org/current/gmt"
            download(
              url = wiki_source_url,
              destfile = temp
            )
            lines <- paste0(readLines(temp, warn = FALSE), collapse = " ")
            gmtfiles <- unlist(regmatches(
              lines,
              m = gregexpr(
                "wikipathways-[^\"'<>[:space:]]+\\.gmt\\b",
                lines,
                perl = TRUE
              )
            ))
            gmtfiles <- unique(gmtfiles)
          }
          if (
            length(gmtfiles) == 0 &&
              grepl("\\.gmt([?#].*)?$", wiki_source_url, ignore.case = TRUE)
          ) {
            wiki_file_url <- sub("[?#].*$", "", wiki_source_url)
            gmtfiles <- basename(wiki_file_url)
          }
          wiki_sp <- sps
          gmtfile <- gmtfiles[grep(wiki_sp, gmtfiles, fixed = TRUE)]
          if (length(gmtfile) == 0) {
            db_species_name <- db_species["WikiPathway"]
            log_message(
              "Failed to prepare the WikiPathway database for {.val {db_species_name}}",
              message_type = "warning",
              verbose = verbose
            )
            if (isTRUE(convert_species) && db_species_name != "Homo_sapiens") {
              log_message(
                "Use the human annotation to create the WikiPathway database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["WikiPathway"] <- "Homo_sapiens"
              wiki_sp <- "Homo_sapiens"
              gmtfile <- gmtfiles[grep(wiki_sp, gmtfiles, fixed = TRUE)]
            } else {
              log_message(
                "Stop the preparation",
                message_type = "error"
              )
            }
          }
          if (length(gmtfile) == 0) {
            log_message(
              c(
                "No {.pkg WikiPathway} GMT file is available for {.val {wiki_sp}}",
                "Check whether {.arg mirror} points to a GMT file or a directory index"
              ),
              message_type = "error"
            )
          }
          gmtfile <- gmtfile[[1]]
          version_parts <- strsplit(gmtfile, split = "-", fixed = TRUE)[[1]]
          version <- if (length(version_parts) >= 2) {
            version_parts[[2]]
          } else {
            tools::file_path_sans_ext(gmtfile)
          }
          if (is.null(wiki_file_url)) {
            wiki_file_url <- paste0(wiki_source_url, "/", gmtfile)
          }
          download(
            url = wiki_file_url,
            destfile = temp
          )
          wiki_gmt <- clusterProfiler::read.gmt(temp)
          unlink(temp)
          wiki_gmt <- apply(wiki_gmt, 1, function(x) {
            wikiid <- strsplit(x[["term"]], split = "%")[[1]][3]
            wikiterm <- strsplit(x[["term"]], split = "%")[[1]][1]
            gmt <- x[["gene"]]
            data.frame(
              v0 = wikiid,
              v1 = gmt,
              v2 = wikiterm,
              stringsAsFactors = FALSE
            )
          })
          bg <- do.call(rbind.data.frame, wiki_gmt)
          TERM2GENE <- bg[, c(1, 2)]
          TERM2NAME <- bg[, c(1, 3)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["WikiPathway"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["WikiPathway"]]][["WikiPathway"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["WikiPathway"]]][["WikiPathway"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["WikiPathway"]]][["WikiPathway"]][[
            "version"
          ]] <- version
          if (sps == db_species["WikiPathway"]) {
            R.cache::saveCache(
              db_list[[db_species["WikiPathway"]]][["WikiPathway"]],
              key = list(
                version,
                as.character(db_species["WikiPathway"]),
                "WikiPathway"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["WikiPathway"],
                "-WikiPathway"
              )
            )
          }
        }

        if (any(db == "Reactome") && (!"Reactome" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg Reactome} database", verbose = verbose)
          reactome_sp <- gsub(pattern = "_", replacement = " ", x = sps)
          reactome_db <- get_namespace_fun("reactome.db", "reactome.db")
          df_all <- suppressMessages(
            AnnotationDbi::select(
              reactome_db,
              keys = AnnotationDbi::keys(reactome_db),
              columns = c("PATHID", "PATHNAME")
            )
          )
          df <- df_all[
            grepl(
              pattern = paste0("^", reactome_sp, ": "),
              x = df_all$PATHNAME
            ), ,
            drop = FALSE
          ]
          if (nrow(df) == 0) {
            if (
              isTRUE(convert_species) &&
                db_species["Reactome"] != "Homo_sapiens"
            ) {
              log_message(
                "Use the human annotation to create the Reactome database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["Reactome"] <- "Homo_sapiens"
              reactome_sp <- gsub(
                pattern = "_",
                replacement = " ",
                x = "Homo_sapiens"
              )
              df <- df_all[
                grepl(
                  pattern = paste0("^", reactome_sp, ": "),
                  x = df_all$PATHNAME
                ), ,
                drop = FALSE
              ]
            } else {
              log_message(
                "Stop the preparation",
                message_type = "error"
              )
            }
          }
          df <- stats::na.omit(df)
          df$PATHNAME <- gsub(
            x = df$PATHNAME,
            pattern = paste0("^", reactome_sp, ": "),
            replacement = "",
            perl = TRUE
          )
          TERM2GENE <- df[, c(2, 1)]
          TERM2NAME <- df[, c(2, 3)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["Reactome"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- utils::packageVersion("reactome.db")
          db_list[[db_species["Reactome"]]][["Reactome"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["Reactome"]]][["Reactome"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["Reactome"]]][["Reactome"]][[
            "version"
          ]] <- version
          if (sps == db_species["Reactome"]) {
            R.cache::saveCache(
              db_list[[db_species["Reactome"]]][["Reactome"]],
              key = list(
                version,
                as.character(db_species["Reactome"]),
                "Reactome"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["Reactome"],
                "-Reactome"
              )
            )
          }
        }

        if (any(db == "CORUM") && (!"CORUM" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the {.pkg CORUM} database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["CORUM"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg CORUM} database only support Homo_sapiens. Consider using convert_species=TRUE",
                message_type = "warning",
                verbose = verbose
              )
              log_message(
                "Stop the preparation",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg CORUM} database", verbose = verbose)
          url <- "https://maayanlab.cloud/static/hdfs/harmonizome/data/corum/gene_set_library_crisp.gmt.gz"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "CORUM",
            pattern = "^gene_set_library_crisp\\.gmt(\\.gz)?$",
            verbose = verbose
          )
          if (is.null(source_file)) {
            temp <- tempfile(fileext = ".gz")
            download(url = url, destfile = temp)
            R.utils::gunzip(temp)
            source_file <- gsub(".gz", "", temp)
          }
          TERM2GENE <- preparedb_read_gmt_source(source_file)
          version <- "Harmonizome 3.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["CORUM"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["CORUM"]]][["CORUM"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["CORUM"]]][["CORUM"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["CORUM"]]][["CORUM"]][["version"]] <- version
          if (sps == db_species["CORUM"]) {
            R.cache::saveCache(
              db_list[[db_species["CORUM"]]][["CORUM"]],
              key = list(version, as.character(db_species["CORUM"]), "CORUM"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["CORUM"],
                "-CORUM"
              )
            )
          }
        }

        if (any(db == "MP") && (!"MP" %in% names(db_list[[sps]]))) {
          if (sps != "Mus_musculus") {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the mouse annotation to create the MP database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["MP"] <- "Mus_musculus"
            } else {
              log_message(
                "{.pkg MP} database only support {.val Mus_musculus}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg MP} database", verbose = verbose)
          temp <- tempfile()
          version <- as.character(Sys.Date())
          download(
            url = "https://www.informatics.jax.org/downloads/reports/VOC_MammalianPhenotype.rpt",
            destfile = temp
          )
          mp_name <- utils::read.table(
            temp,
            header = FALSE,
            sep = "\t",
            fill = TRUE,
            quote = ""
          )
          rownames(mp_name) <- mp_name[, 1]
          download(
            url = "https://www.informatics.jax.org/downloads/reports/MGI_Gene_Model_Coord.rpt",
            destfile = temp
          )
          gene_id <- utils::read.table(
            temp,
            header = FALSE,
            row.names = NULL,
            sep = "\t",
            fill = TRUE,
            quote = ""
          )
          gene_id <- gene_id[, 1:15]
          colnames(gene_id) <- gene_id[1, ]
          gene_id <- gene_id[
            gene_id[, 2] %in% c("Gene", "Pseudogene"), ,
            drop = FALSE
          ]
          rownames(gene_id) <- gene_id[, 1]

          download(
            url = "https://www.informatics.jax.org/downloads/reports/MGI_GenePheno.rpt",
            destfile = temp
          )
          mp_gene <- utils::read.table(
            temp,
            header = FALSE,
            sep = "\t",
            fill = TRUE,
            quote = ""
          )
          mp_gene[["symbol"]] <- gene_id[mp_gene[["V7"]], "3. marker symbol"]
          mp_gene[["MP"]] <- mp_name[mp_gene[, "V5"], 2]
          TERM2GENE <- mp_gene[, c("V5", "symbol")]
          TERM2NAME <- mp_gene[, c("V5", "MP")]

          colnames(TERM2GENE) <- c("Term", default_id_types[["MP"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["MP"]]][["MP"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["MP"]]][["MP"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["MP"]]][["MP"]][["version"]] <- version
          if (sps == db_species["MP"]) {
            R.cache::saveCache(
              db_list[[db_species["MP"]]][["MP"]],
              key = list(version, as.character(db_species["MP"]), "MP"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["MP"],
                "-MP"
              )
            )
          }
        }

        if (any(db == "DO") && (!"DO" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg DO} database", verbose = verbose)
          temp <- tempfile(fileext = ".tsv.gz")
          download(
            url = "https://fms.alliancegenome.org/download/DISEASE-ALLIANCE_COMBINED.tsv.gz",
            destfile = temp
          )
          R.utils::gunzip(temp)
          do_all <- utils::read.table(
            gsub(".gz", "", temp),
            header = TRUE,
            sep = "\t",
            fill = TRUE,
            quote = ""
          )
          version <- gsub(
            pattern = ".*Alliance Database Version: ",
            replacement = "",
            x = grep(
              "Alliance Database Version",
              readLines(gsub(".gz", "", temp), warn = FALSE),
              perl = TRUE,
              value = TRUE
            )
          )
          unlink(temp)
          do_sp <- gsub(pattern = "_", replacement = " ", x = sps)
          do_df <- do_all[
            do_all[["DBobjectType"]] == "gene" &
              do_all[["SpeciesName"]] == do_sp, ,
            drop = FALSE
          ]
          if (nrow(do_df) == 0) {
            if (isTRUE(convert_species) && db_species["DO"] != "Homo_sapiens") {
              log_message(
                "Use the human annotation to create the DO database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["DO"] <- "Homo_sapiens"
              do_sp <- gsub(
                pattern = "_",
                replacement = " ",
                x = "Homo_sapiens"
              )
              do_df <- do_all[
                do_all[["DBobjectType"]] == "gene" &
                  do_all[["SpeciesName"]] == do_sp, ,
                drop = FALSE
              ]
            } else {
              log_message(
                "Stop the preparation",
                message_type = "error"
              )
            }
          }
          TERM2GENE <- do_df[, c("DOID", "DBObjectSymbol")]
          TERM2NAME <- do_df[, c("DOID", "DOtermName")]
          colnames(TERM2GENE) <- c("Term", default_id_types[["DO"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["DO"]]][["DO"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["DO"]]][["DO"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["DO"]]][["DO"]][["version"]] <- version
          if (sps == db_species["DO"]) {
            R.cache::saveCache(
              db_list[[db_species["DO"]]][["DO"]],
              key = list(version, as.character(db_species["DO"]), "DO"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["DO"],
                "-DO"
              )
            )
          }
        }

        if (any(db == "HPO") && (!"HPO" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg HPO} database", verbose = verbose)
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the HPO database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["HPO"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg HPO} database only support {.val Homo_sapiens}. Consider using {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          temp <- tempfile()
          download(
            url = "https://api.github.com/repos/obophenotype/human-phenotype-ontology/releases?per_page=1",
            destfile = temp
          )
          release <- readLines(temp, warn = FALSE)
          release_tag <- regmatches(
            release,
            m = regexpr(
              "(?<=tag_name\\\":\\\")\\S+(?=\\\",\\\"target_commitish)",
              release,
              perl = T
            )
          )
          version <- if (length(release_tag) > 0) {
            release_tag
          } else {
            paste0("Retrieved ", Sys.Date())
          }

          download(
            url = "http://purl.obolibrary.org/obo/hp/hpoa/phenotype_to_genes.txt",
            destfile = temp
          )
          hpo <- utils::read.table(
            temp,
            header = TRUE,
            sep = "\t",
            fill = TRUE,
            quote = ""
          )
          unlink(temp)

          TERM2GENE <- hpo[, c("hpo_id", "gene_symbol")]
          TERM2NAME <- hpo[, c("hpo_id", "hpo_name")]
          colnames(TERM2GENE) <- c("Term", default_id_types[["HPO"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["HPO"]]][["HPO"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["HPO"]]][["HPO"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["HPO"]]][["HPO"]][["version"]] <- version
          if (sps == db_species["HPO"]) {
            R.cache::saveCache(
              db_list[[db_species["HPO"]]][["HPO"]],
              key = list(version, as.character(db_species["HPO"]), "HPO"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["HPO"],
                "-HPO"
              )
            )
          }
        }

        if (any(db == "PFAM") && (!"PFAM" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg PFAM} database", verbose = verbose)
          if (!"PFAM" %in% AnnotationDbi::columns(orgdb)) {
            log_message(
              "{.pkg PFAM} is not in the orgdb: {.val {orgdb}}. Skip this preparation",
              message_type = "warning",
              verbose = verbose
            )
          } else {
            bg <- suppressMessages(
              AnnotationDbi::select(
                orgdb,
                keys = AnnotationDbi::keys(orgdb),
                columns = c("PFAM", org_key)
              )
            )
            bg <- unique(bg[!is.na(bg$PFAM), c("PFAM", org_key), drop = FALSE])
            pfam_de2ac <- get_namespace_fun("PFAM.db", "PFAMDE2AC")
            bg2 <- as.data.frame(
              pfam_de2ac[AnnotationDbi::mappedkeys(pfam_de2ac)]
            )
            rownames(bg2) <- bg2[["ac"]]
            bg[["PFAM_name"]] <- bg2[bg$PFAM, "de"]
            bg[is.na(bg[["PFAM_name"]]), "PFAM_name"] <- bg[
              is.na(bg[["PFAM_name"]]),
              "PFAM"
            ]
            TERM2GENE <- bg[, c("PFAM", org_key)]
            TERM2NAME <- bg[, c("PFAM", "PFAM_name")]
            colnames(TERM2GENE) <- c("Term", default_id_types[["PFAM"]])
            colnames(TERM2NAME) <- c("Term", "Name")
            TERM2GENE <- stats::na.omit(unique(TERM2GENE))
            TERM2NAME <- stats::na.omit(unique(TERM2NAME))
            version <- utils::packageVersion(org_sp)
            db_list[[db_species["PFAM"]]][["PFAM"]][["TERM2GENE"]] <- TERM2GENE
            db_list[[db_species["PFAM"]]][["PFAM"]][["TERM2NAME"]] <- TERM2NAME
            db_list[[db_species["PFAM"]]][["PFAM"]][["version"]] <- version
            if (sps == db_species["PFAM"]) {
              R.cache::saveCache(
                db_list[[db_species["PFAM"]]][["PFAM"]],
                key = list(version, as.character(db_species["PFAM"]), "PFAM"),
                comment = paste0(
                  version,
                  " nterm:",
                  length(TERM2NAME[[1]]),
                  "|",
                  db_species["PFAM"],
                  "-PFAM"
                )
              )
            }
          }
        }

        if (
          any(db == "Chromosome") && (!"Chromosome" %in% names(db_list[[sps]]))
        ) {
          log_message("Preparing {.pkg Chromosome} database", verbose = verbose)
          orgdbCHR <- get(
            paste0(gsub(pattern = ".db", "", org_sp), "CHR")
          )
          chr <- as.data.frame(
            orgdbCHR[AnnotationDbi::mappedkeys(orgdbCHR)]
          )
          chr[, 2] <- paste0("chr", chr[, 2])
          TERM2GENE <- chr[, c(2, 1)]
          TERM2NAME <- chr[, c(2, 2)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["Chromosome"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- utils::packageVersion(org_sp)
          db_list[[db_species["Chromosome"]]][["Chromosome"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["Chromosome"]]][["Chromosome"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["Chromosome"]]][["Chromosome"]][[
            "version"
          ]] <- version
          if (sps == db_species["Chromosome"]) {
            R.cache::saveCache(
              db_list[[db_species["Chromosome"]]][["Chromosome"]],
              key = list(
                version,
                as.character(db_species["Chromosome"]),
                "Chromosome"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["Chromosome"],
                "-Chromosome"
              )
            )
          }
        }

        if (any(db == "GeneType") && (!"GeneType" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg GeneType} database", verbose = verbose)
          if (!"GENETYPE" %in% AnnotationDbi::columns(orgdb)) {
            log_message(
              "GENETYPE is not in the orgdb: {.val {org_sp}}. Skip this preparation",
              message_type = "warning",
              verbose = verbose
            )
          } else {
            bg <- suppressMessages(
              AnnotationDbi::select(
                orgdb,
                keys = AnnotationDbi::keys(orgdb),
                columns = c("GENETYPE", org_key)
              )
            )
            TERM2GENE <- bg[, c("GENETYPE", org_key)]
            TERM2NAME <- bg[, c("GENETYPE", "GENETYPE")]
            colnames(TERM2GENE) <- c("Term", default_id_types[["GeneType"]])
            colnames(TERM2NAME) <- c("Term", "Name")
            TERM2GENE <- stats::na.omit(unique(TERM2GENE))
            TERM2NAME <- stats::na.omit(unique(TERM2NAME))
            version <- utils::packageVersion(org_sp)
            db_list[[db_species["GeneType"]]][["GeneType"]][[
              "TERM2GENE"
            ]] <- TERM2GENE
            db_list[[db_species["GeneType"]]][["GeneType"]][[
              "TERM2NAME"
            ]] <- TERM2NAME
            db_list[[db_species["GeneType"]]][["GeneType"]][[
              "version"
            ]] <- version
            if (sps == db_species["GeneType"]) {
              R.cache::saveCache(
                db_list[[db_species["GeneType"]]][["GeneType"]],
                key = list(
                  version,
                  as.character(db_species["GeneType"]),
                  "GeneType"
                ),
                comment = paste0(
                  version,
                  " nterm:",
                  length(TERM2NAME[[1]]),
                  "|",
                  db_species["GeneType"],
                  "-GeneType"
                )
              )
            }
          }
        }

        if (any(db == "Enzyme") && (!"Enzyme" %in% names(db_list[[sps]]))) {
          log_message("Preparing {.pkg Enzyme} database", verbose = verbose)
          if (!"ENZYME" %in% AnnotationDbi::columns(orgdb)) {
            log_message(
              "ENZYME is not in the orgdb: {.val {orgdb}}. Skip this preparation",
              message_type = "warning",
              verbose = verbose
            )
          } else {
            bg <- suppressMessages(
              AnnotationDbi::select(
                orgdb,
                keys = AnnotationDbi::keys(orgdb),
                columns = c("ENZYME", org_key)
              )
            )
            bg1 <- bg2 <- stats::na.omit(bg)
            bg1[, "ENZYME"] <- sapply(
              strsplit(bg1[, "ENZYME"], "\\."),
              function(x) paste0(utils::head(x, 1), collapse = ".")
            )
            bg2[, "ENZYME"] <- sapply(
              strsplit(bg2[, "ENZYME"], "\\."),
              function(x) paste0(utils::head(x, 2), collapse = ".")
            )
            bg <- unique(rbind(bg1, bg2))
            bg[, "ENZYME"] <- gsub(pattern = "\\.-$", "", x = bg[, 2])
            bg[, "ENZYME"] <- paste0("ec:", bg[, "ENZYME"])
            temp <- tempfile()
            download(
              url = "https://ftp.expasy.org/databases/enzyme/enzclass.txt",
              destfile = temp
            )
            enzyme <- utils::read.table(
              temp,
              header = FALSE,
              sep = "\t",
              fill = TRUE,
              quote = ""
            )
            enzyme <- enzyme[
              grep("-.-", enzyme[, 1], fixed = TRUE), ,
              drop = FALSE
            ]
            enzyme <- do.call(rbind, strsplit(enzyme[, 1], split = ". -.-  "))
            enzyme[, 1] <- paste0(
              "ec:",
              gsub(pattern = "( )|(. -)", replacement = "", enzyme[, 1])
            )
            enzyme[, 2] <- gsub(
              pattern = "(^ )|(\\.$)",
              replacement = "",
              enzyme[, 2]
            )
            rownames(enzyme) <- enzyme[, 1]
            for (i in seq_len(nrow(enzyme))) {
              if (grepl(".", enzyme[i, 1], fixed = TRUE)) {
                enzyme[i, 2] <- paste0(
                  enzyme[strsplit(enzyme[i, 1], ".", fixed = TRUE)[[1]][1], 2],
                  "(",
                  enzyme[i, 2],
                  ")"
                )
              }
            }
            unlink(temp)
            bg[, "Name"] <- enzyme[bg[, "ENZYME"], 2]
            TERM2GENE <- bg[, c("ENZYME", org_key)]
            TERM2NAME <- bg[, c("ENZYME", "Name")]
            colnames(TERM2GENE) <- c("Term", default_id_types[["Enzyme"]])
            colnames(TERM2NAME) <- c("Term", "Name")
            TERM2GENE <- stats::na.omit(unique(TERM2GENE))
            TERM2NAME <- stats::na.omit(unique(TERM2NAME))
            version <- utils::packageVersion(org_sp)
            db_list[[db_species["Enzyme"]]][["Enzyme"]][[
              "TERM2GENE"
            ]] <- TERM2GENE
            db_list[[db_species["Enzyme"]]][["Enzyme"]][[
              "TERM2NAME"
            ]] <- TERM2NAME
            db_list[[db_species["Enzyme"]]][["Enzyme"]][["version"]] <- version
            if (sps == db_species["Enzyme"]) {
              R.cache::saveCache(
                db_list[[db_species["Enzyme"]]][["Enzyme"]],
                key = list(
                  version,
                  as.character(db_species["Enzyme"]),
                  "Enzyme"
                ),
                comment = paste0(
                  version,
                  " nterm:",
                  length(TERM2NAME[[1]]),
                  "|",
                  db_species["Enzyme"],
                  "-Enzyme"
                )
              )
            }
          }
        }

        if (any(db == "TF") && (!"TF" %in% names(db_list[[sps]]))) {
          log_message("Preparing database: TF")

          status <- tryCatch(
            {
              temp <- tempfile()
              url <- paste0(
                "https://raw.githubusercontent.com/mengxu98/datasets/main/AnimalTFDB4/TF_list_final/",
                sps,
                "_TF"
              )
              download(
                url = url,
                destfile = temp
              )
              tf <- utils::read.table(
                temp,
                header = TRUE,
                sep = "\t",
                stringsAsFactors = FALSE,
                fill = TRUE,
                quote = ""
              )
              url <- paste0(
                "https://raw.githubusercontent.com/mengxu98/datasets/main/AnimalTFDB4/Cof_list_final/",
                sps,
                "_Cof"
              )
              download(
                url = url,
                destfile = temp
              )
              tfco <- utils::read.table(
                temp,
                header = TRUE,
                sep = "\t",
                stringsAsFactors = FALSE,
                fill = TRUE,
                quote = ""
              )
              if (!"Symbol" %in% colnames(tf)) {
                if (
                  isTRUE(convert_species) && db_species["TF"] != "Homo_sapiens"
                ) {
                  log_message(
                    "Use the human annotation to create the TF database for ",
                    sps,
                    message_type = "warning"
                  )
                  db_species["TF"] <- "Homo_sapiens"
                  url <- paste0(
                    "https://raw.githubusercontent.com/mengxu98/datasets/main/AnimalTFDB4/TF_list_final/Homo_sapiens_TF"
                  )
                  download(url = url, destfile = temp)
                  tf <- utils::read.table(
                    temp,
                    header = TRUE,
                    sep = "\t",
                    stringsAsFactors = FALSE,
                    fill = TRUE,
                    quote = ""
                  )
                  url <- paste0(
                    "https://raw.githubusercontent.com/mengxu98/datasets/main/AnimalTFDB4/Cof_list_final/Homo_sapiens_Cof"
                  )
                  download(url = url, destfile = temp)
                  tfco <- utils::read.table(
                    temp,
                    header = TRUE,
                    sep = "\t",
                    stringsAsFactors = FALSE,
                    fill = TRUE,
                    quote = ""
                  )
                } else {
                  log_message(
                    "Stop the preparation.",
                    message_type = "error"
                  )
                }
              }
              unlink(temp)
              version <- "AnimalTFDB4"
            },
            error = identity
          )

          if (inherits(status, "error")) {
            temp <- tempfile()
            url <- paste0(
              "https://raw.githubusercontent.com/GuoBioinfoLab/AnimalTFDB3/master/AnimalTFDB3/static/AnimalTFDB3/download/",
              sps,
              "_TF"
            )
            download(url = url, destfile = temp)
            tf <- utils::read.table(
              temp,
              header = TRUE,
              sep = "\t",
              stringsAsFactors = FALSE,
              fill = TRUE,
              quote = ""
            )
            url <- paste0(
              "https://raw.githubusercontent.com/GuoBioinfoLab/AnimalTFDB3/master/AnimalTFDB3/static/AnimalTFDB3/download/",
              sps,
              "_TF_cofactors"
            )
            download(url = url, destfile = temp)
            tfco <- utils::read.table(
              temp,
              header = TRUE,
              sep = "\t",
              stringsAsFactors = FALSE,
              fill = TRUE,
              quote = ""
            )
            if (!"Symbol" %in% colnames(tf)) {
              if (isTRUE(convert_species) && db_species["TF"] != "Homo_sapiens") {
                log_message(
                  "Use the human annotation to create the TF database for {.val {sps}}",
                  message_type = "warning"
                )
                db_species["TF"] <- "Homo_sapiens"
                url <- c(
                  "https://raw.githubusercontent.com/GuoBioinfoLab/AnimalTFDB3/master/AnimalTFDB3/static/AnimalTFDB3/download/Homo_sapiens_TF"
                )
                download(url = url, destfile = temp)
                tf <- utils::read.table(
                  temp,
                  header = TRUE,
                  sep = "\t",
                  stringsAsFactors = FALSE,
                  fill = TRUE,
                  quote = ""
                )
                url <- paste0(
                  "https://raw.githubusercontent.com/GuoBioinfoLab/AnimalTFDB3/master/AnimalTFDB3/static/AnimalTFDB3/download/Homo_sapiens_TF_cofactors"
                )
                download(
                  url = url,
                  destfile = temp
                )
                tfco <- utils::read.table(
                  temp,
                  header = TRUE,
                  sep = "\t",
                  stringsAsFactors = FALSE,
                  fill = TRUE,
                  quote = ""
                )
              } else {
                log_message(
                  "Stop the preparation",
                  message_type = "error"
                )
              }
            }
            unlink(temp)
            version <- "AnimalTFDB3"
          }

          TERM2GENE <- rbind(
            data.frame("Term" = "TF", "symbol" = tf[["Symbol"]]),
            data.frame("Term" = "TF cofactor", "symbol" = tfco[["Symbol"]])
          )
          TERM2NAME <- data.frame(
            "Term" = c("TF", "TF cofactor"),
            "Name" = c("TF", "TF cofactor")
          )
          colnames(TERM2GENE) <- c("Term", default_id_types[["TF"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["TF"]]][["TF"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["TF"]]][["TF"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["TF"]]][["TF"]][["version"]] <- version
          if (sps == db_species["TF"]) {
            R.cache::saveCache(
              db_list[[db_species["TF"]]][["TF"]],
              key = list(version, as.character(db_species["TF"]), "TF"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["TF"],
                "-TF"
              )
            )
          }
        }

        if (any(db == "CSPA") && (!"CSPA" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens", "Mus_musculus")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the CSPA database for {.val {sps}}",
                message_type = "warning"
              )
              db_species["CSPA"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg CSPA} database only support {.val {c('Homo_sapiens', 'Mus_musculus')}}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          check_r("openxlsx", verbose = FALSE)
          log_message("Preparing database: CSPA")
          url <- "https://raw.githubusercontent.com/mengxu98/datasets/main/CSPA/S1_File.xlsx"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "CSPA",
            pattern = "^S1_File\\.xlsx$",
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile(fileext = ".xlsx")
            source_is_temp <- TRUE
            download(
              url = url,
              destfile = source_file,
              mode = "wb"
            )
          }
          surfacepro <- get_namespace_fun(
            "openxlsx", "read.xlsx"
          )(source_file, sheet = 1)
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          surfacepro <- surfacepro[
            surfacepro[["organism"]] ==
              switch(db_species["CSPA"],
                "Homo_sapiens" = "Human",
                "Mus_musculus" = "Mouse"
              ), ,
            drop = FALSE
          ]
          TERM2GENE <- data.frame(
            "Term" = "SurfaceProtein",
            "symbol" = surfacepro[["ENTREZ.gene.symbol"]]
          )
          TERM2NAME <- data.frame(
            "Term" = "SurfaceProtein",
            "Name" = "SurfaceProtein"
          )
          colnames(TERM2GENE) <- c("Term", default_id_types[["CSPA"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- "CSPA"
          db_list[[db_species["CSPA"]]][["CSPA"]][["TERM2GENE"]] <- TERM2GENE
          db_list[[db_species["CSPA"]]][["CSPA"]][["TERM2NAME"]] <- TERM2NAME
          db_list[[db_species["CSPA"]]][["CSPA"]][["version"]] <- version
          if (sps == db_species["CSPA"]) {
            R.cache::saveCache(
              db_list[[db_species["CSPA"]]][["CSPA"]],
              key = list(version, as.character(db_species["CSPA"]), "CSPA"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["CSPA"],
                "-CSPA"
              )
            )
          }
        }

        if (
          any(db == "Surfaceome") && (!"Surfaceome" %in% names(db_list[[sps]]))
        ) {
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the Surfaceome database for {.val {sps}}",
                message_type = "warning"
              )
              db_species["Surfaceome"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg Surfaceome} database only support {.val Homo_sapiens}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          check_r("openxlsx", verbose = FALSE)
          log_message("Preparing database: Surfaceome")
          url <- "http://wlab.ethz.ch/surfaceome/table_S3_surfaceome.xlsx"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "Surfaceome",
            pattern = "^table_S3_surfaceome\\.xlsx$",
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile(fileext = ".xlsx")
            source_is_temp <- TRUE
            download(
              url = url,
              destfile = source_file,
              mode = ifelse(.Platform$OS.type == "windows", "wb", "w")
            )
          }
          surfaceome <- get_namespace_fun("openxlsx", "read.xlsx")(
            source_file,
            sheet = 2,
            colNames = TRUE,
            startRow = 2
          )
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          TERM2GENE <- data.frame(
            "Term" = "SurfaceProtein",
            "symbol" = surfaceome[["UniProt.gene"]]
          )
          TERM2NAME <- data.frame(
            "Term" = "SurfaceProtein",
            "Name" = "SurfaceProtein"
          )
          colnames(TERM2GENE) <- c("Term", default_id_types[["Surfaceome"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- "Surfaceome"
          db_list[[db_species["Surfaceome"]]][["Surfaceome"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["Surfaceome"]]][["Surfaceome"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["Surfaceome"]]][["Surfaceome"]][[
            "version"
          ]] <- version
          if (sps == db_species["Surfaceome"]) {
            R.cache::saveCache(
              db_list[[db_species["Surfaceome"]]][["Surfaceome"]],
              key = list(
                version,
                as.character(db_species["Surfaceome"]),
                "Surfaceome"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["Surfaceome"],
                "-Surfaceome"
              )
            )
          }
        }

        if (any(db == "SPRomeDB") && (!"SPRomeDB" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the SPRomeDB database for {.val {sps}}",
                message_type = "warning"
              )
              db_species["SPRomeDB"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg SPRomeDB} database only support {.val Homo_sapiens}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg SPRomeDB} database", verbose = verbose)
          url <- "http://119.3.41.228/SPRomeDB/files/download/secreted_proteins_SPRomeDB.csv"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "SPRomeDB",
            pattern = "^secreted_proteins_SPRomeDB\\.csv$",
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile()
            source_is_temp <- TRUE
            download(url = url, destfile = source_file)
          }
          spromedb <- utils::read.csv(source_file, header = TRUE)
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          TERM2GENE <- data.frame(
            "Term" = "SecretoryProtein",
            "entrez_id" = unlist(strsplit(spromedb$Gene_ID, ";"))
          )
          TERM2NAME <- data.frame(
            "Term" = "SecretoryProtein",
            "Name" = "SecretoryProtein"
          )
          colnames(TERM2GENE) <- c("Term", default_id_types[["SPRomeDB"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- "SPRomeDB"
          db_list[[db_species["SPRomeDB"]]][["SPRomeDB"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["SPRomeDB"]]][["SPRomeDB"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["SPRomeDB"]]][["SPRomeDB"]][[
            "version"
          ]] <- version
          if (sps == db_species["SPRomeDB"]) {
            R.cache::saveCache(
              db_list[[db_species["SPRomeDB"]]][["SPRomeDB"]],
              key = list(
                version,
                as.character(db_species["SPRomeDB"]),
                "SPRomeDB"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["SPRomeDB"],
                "-SPRomeDB"
              )
            )
          }
        }

        if (any(db == "VerSeDa") && (!"VerSeDa" %in% names(db_list[[sps]]))) {
          temp <- tempfile()
          download(
            url = "http://genomics.cicbiogune.es/VerSeDa/downloads.php",
            destfile = temp
          )
          verseda_sps <- readLines(temp)
          verseda_sps <- regmatches(
            verseda_sps,
            m = regexpr(
              "(?<=Downloads/)\\S+(?=\\.zip)",
              verseda_sps,
              perl = TRUE
            )
          )
          verseda_sps <- setdiff(
            verseda_sps,
            c("NonRefined", "NonRefined_Curated", "Refined", "Refined_Curated")
          )
          if (!tolower(sps) %in% verseda_sps) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the VerSeDa database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["VerSeDa"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg VerSeDa} database only support {.val {verseda_sps}}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg VerSeDa} database", verbose = verbose)
          temp <- tempfile(fileext = ".zip")
          url <- paste0(
            "http://genomics.cicbiogune.es/VerSeDa/Downloads/",
            tolower(db_species["VerSeDa"]),
            ".zip"
          )
          download(url = url, destfile = temp)
          con <- unz(
            temp,
            paste0(
              tolower(db_species["VerSeDa"]),
              "/",
              tolower(db_species["VerSeDa"]),
              "_Refined.sequences"
            )
          )
          verseda <- readLines(con)
          close(con)
          unlink(temp)
          verseda <- verseda[grep("^>", verseda)]
          verseda <- gsub("^>|\\.\\d+", "", verseda)
          verseda_id <- GeneConvert(
            geneID = verseda,
            geneID_from_IDtype = c(
              "ensembl_peptide_id",
              "refseq_peptide",
              "refseq_peptide_predicted",
              "uniprot_isoform",
              "uniprotswissprot",
              "uniprotsptrembl"
            ),
            geneID_to_IDtype = "symbol",
            species_from = db_species["VerSeDa"]
          )
          TERM2GENE <- data.frame(
            "Term" = "SecretoryProtein",
            "symbol" = unique(verseda_id$geneID_expand$symbol)
          )
          TERM2NAME <- data.frame(
            "Term" = "SecretoryProtein",
            "Name" = "SecretoryProtein"
          )
          colnames(TERM2GENE) <- c("Term", default_id_types[["VerSeDa"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          version <- "VerSeDa"
          db_list[[db_species["VerSeDa"]]][["VerSeDa"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["VerSeDa"]]][["VerSeDa"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["VerSeDa"]]][["VerSeDa"]][["version"]] <- version
          if (sps == db_species["VerSeDa"]) {
            R.cache::saveCache(
              db_list[[db_species["VerSeDa"]]][["VerSeDa"]],
              key = list(
                version,
                as.character(db_species["VerSeDa"]),
                "VerSeDa"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["VerSeDa"],
                "-VerSeDa"
              )
            )
          }
        }

        if (any(db == "TFLink") && (!"TFLink" %in% names(db_list[[sps]]))) {
          tflink_sp <- c(
            "Homo_sapiens",
            "Mus_musculus",
            "Rattus_norvegicus",
            "Danio_rerio",
            "Drosophila_melanogaster",
            "Caenorhabditis_elegans",
            "Saccharomyces_cerevisiae"
          )
          if (!sps %in% tflink_sp) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the TFLink database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["TFLink"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg TFLink} database only support {.val {tflink_sp}}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg TFLink} database", verbose = verbose)
          url <- paste0(
            "https://cdn.netbiol.org/tflink/download_files/TFLink_",
            db_species["TFLink"],
            "_interactions_All_GMT_proteinName_v1.0.gmt"
          )
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "TFLink",
            pattern = paste0(
              "^TFLink_",
              db_species[["TFLink"]],
              "_interactions_All_GMT_proteinName_v1\\.0\\.gmt$"
            ),
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile()
            source_is_temp <- TRUE
            download(url = url, destfile = source_file)
          }
          TERM2GENE <- clusterProfiler::read.gmt(source_file)
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          version <- "v1.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["TFLink"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["TFLink"]]][["TFLink"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["TFLink"]]][["TFLink"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["TFLink"]]][["TFLink"]][["version"]] <- version
          if (sps == db_species["TFLink"]) {
            R.cache::saveCache(
              db_list[[db_species["TFLink"]]][["TFLink"]],
              key = list(version, as.character(db_species["TFLink"]), "TFLink"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["TFLink"],
                "-TFLink"
              )
            )
          }
        }

        if (
          any(db == "hTFtarget") && (!"hTFtarget" %in% names(db_list[[sps]]))
        ) {
          if (!sps %in% "Homo_sapiens") {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the hTFtarget database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["hTFtarget"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg hTFtarget} database only support {.val Homo_sapiens}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg hTFtarget} database", verbose = verbose)
          url <- "https://guolab.wchscu.cn/static/hTFtarget/file_download/tf-target-infomation.txt"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "hTFtarget",
            pattern = "^tf-target-infomation\\.txt$",
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile()
            source_is_temp <- TRUE
            download(url = url, destfile = source_file)
          }
          TERM2GENE <- utils::read.table(source_file, header = TRUE, fill = T, sep = "\t")
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          version <- "v1.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["hTFtarget"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["hTFtarget"]]][["hTFtarget"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["hTFtarget"]]][["hTFtarget"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["hTFtarget"]]][["hTFtarget"]][[
            "version"
          ]] <- version
          if (sps == db_species["hTFtarget"]) {
            R.cache::saveCache(
              db_list[[db_species["hTFtarget"]]][["hTFtarget"]],
              key = list(
                version,
                as.character(db_species["hTFtarget"]),
                "hTFtarget"
              ),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["hTFtarget"],
                "-hTFtarget"
              )
            )
          }
        }

        if (any(db == "TRRUST") && (!"TRRUST" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens", "Mus_musculus")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the TRRUST database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["TRRUST"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg TRRUST} database only support {.val {c('Homo_sapiens', 'Mus_musculus')}}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg TRRUST} database", verbose = verbose)
          url <- switch(db_species["TRRUST"],
            "Homo_sapiens" = "https://raw.githubusercontent.com/bioinfonerd/Transcription-Factor-Databases/master/Ttrust_v2/trrust_rawdata.human.tsv",
            "Mus_musculus" = "https://raw.githubusercontent.com/bioinfonerd/Transcription-Factor-Databases/master/Ttrust_v2/trrust_rawdata.mouse.tsv.gz"
          )
          trrust_file <- switch(db_species["TRRUST"],
            "Homo_sapiens" = "trrust_rawdata.human.tsv",
            "Mus_musculus" = "trrust_rawdata.mouse.tsv.gz"
          )
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "TRRUST",
            pattern = switch(db_species["TRRUST"],
              "Homo_sapiens" = "^trrust_rawdata\\.human\\.tsv$",
              "Mus_musculus" = "^trrust_rawdata\\.mouse\\.tsv\\.gz$"
            ),
            verbose = verbose
          )
          source_is_temp <- FALSE
          if (is.null(source_file)) {
            source_file <- tempfile(fileext = ifelse(endsWith(url, "gz"), ".gz", ""))
            source_is_temp <- TRUE
            download(url = url, destfile = source_file)
          }
          if (grepl("\\.gz$", source_file, ignore.case = TRUE)) {
            temp <- tempfile(fileext = ".gz")
            file.copy(source_file, temp, overwrite = TRUE)
            R.utils::gunzip(temp)
            TERM2GENE <- utils::read.table(
              gsub(".gz$", "", temp),
              header = FALSE,
              fill = T,
              sep = "\t"
            )[, 1:2]
            unlink(gsub(".gz$", "", temp))
          } else {
            TERM2GENE <- utils::read.table(
              source_file,
              header = FALSE,
              fill = T,
              sep = "\t"
            )[, 1:2]
          }
          if (isTRUE(source_is_temp)) {
            unlink(source_file)
          }
          version <- "v2.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["TRRUST"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["TRRUST"]]][["TRRUST"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["TRRUST"]]][["TRRUST"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["TRRUST"]]][["TRRUST"]][["version"]] <- version
          if (sps == db_species["TRRUST"]) {
            R.cache::saveCache(
              db_list[[db_species["TRRUST"]]][["TRRUST"]],
              key = list(version, as.character(db_species["TRRUST"]), "TRRUST"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["TRRUST"],
                "-TRRUST"
              )
            )
          }
        }

        if (any(db == "JASPAR") && (!"JASPAR" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the JASPAR database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["JASPAR"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg JASPAR} database only support {.val Homo_sapiens}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg JASPAR} database", verbose = verbose)
          url <- "https://maayanlab.cloud/static/hdfs/harmonizome/data/jasparpwm/gene_set_library_crisp.gmt.gz"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "JASPAR",
            pattern = "^gene_set_library_crisp\\.gmt(\\.gz)?$",
            verbose = verbose
          )
          if (is.null(source_file)) {
            temp <- tempfile(fileext = ".gz")
            download(url = url, destfile = temp)
            R.utils::gunzip(temp)
            source_file <- gsub(".gz", "", temp)
          }
          TERM2GENE <- preparedb_read_gmt_source(source_file)
          version <- "Harmonizome 3.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["JASPAR"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["JASPAR"]]][["JASPAR"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["JASPAR"]]][["JASPAR"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["JASPAR"]]][["JASPAR"]][["version"]] <- version
          if (sps == db_species["JASPAR"]) {
            R.cache::saveCache(
              db_list[[db_species["JASPAR"]]][["JASPAR"]],
              key = list(version, as.character(db_species["JASPAR"]), "JASPAR"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["JASPAR"],
                "-JASPAR"
              )
            )
          }
        }

        if (any(db == "ENCODE") && (!"ENCODE" %in% names(db_list[[sps]]))) {
          if (!sps %in% c("Homo_sapiens")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the ENCODE database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["ENCODE"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg ENCODE} database only support {.val Homo_sapiens}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg ENCODE} database", verbose = verbose)
          url <- "https://maayanlab.cloud/static/hdfs/harmonizome/data/encodetfppi/gene_set_library_crisp.gmt.gz"
          source_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "ENCODE",
            pattern = "^gene_set_library_crisp\\.gmt(\\.gz)?$",
            verbose = verbose
          )
          if (is.null(source_file)) {
            temp <- tempfile(fileext = ".gz")
            download(url = url, destfile = temp)
            R.utils::gunzip(temp)
            source_file <- gsub(".gz", "", temp)
          }
          TERM2GENE <- preparedb_read_gmt_source(source_file)
          version <- "Harmonizome 3.0"
          TERM2NAME <- TERM2GENE[, c(1, 1)]
          colnames(TERM2GENE) <- c("Term", default_id_types[["ENCODE"]])
          colnames(TERM2NAME) <- c("Term", "Name")
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          db_list[[db_species["ENCODE"]]][["ENCODE"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["ENCODE"]]][["ENCODE"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["ENCODE"]]][["ENCODE"]][["version"]] <- version
          if (sps == db_species["ENCODE"]) {
            R.cache::saveCache(
              db_list[[db_species["ENCODE"]]][["ENCODE"]],
              key = list(version, as.character(db_species["ENCODE"]), "ENCODE"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["ENCODE"],
                "-ENCODE"
              )
            )
          }
        }

        msigdb_requested <- db[grepl("^MSigDB($|_)", db)]
        if (
          length(msigdb_requested) > 0L &&
            any(!msigdb_requested %in% names(db_list[[sps]]))
        ) {
          if (!sps %in% c("Homo_sapiens", "Mus_musculus")) {
            if (isTRUE(convert_species)) {
              log_message(
                "Use the human annotation to create the MSigDB database for {.val {sps}}",
                message_type = "warning",
                verbose = verbose
              )
              db_species["MSigDB"] <- "Homo_sapiens"
            } else {
              log_message(
                "{.pkg MSigDB} database only support {.val {c('Homo_sapiens', 'Mus_musculus')}}. Consider setting {.arg convert_species=TRUE}",
                message_type = "error"
              )
            }
          }
          log_message("Preparing {.pkg MSigDB} database", verbose = verbose)

          msigdb_release_species <- switch(db_species[["MSigDB"]],
            "Homo_sapiens" = "Hs",
            "Mus_musculus" = "Mm"
          )
          if (is.null(msigdb_release_species)) {
            log_message(
              "{.pkg MSigDB} database only support {.val {c('Homo_sapiens', 'Mus_musculus')}}. Consider setting {.arg convert_species=TRUE}",
              message_type = "error"
            )
          }

          msigdb_pattern <- if (identical(db_version, "latest")) {
            paste0("^msigdb\\.v.+\\.", msigdb_release_species, "\\.json$")
          } else {
            utils::glob2rx(paste0("msigdb.v", db_version, ".json"))
          }
          msigdb_local_file <- preparedb_local_source_file(
            data_dir = data_dir,
            db = "MSigDB",
            pattern = msigdb_pattern,
            verbose = verbose
          )

          if (!is.null(msigdb_local_file)) {
            version <- sub("^msigdb\\.v(.+)\\.json$", "\\1", basename(msigdb_local_file))
            log_message(
              "Using local {.pkg MSigDB} JSON file: {.path {msigdb_local_file}}",
              verbose = verbose
            )
            lines <- paste0(readLines(msigdb_local_file, warn = FALSE), collapse = "")
          } else {
            temp <- tempfile()
            download(
              url = "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/",
              destfile = temp
            )
            version <- readLines(temp)
            version <- version[grep("alt=\"\\[DIR\\]\"", version)]
            version <- version[grep(
              msigdb_release_species,
              version
            )]
            version <- version[length(version)]
            version <- regmatches(
              version,
              m = regexpr("(?<=href\\=\")\\S+(?=/\"\\>)", version, perl = TRUE)
            )

            url <- paste0(
              "https://data.broadinstitute.org/gsea-msigdb/msigdb/release/",
              version,
              "/msigdb.v",
              version,
              ".json"
            )
            download(url = url, destfile = temp)
            lines <- paste0(readLines(temp, warn = FALSE), collapse = "")
          }
          lines <- gsub("\"", "", lines)
          lines <- gsub("^\\{|\\}$", "", lines)
          terms <- strsplit(lines, "\\},")[[1]]
          term_list <- list()
          for (idx in seq_along(terms)) {
            term_content <- terms[[idx]]
            term_name <- trimws(gsub(":|_|\\{.*", " ", term_content))
            term_id <- trimws(regmatches(
              term_content,
              m = regexpr(
                "(?<=systematicName:)\\S+?(?=,)",
                term_content,
                perl = TRUE
              )
            ))
            term_gene <- trimws(regmatches(
              term_content,
              m = regexpr(
                pattern = "(?<=geneSymbols:\\[)\\S+?(?=\\],)",
                term_content,
                perl = TRUE
              )
            ))
            term_collection <- trimws(regmatches(
              term_content,
              m = regexpr(
                pattern = "(?<=collection:)\\S+?(?=\\,)",
                term_content,
                perl = TRUE
              )
            ))
            term_list[[idx]] <- c(
              id = term_id,
              "name" = term_name,
              "gene" = term_gene,
              "collection" = term_collection
            )
          }
          df <- as.data.frame(do.call(rbind, term_list))
          df$gene <- strsplit(df$gene, split = ",")
          df <- unnest_fun(df, cols = "gene")

          TERM2NAME <- df[, c(1, 2, 4)]
          TERM2GENE <- df[, c(1, 3)]
          colnames(TERM2NAME) <- c("Term", "Name", "Collection")
          colnames(TERM2GENE) <- c("Term", default_id_types[["MSigDB"]])
          TERM2NAME <- stats::na.omit(unique(TERM2NAME))
          TERM2GENE <- stats::na.omit(unique(TERM2GENE))

          db_list[[db_species["MSigDB"]]][["MSigDB"]][[
            "TERM2GENE"
          ]] <- TERM2GENE
          db_list[[db_species["MSigDB"]]][["MSigDB"]][[
            "TERM2NAME"
          ]] <- TERM2NAME
          db_list[[db_species["MSigDB"]]][["MSigDB"]][["version"]] <- version
          if (sps == db_species["MSigDB"]) {
            R.cache::saveCache(
              db_list[[db_species["MSigDB"]]][["MSigDB"]],
              key = list(version, as.character(db_species["MSigDB"]), "MSigDB"),
              comment = paste0(
                version,
                " nterm:",
                length(TERM2NAME[[1]]),
                "|",
                db_species["MSigDB"],
                "-MSigDB"
              )
            )
          }

          msigdb_subsets <- preparedb_msigdb_collection_subsets(
            TERM2GENE = TERM2GENE,
            TERM2NAME = TERM2NAME
          )
          for (collection_db in names(msigdb_subsets)) {
            db_species[collection_db] <- db_species["MSigDB"]
            default_id_types[[collection_db]] <- default_id_types[["MSigDB"]]
            TERM2NAME_sub <- msigdb_subsets[[collection_db]][["TERM2NAME"]]
            TERM2GENE_sub <- msigdb_subsets[[collection_db]][["TERM2GENE"]]
            db_list[[db_species["MSigDB"]]][[collection_db]][[
              "TERM2GENE"
            ]] <- TERM2GENE_sub
            db_list[[db_species["MSigDB"]]][[collection_db]][[
              "TERM2NAME"
            ]] <- TERM2NAME_sub
            db_list[[db_species["MSigDB"]]][[collection_db]][[
              "version"
            ]] <- version
            if (sps == db_species["MSigDB"]) {
              R.cache::saveCache(
                db_list[[db_species["MSigDB"]]][[collection_db]],
                key = list(
                  version,
                  as.character(db_species["MSigDB"]),
                  collection_db
                ),
                comment = paste0(
                  version,
                  " nterm:",
                  length(TERM2NAME_sub[[1]]),
                  "|",
                  db_species["MSigDB"],
                  "-",
                  collection_db
                )
              )
            }
          }
        }

        ccc_db_use <- intersect(db, c("CellTalk", "CellChat"))
        if (length(ccc_db_use) > 0L &&
          any(!ccc_db_use %in% names(db_list[[sps]]))) {
          ccc_prepared <- PrepareCCCDB(
            species = sps,
            db = ccc_db_use,
            convert_species = convert_species,
            data_dir = data_dir,
            db_version = db_version,
            db_update = db_update,
            verbose = verbose
          )
          for (ccc_db in ccc_db_use) {
            if (!ccc_db %in% names(ccc_prepared[[sps]])) next
            db_list[[sps]][[ccc_db]] <- ccc_prepared[[sps]][[ccc_db]]
          }
        }
      } else {
        db_species[db] <- custom_species
        if (sps != custom_species) {
          if (isTRUE(convert_species)) {
            log_message(
              "Use the {.val {custom_species}} annotation to create the {.val {db}} database for {.val {sps}}",
              message_type = "warning",
              verbose = verbose
            )
          } else {
            log_message(
              "{.pkg {db}} database only support {.val {custom_species}}. Consider using {.arg convert_species=TRUE}",
              message_type = "error"
            )
          }
        }
        custom_db <- normalize_custom_db_input(
          TERM2GENE = custom_TERM2GENE,
          TERM2NAME = custom_TERM2NAME,
          IDtype = custom_IDtype,
          remove_na = TRUE
        )
        TERM2GENE <- custom_db[["TERM2GENE"]]
        TERM2NAME <- custom_db[["TERM2NAME"]]
        db_list[[db_species[db]]][[db]][["TERM2GENE"]] <- TERM2GENE
        db_list[[db_species[db]]][[db]][["TERM2NAME"]] <- TERM2NAME
        db_list[[db_species[db]]][[db]][["version"]] <- custom_version
        if (sps == db_species[db]) {
          R.cache::saveCache(
            db_list[[db_species[db]]][[db]],
            key = list(custom_version, as.character(db_species[db]), db),
            comment = paste0(
              custom_version,
              " nterm:",
              length(TERM2NAME[[1]]),
              "|",
              db_species[db],
              "-",
              db
            )
          )
        }
      }
    }

    db_list <- preparedb_ensure_msigdb_parent(
      db_list = db_list,
      species = sps,
      db_version = db_version,
      verbose = verbose
    )

    if (!all(db_species == sps)) {
      for (term in names(db_species[db_species != sps])) {
        log_message(
          "Convert species for the {.pkg {term}} database",
          verbose = verbose
        )
        sp_from <- db_species[term]
        db_info <- db_list[[sp_from]][[names(sp_from)]]
        TERM2GENE <- preparedb_normalize_term2gene_id_columns(
          db_info[["TERM2GENE"]]
        )
        db_info[["TERM2GENE"]] <- TERM2GENE
        TERM2NAME <- db_info[["TERM2NAME"]]
        IDtype <- preparedb_source_idtype(
          term = term,
          TERM2GENE = TERM2GENE,
          default_id_types = default_id_types
        )
        TERM2GENE_map <- NULL
        if (grepl("^MSigDB_", term)) {
          TERM2GENE_map <- db_list[[sps]][["MSigDB"]][["TERM2GENE"]]
        }
        if (!is.null(TERM2GENE_map)) {
          TERM2GENE <- TERM2GENE_map[
            TERM2GENE_map[["Term"]] %in% TERM2GENE[["Term"]], ,
            drop = FALSE
          ]
          TERM2NAME <- TERM2NAME[
            TERM2NAME[["Term"]] %in% TERM2GENE[["Term"]], ,
            drop = FALSE
          ]
        } else {
          res <- GeneConvert(
            geneID = as.character(unique(TERM2GENE[, 2])),
            geneID_from_IDtype = IDtype,
            geneID_to_IDtype = "ensembl_id",
            species_from = sp_from,
            species_to = sps,
            Ensembl_version = Ensembl_version,
            mirror = mirror,
            biomart = biomart,
            max_tries = max_tries
          )
          if (is.null(res$geneID_res)) {
            log_message(
              "Failed to convert species for the database: {.val {term}}",
              message_type = "warning",
              verbose = verbose
            )
            next
          }
          map <- res$geneID_collapse
          TERM2GENE[["ensembl_id-converted"]] <- map[
            as.character(TERM2GENE[, 2]),
            "ensembl_id"
          ]
          TERM2GENE <- unnest_fun(
            TERM2GENE,
            cols = "ensembl_id-converted",
            keep_empty = FALSE
          )
          TERM2GENE <- TERM2GENE[, c("Term", "ensembl_id-converted")]
          colnames(TERM2GENE) <- c("Term", "ensembl_id")
          TERM2NAME <- TERM2NAME[
            TERM2NAME[["Term"]] %in% TERM2GENE[["Term"]], ,
            drop = FALSE
          ]
        }

        db_info[["TERM2GENE"]] <- unique(TERM2GENE)
        db_info[["TERM2NAME"]] <- unique(TERM2NAME)
        version <- paste0(
          db_info[["version"]],
          "(converted from ",
          sp_from,
          ")"
        )
        db_info[["version"]] <- version
        db_list[[sps]][[term]] <- db_info
        default_id_types[[term]] <- "ensembl_id"
        R.cache::saveCache(
          db_list[[sps]][[term]],
          key = list(version, sps, term),
          comment = paste0(
            version,
            " nterm:",
            length(TERM2NAME[[1]]),
            "|",
            sps,
            "-",
            term
          )
        )
      }
    }

    for (term in names(db_list[[sps]])) {
      db_list[[sps]][[term]][["TERM2GENE"]] <-
        preparedb_normalize_term2gene_id_columns(
          db_list[[sps]][[term]][["TERM2GENE"]]
        )
      IDtypes <- db_IDtypes[
        !db_IDtypes %in% colnames(db_list[[sps]][[term]][["TERM2GENE"]])
      ]
      if (length(IDtypes) > 0) {
        log_message(
          "Convert ID types for the {.pkg {term}} database",
          verbose = verbose
        )
        TERM2GENE <- db_list[[sps]][[term]][["TERM2GENE"]]
        TERM2NAME <- db_list[[sps]][[term]][["TERM2NAME"]]
        IDtype <- preparedb_source_idtype(
          term = term,
          TERM2GENE = TERM2GENE,
          default_id_types = default_id_types
        )
        parent_term2gene <- preparedb_msigdb_parent_term2gene(
          parent = db_list[[sps]][["MSigDB"]][["TERM2GENE"]],
          id_types = IDtypes
        )
        if (grepl("^MSigDB_", term) && !is.null(parent_term2gene)) {
          map <- parent_term2gene[, -1, drop = FALSE]
          map <- stats::aggregate(
            map,
            by = list(map[[1]]),
            FUN = function(x) list(unique(x))
          )
          rownames(map) <- map[, 1]
        } else {
          map <- preparedb_local_orgdb_id_map(
            geneID = as.character(unique(TERM2GENE[, 2])),
            geneID_from_IDtype = IDtype,
            geneID_to_IDtype = IDtypes,
            org_sp = org_sp,
            org_key = org_key,
            verbose = verbose
          )
          if (is.null(map)) {
            res <- GeneConvert(
              geneID = as.character(unique(TERM2GENE[, 2])),
              geneID_from_IDtype = IDtype,
              geneID_to_IDtype = IDtypes,
              species_from = sps,
              species_to = sps,
              Ensembl_version = Ensembl_version,
              mirror = mirror,
              biomart = biomart,
              max_tries = max_tries
            )
            if (is.null(res$geneID_res)) {
              log_message(
                "Failed to convert ID types for the database: {.val {term}}",
                message_type = "warning",
                verbose = verbose
              )
              next
            }
            map <- res$geneID_collapse
          }
          if (is.null(map) || nrow(map) == 0) {
            log_message(
              "Failed to convert ID types for the database: {.val {term}}",
              message_type = "warning",
              verbose = verbose
            )
            next
          }
        }
        for (type in IDtypes) {
          TERM2GENE[[type]] <- map[as.character(TERM2GENE[, 2]), type]
          TERM2GENE <- unnest_fun(TERM2GENE, cols = type, keep_empty = TRUE)
        }
        db_list[[sps]][[term]][["TERM2GENE"]] <- TERM2GENE
        version <- db_list[[sps]][[term]][["version"]]
        R.cache::saveCache(
          db_list[[sps]][[term]],
          key = list(version, sps, term),
          comment = paste0(
            version,
            " nterm:",
            length(TERM2NAME[[1]]),
            "|",
            sps,
            "-",
            term
          )
        )
      }
    }
    preparedb_require_msigdb_names(
      db_list = db_list,
      species = sps,
      db = db
    )
    db_list <- preparedb_alias_requested_msigdb(
      db_list = db_list,
      species = sps,
      db_requested = db_requested,
      db_normalized = db
    )
  }
  db_list <- preparedb_keep_requested_dbs(
    db_list = db_list,
    species = species,
    db_names = unique(c(db, db_requested))
  )
  return(db_list)
}

normalize_species_name <- function(species) {
  if (
    !is.character(species) ||
      length(species) == 0L ||
      any(is.na(species)) ||
      any(!nzchar(trimws(species)))
  ) {
    log_message(
      "{.arg species} must be a non-empty character vector",
      message_type = "error"
    )
  }

  vapply(species, function(x) {
    x <- trimws(x)
    x <- gsub("[[:space:].-]+", "_", x)
    x <- gsub("_+", "_", x)
    x <- gsub("^_|_$", "", x)
    parts <- strsplit(x, "_", fixed = TRUE)[[1]]
    parts <- parts[nzchar(parts)]
    if (length(parts) == 0L) {
      return(x)
    }
    parts <- tolower(parts)
    parts[1] <- paste0(
      toupper(substr(parts[1], 1, 1)),
      substr(parts[1], 2, nchar(parts[1]))
    )
    paste(parts, collapse = "_")
  }, character(1), USE.NAMES = FALSE)
}

preparedb_normalize_term2gene_id_columns <- function(TERM2GENE) {
  legacy_msigdb_col <- "symbol.ensembl_id"
  if (
    legacy_msigdb_col %in% colnames(TERM2GENE) &&
      !"symbol" %in% colnames(TERM2GENE)
  ) {
    colnames(TERM2GENE)[colnames(TERM2GENE) == legacy_msigdb_col] <- "symbol"
  }
  TERM2GENE
}

normalize_msigdb_db_names <- function(db) {
  if (is.null(db) || length(db) == 0L) {
    return(db)
  }
  db <- as.character(db)
  nested <- grepl(
    "^MSigDB_[A-Za-z0-9_]+(?::[A-Za-z0-9_]+)+$",
    db,
    perl = TRUE
  )
  db[nested] <- gsub(":", "_", db[nested], fixed = TRUE)
  db
}

msigdb_collection_db_names <- function(collection) {
  collections <- as.character(collection)
  unlist(lapply(collections, function(x) {
    if (is.na(x) || !nzchar(x)) {
      return(character(0))
    }
    parts <- strsplit(x, ":", fixed = TRUE)[[1]]
    parts <- parts[nzchar(parts)]
    if (length(parts) == 0L) {
      return(character(0))
    }
    vapply(seq_along(parts), function(i) {
      paste0("MSigDB_", paste(parts[seq_len(i)], collapse = "_"))
    }, character(1))
  }), use.names = FALSE)
}

preparedb_msigdb_collection_subsets <- function(TERM2GENE, TERM2NAME) {
  collections <- unique(as.character(TERM2NAME[["Collection"]]))
  collections <- collections[!is.na(collections) & nzchar(collections)]
  db_names <- unique(msigdb_collection_db_names(collections))
  normalized <- gsub(":", "_", as.character(TERM2NAME[["Collection"]]), fixed = TRUE)
  stats::setNames(lapply(db_names, function(db_name) {
    suffix <- sub("^MSigDB_", "", db_name)
    keep <- !is.na(normalized) & (
      normalized == suffix | startsWith(normalized, paste0(suffix, "_"))
    )
    term2name <- TERM2NAME[keep, , drop = FALSE]
    term2gene <- TERM2GENE[
      TERM2GENE[["Term"]] %in% term2name[["Term"]], ,
      drop = FALSE
    ]
    list(TERM2GENE = term2gene, TERM2NAME = term2name)
  }), db_names)
}

preparedb_require_msigdb_names <- function(db_list, species, db) {
  requested <- as.character(db)
  requested <- requested[grepl("^MSigDB($|_)", requested)]
  if (length(requested) == 0L) {
    return(invisible(NULL))
  }
  available_names <- names(db_list[[species]])
  missing <- requested[!requested %in% available_names]
  if (length(missing) == 0L) {
    return(invisible(NULL))
  }
  available <- grep("^MSigDB($|_)", available_names, value = TRUE)
  if (length(available) == 0L) {
    available <- "(none)"
  }
  log_message(
    paste0(
      "MSigDB database {.val {missing}} is not available. ",
      "Nested collections use underscores, for example {.val MSigDB_M2_CGP}, ",
      "{.val MSigDB_M2_CP} and {.val MSigDB_M2_CP_BIOCARTA}. ",
      "Available MSigDB databases: {.val {available}}."
    ),
    message_type = "error"
  )
}

preparedb_load_cache_entry <- function(
  species,
  db,
  db_version = "latest",
  verbose = TRUE
) {
  dbinfo <- list_db_cache_entries(species = species, db = db)
  if (is.null(dbinfo) || nrow(dbinfo) == 0L) {
    return(NULL)
  }
  if (identical(as.character(db_version), "latest")) {
    pathname <- dbinfo[
      order(dbinfo[["timestamp"]], decreasing = TRUE)[1],
      "file"
    ]
  } else {
    pathname <- dbinfo[
      grep(db_version, dbinfo[["db_version"]], fixed = TRUE)[1],
      "file"
    ]
    if (is.na(pathname)) {
      log_message(
        "There is no {.val {db_version}} version of the database. Use the latest version",
        message_type = "warning",
        verbose = verbose
      )
      pathname <- dbinfo[
        order(dbinfo[["timestamp"]], decreasing = TRUE)[1],
        "file"
      ]
    }
  }
  if (length(pathname) == 0L || is.na(pathname)) {
    return(NULL)
  }
  header <- R.cache::readCacheHeader(pathname)
  cached_version <- strsplit(header[["comment"]], "\\|")[[1]][1]
  timestamp <- format(header[["timestamp"]], "%Y-%m-%d %H:%M:%S")
  log_message(
    "Loading cached: {.pkg {db}} version: {.pkg {cached_version}} created: {.pkg {timestamp}}",
    verbose = verbose
  )
  R.cache::loadCache(pathname = pathname)
}

preparedb_ensure_msigdb_parent <- function(
  db_list,
  species,
  db_version = "latest",
  verbose = TRUE
) {
  present <- names(db_list[[species]])
  needs_parent <- any(grepl("^MSigDB_", present)) && !"MSigDB" %in% present
  if (!isTRUE(needs_parent)) {
    return(db_list)
  }
  parent <- preparedb_load_cache_entry(
    species = species,
    db = "MSigDB",
    db_version = db_version,
    verbose = verbose
  )
  if (!is.null(parent)) {
    db_list[[species]][["MSigDB"]] <- parent
  }
  db_list
}

preparedb_msigdb_parent_term2gene <- function(parent, id_types) {
  if (
    is.null(parent) ||
      !is.data.frame(parent) ||
      length(id_types) == 0L ||
      !all(id_types %in% colnames(parent))
  ) {
    return(NULL)
  }
  parent
}

preparedb_keep_requested_dbs <- function(db_list, species, db_names) {
  db_names <- unique(as.character(db_names))
  db_names <- db_names[!is.na(db_names) & nzchar(db_names)]
  if (length(db_names) == 0L) {
    return(db_list)
  }
  for (sps in intersect(as.character(species), names(db_list))) {
    keep <- intersect(names(db_list[[sps]]), db_names)
    db_list[[sps]] <- db_list[[sps]][keep]
  }
  drop <- setdiff(names(db_list), c(as.character(species), "CytoTRACE2"))
  if (length(drop) > 0L) {
    db_list[drop] <- NULL
  }
  db_list
}

preparedb_alias_requested_msigdb <- function(
  db_list,
  species,
  db_requested,
  db_normalized
) {
  if (length(db_requested) == 0L || is.null(db_list[[species]])) {
    return(db_list)
  }
  for (i in seq_along(db_requested)) {
    requested <- db_requested[[i]]
    normalized <- db_normalized[[i]]
    if (identical(requested, normalized)) {
      next
    }
    entry <- db_list[[species]][[normalized]]
    if (!is.null(entry)) {
      db_list[[species]][[requested]] <- entry
    }
  }
  db_list
}

preparedb_local_source_file <- function(
  data_dir,
  db,
  pattern,
  verbose = TRUE
) {
  if (is.null(data_dir)) {
    return(NULL)
  }

  data_source <- data_dir
  if (is.list(data_dir)) {
    if (is.null(names(data_dir)) || !db %in% names(data_dir)) {
      return(NULL)
    }
    data_source <- data_dir[[db]]
    if (is.list(data_source)) {
      if (!is.null(data_source[["file"]])) {
        data_source <- data_source[["file"]]
      } else if (!is.null(data_source[["path"]])) {
        data_source <- data_source[["path"]]
      } else {
        return(NULL)
      }
    }
  }

  if (!is.character(data_source) || length(data_source) != 1 || is.na(data_source) || !nzchar(data_source)) {
    log_message(
      "{.arg data_dir} must be one directory path, one file path, or a named list of paths",
      message_type = "error"
    )
  }
  data_source <- path.expand(data_source)
  if (file.exists(data_source) && !dir.exists(data_source)) {
    if (any(grepl(pattern, basename(data_source), perl = TRUE))) {
      return(normalizePath(data_source, mustWork = TRUE))
    }
    log_message(
      "Local source file {.path {data_source}} does not match the expected {.pkg {db}} file name; downloading instead",
      message_type = "warning",
      verbose = verbose
    )
    return(NULL)
  }
  if (!dir.exists(data_source)) {
    log_message(
      "{.arg data_dir} must point to an existing local directory or file",
      message_type = "error"
    )
  }

  candidate_dirs <- unique(c(file.path(data_source, db), data_source))
  candidate_dirs <- candidate_dirs[dir.exists(candidate_dirs)]
  local_files <- unlist(lapply(candidate_dirs, function(dir) {
    list.files(
      dir,
      pattern = pattern,
      full.names = TRUE
    )
  }), use.names = FALSE)
  local_files <- unique(local_files)
  if (length(local_files) == 0) {
    log_message(
      "No local source file for {.pkg {db}} was found in {.arg data_dir}; downloading instead",
      message_type = "warning",
      verbose = verbose
    )
    return(NULL)
  }
  local_files[order(file.info(local_files)[["mtime"]], decreasing = TRUE)][[1]]
}

preparedb_read_gmt_source <- function(path) {
  if (grepl("\\.gz$", path, ignore.case = TRUE)) {
    temp <- tempfile(fileext = ".gz")
    file.copy(path, temp, overwrite = TRUE)
    R.utils::gunzip(temp)
    unzipped <- sub("\\.gz$", "", temp)
    on.exit(unlink(unzipped), add = TRUE)
    return(clusterProfiler::read.gmt(unzipped))
  }
  clusterProfiler::read.gmt(path)
}

preparedb_source_idtype <- function(term, TERM2GENE, default_id_types) {
  default_idtype <- default_id_types[[term]]
  if (length(default_idtype) > 0 && !all(is.na(default_idtype))) {
    default_idtype <- default_idtype[default_idtype %in% colnames(TERM2GENE)]
    if (length(default_idtype) > 0) {
      return(default_idtype[[1]])
    }
  }
  colnames(TERM2GENE)[[2]]
}

preparedb_local_orgdb_id_map <- function(
  geneID,
  geneID_from_IDtype,
  geneID_to_IDtype,
  org_sp,
  org_key,
  verbose = TRUE
) {
  if (is.null(org_sp) || !isTRUE(all(unlist(check_r(org_sp, install = FALSE, verbose = FALSE), use.names = FALSE)))) {
    return(NULL)
  }
  idtype_to_orgdb_column <- function(idtype) {
    if (length(idtype) != 1) {
      return(NA_character_)
    }
    switch(tolower(idtype),
      "symbol" = "SYMBOL",
      "ensembl_id" = "ENSEMBL",
      "entrez_id" = org_key,
      "tair_locus" = "TAIR",
      "sgd_gene" = "SGD",
      NA_character_
    )
  }
  from_column <- idtype_to_orgdb_column(geneID_from_IDtype)
  to_columns <- stats::setNames(
    vapply(geneID_to_IDtype, idtype_to_orgdb_column, character(1)),
    geneID_to_IDtype
  )
  if (is.na(from_column) || any(is.na(to_columns))) {
    return(NULL)
  }
  orgdb <- get_namespace_fun(org_sp, org_sp)
  columns_available <- AnnotationDbi::columns(orgdb)
  columns_needed <- unique(c(from_column, to_columns))
  if (any(!columns_needed %in% columns_available)) {
    return(NULL)
  }
  geneID <- unique(stats::na.omit(as.character(geneID)))
  geneID <- geneID[nzchar(geneID)]
  if (length(geneID) == 0) {
    return(NULL)
  }
  map <- tryCatch(
    {
      suppressMessages(
        AnnotationDbi::select(
          orgdb,
          keys = geneID,
          keytype = from_column,
          columns = unique(to_columns)
        )
      )
    },
    error = function(e) NULL
  )
  if (is.null(map) || nrow(map) == 0) {
    return(NULL)
  }
  map <- map[
    !is.na(map[[from_column]]) & map[[from_column]] %in% geneID, ,
    drop = FALSE
  ]
  if (nrow(map) == 0) {
    return(NULL)
  }
  for (type in names(to_columns)) {
    if (!identical(type, to_columns[[type]])) {
      map[[type]] <- map[[to_columns[[type]]]]
    }
  }
  map <- map[, unique(c(from_column, names(to_columns))), drop = FALSE]
  map <- stats::aggregate(
    map[, names(to_columns), drop = FALSE],
    by = list(map[[from_column]]),
    FUN = function(x) {
      list(unique(x[!is.na(x) & nzchar(as.character(x))]))
    }
  )
  rownames(map) <- map[, 1]
  map <- map[, -1, drop = FALSE]
  log_message(
    "Converted ID types using local annotation package {.pkg {org_sp}}",
    verbose = verbose
  )
  map
}

kegg_get <- function(url) {
  temp <- tempfile()
  on.exit(unlink(temp))
  download(url = url, destfile = temp)
  content <- as.data.frame(
    do.call(
      rbind,
      strsplit(readLines(temp), split = "\t")
    )
  )
  content
}

kegg_release_version <- function(info_lines) {
  kegg_release_from_info(info_lines) %||%
    kegg_release_from_relnote() %||%
    paste0("Retrieved ", Sys.Date())
}

kegg_release_from_info <- function(info_lines) {
  release_line <- info_lines[grepl("Release", x = info_lines)]
  if (length(release_line) == 0) {
    return(NULL)
  }
  gsub(".*(?=Release)", replacement = "", x = release_line, perl = TRUE)
}

kegg_release_from_relnote <- function(url = "https://www.kegg.jp/kegg/docs/relnote.html") {
  page <- tryCatch(
    httr::content(httr::GET(url, httr::timeout(10))),
    error = function(e) NULL
  )
  if (is.null(page)) {
    return(NULL)
  }
  page <- paste0(page, collapse = "")
  release <- regmatches(page, regexpr("Release [0-9]+\\.[0-9]+", page))
  if (length(release) == 0) NULL else release
}
