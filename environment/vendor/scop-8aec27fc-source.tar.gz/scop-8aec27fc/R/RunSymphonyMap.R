#' @title Single-cell reference mapping with Symphony method
#'
#' @md
#' @inheritParams RunKNNMap
#' @inheritParams thisutils::log_message
#' @param ref_pca The PCA reduction in the reference object to use for calculating the distance metric.
#' @param ref_harmony The Harmony reduction in the reference object to use for calculating the distance metric.
#'
#' @export
#'
#' @examples
#' data(panc8_sub)
#' panc8_sub <- RunStandardWorkflow(panc8_sub)
#' srt_ref <- panc8_sub[, panc8_sub$tech != "fluidigmc1"]
#' srt_query <- panc8_sub[, panc8_sub$tech == "fluidigmc1"]
#' srt_ref <- RunIntegration(
#'   srt_ref,
#'   batch = "tech",
#'   integration_method = "Harmony"
#' )
#' CellDimPlot(srt_ref, group.by = c("celltype", "tech"))
#'
#' # Projection
#' srt_query <- RunSymphonyMap(
#'   srt_query = srt_query,
#'   srt_ref = srt_ref,
#'   ref_pca = "Harmonypca",
#'   ref_harmony = "Harmony",
#'   ref_umap = "HarmonyUMAP2D"
#' )
#' ProjectionPlot(
#'   srt_query = srt_query,
#'   srt_ref = srt_ref,
#'   query_group = "celltype",
#'   ref_group = "celltype"
#' )
RunSymphonyMap <- function(
  srt_query,
  srt_ref,
  query_assay = NULL,
  ref_assay = srt_ref[[ref_pca]]@assay.used,
  ref_pca = NULL,
  ref_harmony = NULL,
  ref_umap = NULL,
  ref_group = NULL,
  projection_method = c("model", "knn"),
  nn_method = NULL,
  k = 30,
  distance_metric = "cosine",
  vote_fun = "mean",
  verbose = TRUE
) {
  check_r("immunogenomics/symphony", verbose = FALSE)
  check_r("matrixStats", verbose = FALSE)
  query_assay <- query_assay %||% SeuratObject::DefaultAssay(srt_query)
  ref_assay <- ref_assay %||% SeuratObject::DefaultAssay(srt_ref)
  if (!is.null(ref_group)) {
    if (length(ref_group) == ncol(srt_ref)) {
      srt_ref[["ref_group"]] <- ref_group
    } else if (length(ref_group) == 1) {
      if (!ref_group %in% colnames(srt_ref@meta.data)) {
        log_message(
          "{.arg ref_group} must be one of the column names in the meta.data",
          message_type = "error"
        )
      } else {
        srt_ref[["ref_group"]] <- srt_ref[[ref_group]]
      }
    } else {
      log_message(
        "Length of {.arg ref_group} must be one or length of {.arg srt_ref}",
        message_type = "error"
      )
    }
    ref_group <- "ref_group"
  }
  if (is.null(ref_pca)) {
    ref_pca <- sort(
      SeuratObject::Reductions(srt_ref)[grep(
        "pca",
        SeuratObject::Reductions(srt_ref),
        ignore.case = TRUE
      )]
    )[1]
    if (length(ref_pca) == 0) {
      log_message(
        "Cannot find PCA reduction in the {.arg srt_ref}",
        message_type = "error"
      )
    } else {
      log_message("Set ref_pca to {.val {ref_pca}}", verbose = verbose)
    }
  }
  if (is.null(ref_harmony)) {
    ref_harmony <- sort(
      SeuratObject::Reductions(srt_ref)[grep(
        "harmony",
        SeuratObject::Reductions(srt_ref),
        ignore.case = TRUE
      )]
    )[1]
    if (length(ref_harmony) == 0) {
      log_message(
        "Cannot find Harmony reduction in the {.arg srt_ref}",
        message_type = "error"
      )
    } else {
      log_message("Set ref_harmony to {.val {ref_harmony}}", verbose = verbose)
    }
  }
  if (is.null(ref_umap)) {
    ref_umap <- sort(
      SeuratObject::Reductions(srt_ref)[grep(
        "umap",
        SeuratObject::Reductions(srt_ref),
        ignore.case = TRUE
      )]
    )[1]
    if (length(ref_umap) == 0) {
      log_message(
        "Cannot find UMAP reduction in the {.arg srt_ref}",
        message_type = "error"
      )
    } else {
      log_message("Set ref_umap to {.val {ref_umap}}", verbose = verbose)
    }
  }
  ref_pca_dims <- srt_ref[[ref_harmony]]@misc$reduction_dims

  projection_method <- match.arg(projection_method)
  if (
    projection_method == "model" &&
      !"model" %in% names(srt_ref[[ref_umap]]@misc)
  ) {
    log_message(
      "No UMAP model detected. Set the projection_method to 'knn'",
      message_type = "warning",
      verbose = verbose
    )
    projection_method <- "knn"
  }
  if (
    projection_method == "model" &&
      !distance_metric %in% c("euclidean", "cosine", "manhattan", "hamming")
  ) {
    log_message(
      "distance_metric must be one of euclidean, cosine, manhattan, and hamming when projection_method='model'",
      message_type = "error"
    )
  }

  query_data <- GetAssayData5(srt_query, layer = "data", assay = query_assay)
  status_query <- CheckDataType(object = query_data)
  log_message("Detected {.arg srt_query} data type: {.val {status_query}}", verbose = verbose)
  status_ref <- CheckDataType(
    object = GetAssayData5(
      srt_ref,
      layer = "data",
      assay = ref_assay
    )
  )
  log_message("Detected {.arg srt_ref} data type: {.val {status_ref}}", verbose = verbose)
  if (
    status_ref != status_query ||
      any(status_query == "unknown", status_ref == "unknown")
  ) {
    log_message(
      "Data type is unknown or different between {.arg srt_query} and {.arg srt_ref}.",
      message_type = "warning",
      verbose = verbose
    )
  }

  log_message("Build reference", verbose = verbose)
  ref <- buildReferenceFromSeurat(
    obj = srt_ref,
    assay = ref_assay,
    pca = ref_pca,
    pca_dims = ref_pca_dims,
    harmony = ref_harmony,
    umap = ref_umap
  )
  log_message("Run mapQuery", verbose = verbose)
  res <- mapQuery(
    exp_query = query_data,
    metadata_query = srt_query@meta.data,
    ref_obj = ref,
    vars = NULL,
    sigma = 0.1,
    verbose = TRUE
  )
  Z_pca_query <- res$Z_pca_query
  Zq_corr <- res$Zq_corr
  R_query <- res$R_query

  srt_query[["ref.pca"]] <- SeuratObject::CreateDimReducObject(
    embeddings = Matrix::t(Z_pca_query),
    loadings = ref$loadings,
    stdev = as.numeric(matrixStats::rowSds(Z_pca_query)),
    assay = query_assay,
    key = "refpca_"
  )
  srt_query[["ref.harmony"]] <- SeuratObject::CreateDimReducObject(
    embeddings = Matrix::t(Zq_corr),
    stdev = as.numeric(matrixStats::rowSds(Zq_corr)),
    assay = query_assay,
    key = "refharmony_",
    misc = list(R = R_query)
  )

  log_message("Run UMAP projection", verbose = verbose)
  ref_dims <- seq_len(dim(srt_ref[[ref_harmony]])[2])
  srt_query <- RunKNNMap(
    srt_query = srt_query,
    query_assay = query_assay,
    srt_ref = srt_ref,
    ref_assay = ref_assay,
    ref_group = ref_group,
    ref_umap = ref_umap,
    query_reduction = "ref.harmony",
    ref_reduction = ref_harmony,
    query_dims = ref_dims,
    ref_dims = ref_dims,
    projection_method = projection_method,
    nn_method = nn_method,
    k = k,
    distance_metric = distance_metric,
    vote_fun = vote_fun
  )

  log_message(
    "Run SymphonyMap finished",
    verbose = verbose
  )
  return(srt_query)
}

mapQuery <- function(
  exp_query,
  metadata_query,
  ref_obj,
  vars = NULL,
  sigma = 0.1,
  verbose = TRUE
) {
  log_message(
    "Scaling and synchronizing query gene expression",
    verbose = verbose
  )
  idx_shared_genes <- which(ref_obj$vargenes$symbol %in% rownames(exp_query))
  shared_genes <- ref_obj$vargenes$symbol[idx_shared_genes]
  log_message(
    "Found {.val {length(shared_genes)}} reference variable genes in query object",
    verbose = verbose
  )
  scale_data_with_stats <- get_namespace_fun("symphony", "scaleDataWithStats")
  exp_query_scaled <- scale_data_with_stats(
    exp_query[shared_genes, ],
    ref_obj$vargenes$mean[idx_shared_genes],
    ref_obj$vargenes$stddev[idx_shared_genes],
    1
  )
  exp_query_scaled_sync <- matrix(
    0,
    nrow = length(ref_obj$vargenes$symbol),
    ncol = ncol(exp_query)
  )
  exp_query_scaled_sync[idx_shared_genes, ] <- exp_query_scaled
  rownames(exp_query_scaled_sync) <- ref_obj$vargenes$symbol
  colnames(exp_query_scaled_sync) <- colnames(exp_query)
  log_message(
    "Project query cells using reference gene loadings",
    verbose = verbose
  )
  Z_pca_query <- Matrix::t(ref_obj$loadings) %*% exp_query_scaled_sync
  log_message(
    "Clustering query cells to reference centroids",
    verbose = verbose
  )
  Z_pca_query_cos <- symphony_cosine_normalize(
    V = Z_pca_query,
    dim = 2
  )
  R_query <- get_namespace_fun(
    "symphony", "soft_cluster"
  )(
    Y = ref_obj$centroids,
    Z = Z_pca_query_cos,
    sigma = sigma
  )
  log_message(
    "Correcting query batch effects",
    verbose = verbose
  )
  if (!is.null(vars)) {
    design <- droplevels(metadata_query)[, vars] |> as.data.frame()
    onehot <- design |>
      purrr::map(function(.x) {
        if (length(unique(.x)) == 1) {
          rep(1, length(.x))
        } else {
          stats::model.matrix(~ 0 + .x)
        }
      }) |>
      purrr::reduce(cbind)
    Xq <- cbind(1, intercept = onehot) |> Matrix::t()
  } else {
    Xq <- Matrix::Matrix(
      rbind(rep(1, ncol(Z_pca_query)), rep(1, ncol(Z_pca_query))),
      sparse = TRUE
    )
  }
  Zq_corr <- get_namespace_fun(
    "symphony", "moe_correct_ref"
  )(
    Zq = as_matrix(Z_pca_query),
    Xq = as_matrix(Xq),
    Rq = as_matrix(R_query),
    Nr = as_matrix(ref_obj$cache[[1]]),
    RrZtr = as_matrix(ref_obj$cache[[2]])
  )
  colnames(Z_pca_query) <- row.names(metadata_query)
  rownames(Z_pca_query) <- paste0("PC_", seq_len(nrow(Zq_corr)))
  colnames(Zq_corr) <- row.names(metadata_query)
  rownames(Zq_corr) <- paste0("harmony_", seq_len(nrow(Zq_corr)))

  return(list(Z_pca_query = Z_pca_query, Zq_corr = Zq_corr, R_query = R_query))
}

buildReferenceFromSeurat <- function(
  obj,
  assay = "RNA",
  pca = "pca",
  pca_dims = NULL,
  harmony = "harmony",
  umap = "umap",
  verbose = TRUE
) {
  if (!assay %in% c("RNA", "SCT")) {
    log_message(
      "Only supported assays are RNA or SCT",
      message_type = "error"
    )
  }
  if (is.null(pca_dims)) {
    pca_dims <- seq_len(
      ncol(
        SeuratObject::Embeddings(obj, pca)
      )
    )
  }
  res <- list()
  res$Z_corr <- Matrix::t(
    SeuratObject::Embeddings(obj, harmony)
  )
  res$Z_orig <- Matrix::t(
    SeuratObject::Embeddings(obj, pca)[, pca_dims, drop = FALSE]
  )
  log_message("Saved embeddings")

  res$R <- Matrix::t(obj[[harmony]]@misc$R)
  log_message("Saved soft cluster assignments")

  var_features <- SeuratObject::VariableFeatures(obj)
  var_features <- intersect(
    var_features,
    intersect(rownames(obj[[pca]]@feature.loadings), rownames(obj[[assay]]))
  )

  if (assay == "RNA") {
    var_feature_data <- GetAssayData5(
      obj,
      assay = assay,
      layer = "data"
    )[var_features, , drop = FALSE]
    vargenes_means_sds <- data.frame(
      symbol = var_features,
      mean = Matrix::rowMeans(var_feature_data)
    )

    row_sds <- get_namespace_fun("symphony", "rowSDs")
    vargenes_means_sds$stddev <- row_sds(
      A = var_feature_data,
      row_means = vargenes_means_sds$mean
    )
  } else if (assay == "SCT") {
    var_feature_data <- GetAssayData5(
      obj,
      assay = assay,
      layer = "scale.data"
    )[var_features, , drop = FALSE]
    vargenes_means_sds <- data.frame(
      symbol = var_features,
      mean = Matrix::rowMeans(var_feature_data)
    )
    asdgc <- Matrix::Matrix(
      var_feature_data,
      sparse = TRUE
    )
    row_sds <- get_namespace_fun("symphony", "rowSDs")
    vargenes_means_sds$stddev <- row_sds(
      asdgc,
      vargenes_means_sds$mean
    )
  }

  res$vargenes_means_sds <- vargenes_means_sds
  log_message(
    "Saved variable gene information for {.val {nrow(vargenes_means_sds)}} genes",
    verbose = verbose
  )

  res$loadings <- obj[[pca]]@feature.loadings[var_features, pca_dims, drop = FALSE]
  log_message("Saved PCA loadings", verbose = verbose)

  res$meta_data <- obj@meta.data
  log_message("Saved metadata", verbose = verbose)

  if (is.null(obj[[umap]]@misc$model)) {
    log_message(
      "{.pkg uwot} model not initialiazed in {.cls Seurat}\n",
      "Run {.fn Seurat::RunUMAP} with {.arg umap.method = 'uwot'}, {.arg return.model = TRUE} first",
      message_type = "error"
    )
  }
  res$umap <- obj[[umap]]@misc$model

  log_message(
    "Calculate final L2 normalized reference centroids (Y_cos)",
    verbose = verbose
  )
  res$centroids <- Matrix::t(
    symphony_cosine_normalize(
      V = res$R %*% Matrix::t(res$Z_corr),
      dim = 1
    )
  )
  log_message(
    "Calculate reference compression terms (Nr and C)",
    verbose = verbose
  )
  res$cache <- get_namespace_fun(
    "symphony", "compute_ref_cache"
  )(
    Rr = res$R,
    Zr = res$Z_corr
  )
  colnames(res$Z_orig) <- row.names(res$meta_data)
  rownames(res$Z_orig) <- paste0(
    SeuratObject::Key(
      obj[[pca]]
    ), seq_len(nrow(res$Z_corr))
  )
  colnames(res$Z_corr) <- row.names(res$meta_data)
  rownames(res$Z_corr) <- paste0(
    SeuratObject::Key(
      obj[[harmony]]
    ),
    seq_len(nrow(res$Z_corr))
  )

  return(res)
}

symphony_cosine_normalize <- function(V, dim = 2) {
  normalizer <- tryCatch(
    get_namespace_fun("symphony", "cosine_normalize"),
    error = function(e) NULL
  )
  if (is.function(normalizer)) {
    return(normalizer(V = V, dim = dim))
  }
  if (dim == 1) {
    denom <- sqrt(Matrix::rowSums(V^2))
    denom[denom == 0] <- 1
    return(V / denom)
  }
  if (dim == 2) {
    denom <- sqrt(Matrix::colSums(V^2))
    denom[denom == 0] <- 1
    return(Matrix::t(Matrix::t(V) / denom))
  }
  log_message("{.arg dim} must be 1 or 2", message_type = "error")
}
