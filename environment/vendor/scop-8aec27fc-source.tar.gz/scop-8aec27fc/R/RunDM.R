#' @title Run diffusion map (DM)
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams RunUMAP2
#' @param object An object. This can be a Seurat object or a matrix-like object.
#' @param ndcs A number of diffusion components (dimensions) to be computed.
#' @param sigma The diffusion scale parameter of the Gaussian kernel.
#' Currently supported values are `"local"` (default) and `"global"`.
#' @param k A number of nearest neighbors to be used for the construction of the graph.
#' @param dist.method The distance metric to be used for the construction of the knn graph.
#' Currently supported values are `"euclidean"` and `"cosine"`.
#' @param npcs Number of principal components to use for dimensionality reduction before computing diffusion map.
#' This can speed up computation when using many features.
#' Default is `NULL` (auto-determined based on the number of features).
#' @param reduction.name Reduction to be stored in the Seurat object.
#' @param reduction.key The prefix for the column names of the basis vectors.
#' @param ... Passed to `destiny::DiffusionMap`.
#'
#' @rdname RunDM
#' @export
RunDM <- function(object, ...) {
  UseMethod(generic = "RunDM", object = object)
}

#' @rdname RunDM
#' @method RunDM Seurat
#' @export
RunDM.Seurat <- function(
  object,
  reduction = "pca",
  dims = 1:30,
  features = NULL,
  assay = NULL,
  layer = "data",
  ndcs = 2,
  sigma = "local",
  k = 30,
  dist.method = "euclidean",
  npcs = NULL,
  reduction.name = "dm",
  reduction.key = "DM_",
  verbose = TRUE,
  seed.use = 11,
  ...
) {
  log_message(
    "Running {.pkg destiny::DiffusionMap}",
    message_type = "running",
    verbose = verbose
  )
  check_r("destiny", verbose = FALSE)
  if (!is.null(features)) {
    assay <- assay %||% SeuratObject::DefaultAssay(object = object)
    data_use <- as_matrix(
      Matrix::t(
        GetAssayData5(
          object = object,
          layer = layer,
          assay = assay
        )[features, ]
      )
    )
    if (ncol(data_use) < ndcs) {
      log_message(
        "Please provide as many or more features than ndcs: {.val {length(features)}}",
        " features provided, {.val {ndcs}} Diffusion components requested",
        message_type = "error"
      )
    }
    if (is.null(npcs) && ncol(data_use) > 1000) {
      npcs <- min(50, ncol(data_use))
      if (verbose) {
        log_message(
          "Using {.val {npcs}} principal components to speed up computation",
          " (provided {.val {ncol(data_use)}} features)"
        )
      }
    }
  } else if (!is.null(dims)) {
    reduction <- DefaultReduction(
      object,
      pattern = reduction
    )
    data_use <- SeuratObject::Embeddings(object[[reduction]])[, dims]
    assay <- SeuratObject::DefaultAssay(object = object[[reduction]])
    if (length(dims) < ndcs) {
      log_message(
        "Please provide as many or more dims than ndcs: {.val {length(dims)}}",
        " dims provided, {.val {ndcs}} DiffusionMap components requested",
        message_type = "error"
      )
    }
  } else {
    log_message(
      "Please specify one of {.arg dims} and {.arg features}",
      message_type = "error"
    )
  }

  object[[reduction.name]] <- RunDM(
    object = data_use,
    assay = assay,
    layer = layer,
    ndcs = ndcs,
    sigma = sigma,
    k = k,
    dist.method = dist.method,
    npcs = npcs,
    reduction.key = reduction.key,
    seed.use = seed.use,
    verbose = verbose,
    ...
  )
  object <- Seurat::LogSeuratCommand(object = object)
  log_message(
    "{.pkg destiny::DiffusionMap} computed successfully and set {.val {reduction.name}} reduction",
    message_type = "success",
    verbose = verbose
  )

  return(object)
}

#' @rdname RunDM
#' @method RunDM default
#' @export
RunDM.default <- function(
  object,
  assay = NULL,
  layer = "data",
  ndcs = 2,
  sigma = "local",
  k = 30,
  dist.method = "euclidean",
  npcs = NULL,
  reduction.key = "DM_",
  verbose = TRUE,
  seed.use = 11,
  ...
) {
  check_r("destiny", verbose = FALSE)

  set.seed(seed = seed.use)
  dm_args <- list(
    data = object,
    n_eigs = ndcs,
    sigma = sigma,
    k = k,
    distance = dist.method,
    verbose = FALSE
  )
  if (!is.null(npcs)) {
    dm_args$n_pcs <- npcs
  }
  dm_results <- do.call(
    get_namespace_fun("destiny", "DiffusionMap"),
    c(dm_args, list(...))
  )

  embeddings <- dm_results@eigenvectors
  rownames(embeddings) <- rownames(object)
  colnames(embeddings) <- paste0(reduction.key, 1:ndcs)
  reduction <- SeuratObject::CreateDimReducObject(
    embeddings = embeddings,
    assay = assay,
    key = reduction.key,
    misc = list(
      slot = layer,
      dm.results = dm_results
    )
  )
  return(reduction)
}
