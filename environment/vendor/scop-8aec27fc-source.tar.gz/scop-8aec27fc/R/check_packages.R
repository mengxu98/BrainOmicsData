#' @title Check and install python packages
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams PrepareEnv
#' @param packages Package names to check and install.
#' Use `"<package>==<version>"` to request a specific version.
#' @param force Whether to force package reinstallation.
#' @param pip Whether to use `pip`/`uv` (`TRUE`) or the configured
#' conda-compatible environment manager (`FALSE`) for installation.
#' Default is `TRUE`. When `TRUE`, uv is used as the primary installer with pip as fallback.
#' @param pip_options Additional command line arguments to be passed to `uv`/`pip` when `pip = TRUE`.
#' @param ... Other arguments to be passed to other functions.
#'
#' @export
#'
#' @examples
#' \dontrun{
#' PrepareEnv()
#'
#' # Then check/install packages
#' check_python(
#'   packages = c("numpy", "pandas")
#' )
#'
#' check_python(
#'   packages = "numpy==1.26.4",
#'   envname = "scop_env",
#'   pip_options = "-i https://pypi.tuna.tsinghua.edu.cn/simple"
#' )
#' }
check_python <- function(
  packages,
  envname = NULL,
  conda = "auto",
  force = FALSE,
  pip = TRUE,
  pip_options = character(),
  verbose = TRUE,
  ...
) {
  envname <- get_envname(envname)
  conda <- resolve_conda(conda)
  packages <- unique_python_requirements(
    packages,
    envname = envname,
    conda = conda
  )
  pip_options <- normalize_cli_args(pip_options)

  env <- env_exist(conda = conda, envname = envname)
  if (isFALSE(env)) {
    log_message(
      "Python environment {.val {envname}} not found. Run {.fn PrepareEnv} first",
      message_type = "error"
    )
  }

  if (isTRUE(force)) {
    pkg_installed <- stats::setNames(
      rep(FALSE, length(packages)),
      packages
    )
    pip_options <- c(pip_options, "--force-reinstall")
  } else {
    pkg_installed <- exist_python_pkgs(
      packages = packages,
      envname = envname,
      conda = conda,
      verbose = verbose
    )
  }

  if (sum(!pkg_installed) > 0) {
    pkgs_to_install <- names(pkg_installed)[!pkg_installed]
    log_message(
      "Try to install: {.pkg {pkgs_to_install}}",
      verbose = verbose
    )
    tryCatch(
      expr = {
        conda_install(
          conda = conda,
          packages = pkgs_to_install,
          envname = envname,
          pip = pip,
          pip_options = pip_options,
          ...
        )
      },
      error = identity
    )

    pkg_installed <- exist_python_pkgs(
      packages = packages,
      envname = envname,
      conda = conda,
      verbose = verbose
    )
  }

  if (sum(!pkg_installed) > 0) {
    failed_pkgs <- names(pkg_installed)[!pkg_installed]
    log_message(
      "Failed to install: {.pkg {failed_pkgs}} into the environment {.file {envname}}. Please install manually",
      message_type = "warning",
      verbose = verbose
    )
    return(invisible(FALSE))
  } else {
    return(invisible(TRUE))
  }
}

exist_python_pkgs <- function(
  packages,
  envname = NULL,
  conda = "auto",
  verbose = TRUE
) {
  envname <- get_envname(envname)
  conda <- resolve_conda(conda)

  if (!ensure_conda(conda)) {
    return(invisible(FALSE))
  }

  env <- env_exist(conda = conda, envname = envname)
  if (isFALSE(env)) {
    log_message(
      "Cannot find the conda-compatible Python environment: {.file {envname}}",
      message_type = "error"
    )
  }

  log_message(
    "Checking {.val {length(packages)}} package{?s} in environment: {.file {envname}}",
    verbose = verbose
  )

  all_installed <- tryCatch(
    {
      installed_python_pkgs(
        envname = envname,
        conda = conda,
        verbose = verbose
      )
    },
    error = function(e) {
      log_message(
        "Failed to get installed packages: {.val {e$message}}",
        message_type = "warning",
        verbose = verbose
      )
    }
  )

  packages_installed <- stats::setNames(
    rep(FALSE, length(packages)),
    packages
  )
  if (is.null(all_installed) || is.null(all_installed$package)) {
    return(packages_installed)
  }

  requirements <- env_requirements(
    include_optional = TRUE
  )
  pkg_name_mapping <- requirements$package_aliases

  installed_package_names <- canonical_python_distribution_name(
    all_installed$package
  )

  for (i in seq_along(packages)) {
    pkg <- packages[i]
    requirement <- parse_python_requirement(pkg, fallback_name = names(pkg))
    pkg_name <- requirement$name
    pkg_version <- requirement$version
    pkg_operator <- requirement$operator

    check_pkg_names <- pkg_name
    if (length(pkg_name_mapping) > 0) {
      if (pkg_name %in% names(pkg_name_mapping)) {
        actual_name <- pkg_name_mapping[[pkg_name]]
        check_pkg_names <- c(pkg_name, actual_name)
      }
      if (pkg_name %in% pkg_name_mapping) {
        logical_name <- names(pkg_name_mapping)[pkg_name_mapping == pkg_name]
        check_pkg_names <- unique(c(check_pkg_names, logical_name))
      }
    }

    found_pkg_name <- NULL
    installed_index <- match(
      canonical_python_distribution_name(check_pkg_names),
      installed_package_names
    )
    installed_index <- installed_index[!is.na(installed_index)]
    if (length(installed_index) > 0L) {
      found_pkg_name <- all_installed$package[[installed_index[[1L]]]]
    }

    if (!is.null(found_pkg_name)) {
      if (!is.na(pkg_version)) {
        installed_version <- unique(all_installed$version[
          all_installed$package == found_pkg_name
        ])
        version_match <- version_satisfies_requirement(
          installed_version = installed_version,
          required_version = pkg_version,
          operator = pkg_operator
        )

        if (version_match) {
          log_message(
            "{.pkg {pkg_name}} {.pkg {pkg_operator}} {.pkg {pkg_version}}",
            message_type = "success",
            verbose = verbose
          )
        } else {
          log_message(
            "{.pkg {pkg_name}} found but version mismatch: installed {.pkg {paste(installed_version, collapse = ', ')}}, required {.pkg {pkg_operator}} {.pkg {pkg_version}}",
            message_type = "warning",
            verbose = verbose
          )
        }

        packages_installed[pkg] <- version_match
      } else {
        packages_installed[pkg] <- TRUE
        installed_version <- unique(all_installed$version[
          all_installed$package == found_pkg_name
        ])
        log_message(
          "{.pkg {pkg_name}} version: {.pkg {paste(installed_version, collapse = ', ')}}",
          message_type = "success",
          verbose = verbose
        )
      }
    } else {
      packages_installed[pkg] <- FALSE
      log_message(
        "{.pkg {pkg_name}} not found",
        message_type = "warning",
        verbose = verbose
      )
    }
  }

  return(packages_installed)
}

canonical_python_distribution_name <- function(name) {
  tolower(gsub("[-_.]+", "-", trimws(as.character(name))))
}

unique_python_requirements <- function(
  packages,
  envname = NULL,
  conda = "auto"
) {
  packages <- resolve_requested_python_packages(
    packages,
    envname = envname,
    conda = conda
  )
  packages[!duplicated(unname(packages))]
}

resolve_requested_python_packages <- function(
  packages,
  envname = NULL,
  conda = "auto"
) {
  envname <- get_envname(envname)
  conda <- resolve_conda(conda)
  python_path <- tryCatch(
    conda_python(envname = envname, conda = conda),
    error = function(...) NULL
  )
  actual_minor <- python_minor_version(python_path)
  version <- if (isTRUE(actual_minor %in% c("3.10", "3.11", "3.12"))) {
    paste0(actual_minor, "-1")
  } else {
    if (is_windows()) "3.11-1" else "3.10-1"
  }
  requirements <- env_requirements(
    version = version,
    include_optional = TRUE
  )
  package_versions <- requirements$packages

  resolved <- vapply(
    packages,
    function(pkg) {
      requirement <- parse_python_requirement(pkg)
      if (
        !is.na(requirement$operator) ||
          !requirement$name %in% names(package_versions)
      ) {
        return(pkg)
      }
      unname(package_versions[[requirement$name]])
    },
    character(1),
    USE.NAMES = FALSE
  )

  stats::setNames(resolved, names(packages))
}

parse_python_requirement <- function(pkg, fallback_name = NULL) {
  requirement_name <- function(name) {
    sub("\\[.*\\]$", "", trimws(as.character(name)))
  }

  if (grepl("^git\\+", pkg)) {
    pkg_name <- fallback_name %||%
      basename(strsplit(pkg, "@", fixed = TRUE)[[1]][1])
    pkg_name <- sub("\\.git$", "", pkg_name)
    return(list(
      name = pkg_name,
      operator = NA_character_,
      version = NA_character_
    ))
  }

  match <- regexec("^([^<>=!~]+?)\\s*([<>=!~]{1,2})\\s*(.+)$", pkg, perl = TRUE)
  parts <- regmatches(pkg, match)[[1]]
  if (length(parts) == 4) {
    return(list(
      name = fallback_name %||% requirement_name(parts[2]),
      operator = trimws(parts[3]),
      version = trimws(parts[4])
    ))
  }

  list(
    name = fallback_name %||% requirement_name(pkg),
    operator = NA_character_,
    version = NA_character_
  )
}

normalize_package_version <- function(version) {
  version <- trimws(as.character(version))
  sub("^v", "", version)
}

compare_versions_safe <- function(installed_version, required_version) {
  installed_version <- normalize_package_version(installed_version)
  required_version <- normalize_package_version(required_version)

  vapply(
    installed_version,
    function(version) {
      tryCatch(
        suppressWarnings(
          as.integer(utils::compareVersion(version, required_version))
        ),
        error = function(e) {
          if (identical(version, required_version)) {
            0L
          } else {
            NA_integer_
          }
        }
      )
    },
    integer(1)
  )
}

version_satisfies_requirement <- function(
  installed_version,
  required_version,
  operator
) {
  if (is.na(required_version) || is.na(operator) || !nzchar(required_version)) {
    return(TRUE)
  }

  comparison <- compare_versions_safe(installed_version, required_version)
  if (all(is.na(comparison))) {
    return(FALSE)
  }

  any(
    switch(operator,
      "==" = comparison == 0L,
      "=" = comparison == 0L,
      ">=" = comparison >= 0L,
      "<=" = comparison <= 0L,
      ">" = comparison > 0L,
      "<" = comparison < 0L,
      "!=" = comparison != 0L,
      "~=" = comparison >= 0L,
      FALSE
    ),
    na.rm = TRUE
  )
}

installed_python_pkgs <- function(
  envname = NULL,
  conda = "auto",
  verbose = TRUE
) {
  envname <- get_envname(envname)
  conda <- resolve_conda(conda)

  if (!ensure_conda(conda)) {
    return(invisible(NULL))
  }

  env <- env_exist(conda = conda, envname = envname)
  if (isFALSE(env)) {
    log_message(
      "Cannot find the conda-compatible Python environment: {.file {envname}}",
      message_type = "error"
    )
  }

  log_message(
    "Retrieving package list for environment: {.file {envname}}",
    verbose = verbose
  )

  all_installed <- tryCatch(
    {
      all_installed <- get_namespace_fun(
        "reticulate",
        "conda_list_packages"
      )(
        conda = conda,
        envname = envname,
        no_pip = FALSE
      )
      log_message(
        "Found {.val {nrow(all_installed)}} packages installed",
        verbose = verbose
      )
      normalize_installed_package_table(all_installed)
    },
    error = function(e) {
      log_message(
        "Failed to retrieve package list via reticulate: {.val {e$message}}",
        message_type = "warning",
        verbose = verbose
      )
      NULL
    }
  )

  pip_installed <- installed_python_pkgs_pip(
    envname = envname,
    conda = conda
  )

  if (!is.null(all_installed)) {
    return(merge_installed_package_tables(all_installed, pip_installed))
  }

  all_installed <- installed_python_pkgs_cli(
    envname = envname,
    conda = conda
  )
  if (!is.null(all_installed)) {
    all_installed <- merge_installed_package_tables(all_installed, pip_installed)
    log_message(
      "Found {.val {nrow(all_installed)}} packages installed",
      verbose = verbose
    )
    return(all_installed)
  }

  log_message(
    "Failed to retrieve package list from environment: {.file {envname}}",
    message_type = "error"
  )
}

normalize_installed_package_table <- function(packages) {
  if (is.null(packages) || !is.data.frame(packages) || nrow(packages) == 0) {
    return(NULL)
  }

  package <- packages[["package"]] %||% packages[["name"]]
  version <- packages[["version"]] %||% rep(NA_character_, length(package))
  if (is.null(package)) {
    return(NULL)
  }

  data.frame(
    package = as.character(package),
    version = as.character(version),
    stringsAsFactors = FALSE
  )
}

merge_installed_package_tables <- function(...) {
  tables <- list(...)
  tables <- lapply(tables, normalize_installed_package_table)
  tables <- tables[!vapply(tables, is.null, logical(1))]
  if (length(tables) == 0) {
    return(NULL)
  }

  merged <- do.call(rbind, tables)
  key <- tolower(merged$package)
  merged <- merged[!duplicated(key, fromLast = TRUE), , drop = FALSE]
  rownames(merged) <- NULL
  merged
}

installed_python_pkgs_cli <- function(envname, conda) {
  env_path <- conda_env_path(envname = envname, conda = conda)
  list_args <- list()
  if (!is.null(env_path) && dir.exists(env_path)) {
    list_args <- c(list_args, list(c("list", "--prefix", env_path, "--json")))
  }
  list_args <- c(list_args, list(c("list", "--name", envname, "--json")))

  for (args in list_args) {
    packages <- normalize_installed_package_table(
      run_conda_json(conda, args)
    )
    if (!is.null(packages)) {
      return(packages)
    }
  }

  python <- resolve_python_executable(
    envname = envname,
    conda = conda,
    error_if_missing = FALSE
  )
  if (is.null(python) || !file.exists(python)) {
    return(NULL)
  }

  output <- tryCatch(
    suppressWarnings(system2(
      python,
      c("-m", "pip", "list", "--format=json"),
      stdout = TRUE,
      stderr = FALSE
    )),
    error = function(...) NULL
  )
  status <- attr(output, "status") %||% 0L
  if (!identical(status, 0L)) {
    return(NULL)
  }

  normalize_installed_package_table(
    parse_conda_json_output(output)
  )
}

installed_python_pkgs_pip <- function(envname, conda) {
  python <- resolve_python_executable(
    envname = envname,
    conda = conda,
    error_if_missing = FALSE
  )
  if (is.null(python) || !file.exists(python)) {
    return(NULL)
  }

  output <- tryCatch(
    suppressWarnings(system2(
      python,
      c("-m", "pip", "list", "--format=json"),
      stdout = TRUE,
      stderr = FALSE
    )),
    error = function(...) NULL
  )
  status <- attr(output, "status") %||% 0L
  if (!identical(status, 0L)) {
    return(NULL)
  }

  normalize_installed_package_table(
    parse_conda_json_output(output)
  )
}

#' @title Remove Python packages from a conda-compatible Python environment
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams PrepareEnv
#' @param packages Package names to remove.
#' @param pip Whether to use pip for package removal.
#' Default is `FALSE` (use conda).
#' @param force Whether to force removal without confirmation.
#'
#' @return Invisibly returns.
#'
#' @export
#'
#' @examples
#' \dontrun{
#' # Remove a single package using conda
#' remove_python("numpy")
#'
#' # Remove multiple packages using conda
#' remove_python(c("numpy", "pandas"))
#'
#' # Remove packages using pip
#' remove_python("numpy", pip = TRUE)
#'
#' # Force removal without confirmation
#' remove_python("numpy", force = TRUE)
#'
#' # Remove packages from a specific environment
#' remove_python("numpy", envname = "env")
#' }
remove_python <- function(
  packages,
  envname = NULL,
  conda = "auto",
  pip = FALSE,
  force = FALSE,
  verbose = TRUE
) {
  envname <- get_envname(envname)
  system2t <- get_namespace_fun("reticulate", "system2t")
  log_message(
    "Removing {.pkg {packages}} from environment: {.file {envname}}",
    verbose = verbose
  )

  conda <- resolve_conda(conda)
  manager <- conda_manager_type(conda)
  if (!ensure_conda(conda)) {
    return(invisible(FALSE))
  }

  env_exists <- env_exist(envname = envname, conda = conda)
  if (isFALSE(env_exists)) {
    log_message(
      "Cannot find the conda-compatible Python environment: {.file {envname}}",
      message_type = "error"
    )
    return(invisible(FALSE))
  }

  if (!force) {
    if (interactive()) {
      response <- readline(
        paste0(
          "Are you sure you want to remove these packages from environment '",
          envname,
          "'? (y/N): "
        )
      )
      if (!tolower(response) %in% c("y", "yes")) {
        log_message(
          "{.pkg {packages}} removal cancelled",
          message_type = "warning",
          verbose = verbose
        )
        return(invisible(FALSE))
      }
    } else {
      log_message(
        "Automatically remove {.pkg {packages}} in non-interactive mode",
        message_type = "warning",
        verbose = verbose
      )
    }
  }

  python <- resolve_python_executable(
    envname = envname,
    conda = conda,
    error_message = "Failed to get Python path"
  )

  if (is.null(python)) {
    return(invisible(FALSE))
  }

  remove_many_python_packages <- function(packages, uv = NULL) {
    statuses <- vapply(
      packages,
      remove_single_python_package,
      logical(1),
      python = python,
      uv = uv,
      verbose = verbose
    )
    all(statuses)
  }

  if (pip) {
    result <- remove_pkg(
      packages,
      python,
      envname,
      conda,
      verbose
    )
  } else {
    log_message(
      "Removing {.pkg {packages}} via {.pkg {manager}}...",
      verbose = verbose
    )

    result <- tryCatch(
      {
        conda_args <- get_namespace_fun("reticulate", "conda_args")
        args <- conda_args("remove", envname)
        args <- c(args, packages)

        status <- system2t(conda, shQuote(args))

        if (status != 0L) {
          log_message(
            "{.pkg {packages}} removal failed via {.pkg {manager}} with error code: {.val {status}}",
            message_type = "warning",
            verbose = verbose
          )
          FALSE
        } else {
          log_message(
            "{.pkg {packages}} removed successfully via {.pkg {manager}}",
            message_type = "success",
            verbose = verbose
          )
          TRUE
        }
      },
      error = function(e) {
        log_message(
          "{.pkg {manager}} removal failed: {.val {e$message}}",
          message_type = "warning",
          verbose = verbose
        )
        FALSE
      }
    )

    if (!result && !pip) {
      log_message(
        "{.pkg {packages}} removal failed via {.pkg {manager}}, trying {.pkg uv} as fallback...",
        message_type = "warning",
        verbose = verbose
      )

      result <- tryCatch(
        {
          uv <- find_uv(
            python = python,
            envname = envname,
            conda = conda,
            auto_install = TRUE
          )

          if (is.null(uv)) {
            log_message(
              "{.pkg uv} not found and installation failed, falling back to {.pkg pip}",
              message_type = "warning"
            )
            remove_many_python_packages(packages, uv = NULL)
          } else {
            remove_many_python_packages(packages, uv = uv)
          }
        },
        error = function(e) {
          log_message(
            "{.pkg {packages}} removal failed via {.pkg uv} as fallback: {.val {e$message}}",
            message_type = "error"
          )
          FALSE
        }
      )
    }
  }

  if (result) {
    log_message(
      "{.pkg {packages}} removal completed successfully",
      message_type = "success",
      verbose = verbose
    )
  } else {
    log_message(
      "{.pkg {packages}} removal failed",
      message_type = "warning",
      verbose = verbose
    )
  }

  return(invisible(result))
}

remove_pkg <- function(
  packages,
  python,
  envname,
  conda,
  verbose
) {
  uv <- find_uv(
    python = python,
    envname = envname,
    conda = conda,
    auto_install = TRUE
  )

  if (!is.null(uv)) {
    log_message(
      "Removing {.pkg {packages}} via {.pkg uv}...",
      verbose = verbose
    )

    statuses <- vapply(
      packages,
      remove_single_python_package,
      logical(1),
      python = python,
      uv = uv,
      verbose = verbose
    )

    if (all(statuses)) {
      log_message(
        "{.pkg {packages}} removed successfully via {.pkg uv}",
        message_type = "success",
        verbose = verbose
      )
      return(TRUE)
    } else {
      log_message(
        "{.pkg uv} removal failed, falling back to {.pkg pip}...",
        message_type = "warning",
        verbose = verbose
      )
    }
  } else {
    log_message(
      "{.pkg uv} not found, falling back to {.pkg pip}...",
      message_type = "warning",
      verbose = verbose
    )
  }

  log_message(
    "Removing {.pkg {packages}} via {.pkg pip}...",
    verbose = verbose
  )
  statuses <- vapply(
    packages,
    remove_single_python_package,
    logical(1),
    python = python,
    uv = NULL,
    verbose = verbose
  )

  if (all(statuses)) {
    log_message(
      "{.pkg {packages}} removed successfully via {.pkg pip}",
      message_type = "success",
      verbose = verbose
    )
    return(TRUE)
  } else {
    log_message(
      "Failed to remove {.pkg {packages}} via {.pkg pip}",
      message_type = "warning",
      verbose = verbose
    )
    return(FALSE)
  }
}

remove_single_python_package <- function(
  pkg,
  python,
  uv = NULL,
  verbose = TRUE
) {
  if (!is.null(uv)) {
    log_message(
      "Removing {.pkg {pkg}} via {.pkg uv}...",
      verbose = verbose
    )

    args <- c("pip", "uninstall")
    if (uv != "python -m uv") {
      args <- c(args, "--python", python)
    }
    args <- c(args, pkg)

    status <- run_uv_command(uv, python, args)
    if (status == 0L) {
      log_message(
        "{.pkg {pkg}} removed successfully via {.pkg uv}",
        message_type = "success",
        verbose = verbose
      )
      return(TRUE)
    }

    log_message(
      "Failed to remove {.pkg {pkg}} via {.pkg uv} [error code {.val {status}}], trying {.pkg pip} as fallback...",
      message_type = "warning",
      verbose = verbose
    )
  }

  log_message(
    "Removing {.pkg {pkg}} via {.pkg pip}...",
    verbose = verbose
  )
  status <- {
    .pip_cmd <- python
    .pip_args <- c("uninstall", "-y", pkg)
    .system2t <- get_namespace_fun("reticulate", "system2t")
    .system2t(.pip_cmd, shQuote(c("-m", "pip", .pip_args)))
  }

  if (status == 0L) {
    log_message(
      "{.pkg {pkg}} removed successfully via {.pkg pip}",
      message_type = "success",
      verbose = verbose
    )
    return(TRUE)
  }

  log_message(
    "{.pkg {pkg}} removal failed via {.pkg pip} [error code {.val {status}}]",
    message_type = "warning",
    verbose = verbose
  )
  FALSE
}
