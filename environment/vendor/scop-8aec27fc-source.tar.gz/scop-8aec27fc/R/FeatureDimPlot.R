#' @title Feature values on a 2D reduction
#'
#' @description
#' Color cells on a dimensionality reduction by feature values (assay genes or
#' numeric metadata).
#'
#' @md
#' @inheritParams scop-params
#' @inheritParams CellDimPlot
#' @param lineages_trim,lineages_span,lineages_palcolor,lineages_arrow,lineages_linewidth,lineages_line_bg,lineages_line_bg_stroke,lineages_whiskers,lineages_whiskers_linewidth,lineages_whiskers_alpha
#' Pseudotime lineages as [stats::loess] curves. See [grid::arrow] for `lineages_arrow`.
#' @param edge_size,edge_alpha,edge_color Neighbor-graph edges.
#' @param legend.title Title of the legend. `NULL` uses the group name.
#' @param alpha.highlight,stroke.highlight Transparency and stroke width of the highlighted points.
#' @param theme_use Theme name or function.
#' @param features Features to plot: a character vector or a named list of
#' assay gene names or numeric metadata columns.
#' @param layer Assay layer to use.
#' @param keep_scale Color scale across panels:
#' \itemize{
#'   \item `NULL`: each panel is scaled independently (not comparable).
#'   \item `"feature"`: scale each feature across `split.by` panels.
#'   \item `"all"`: one scale for every feature and panel.
#' }
#' @param calculate_coexp Plot the geometric mean of the features.
#' @param compare_features Show multiple features on one plot.
#' @param color_blend_mode Blend mode when `compare_features = TRUE`.
#' @param bg_cutoff Values below this cutoff are colored with `bg_color`.
#' @param lower_quantile,upper_quantile,lower_cutoff,upper_cutoff Per-feature
#' quantile or absolute cutoffs for the color scale.
#' @param label Label high-expressing cells.
#' @param label_insitu Use feature names instead of numbers when
#' `compare_features = TRUE`.
#' @param hex.color Border color of hexagonal bins.
#' @param title.face Font face of individual feature headings. `NULL` (default)
#' uses italic for assay genes and plain for numeric metadata or embeddings.
#' Set to `"plain"`, `"bold"`, `"italic"`, or `"bold.italic"` to override.
#' @param title.color Color of individual feature headings: `NULL` inherits the
#' theme, an unnamed color applies to every feature, or a named color vector
#' maps feature names to colors. Unspecified features inherit the theme. Names
#' refer to features, not group names or panel order. These heading options do
#' not affect the custom `title`, split labels, expression palette, or blended
#' panels (`compare_features = TRUE`).
#' @param force Draw even when more than 100 features are requested.
#'
#' @seealso [CellDimPlot]
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "G2M_score", reduction = "UMAP"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "G2M_score",
#'   reduction = "UMAP",
#'   bg_cutoff = -Inf
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "G2M_score",
#'   reduction = "UMAP",
#'   theme_use = "theme_blank"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "G2M_score",
#'   reduction = "UMAP",
#'   theme_use = ggplot2::theme_classic,
#'   theme_args = list(base_size = 16)
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "G2M_score",
#'   reduction = "UMAP"
#' ) |> thisplot::panel_fix(
#'   height = 2,
#'   raster = TRUE,
#'   dpi = 30
#' )
#'
#' # Label and highlight cell points
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   reduction = "UMAP",
#'   label = TRUE,
#'   cells.highlight = colnames(
#'     pancreas_sub
#'   )[pancreas_sub$SubCellType == "Delta"]
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   split.by = "Phase",
#'   reduction = "UMAP",
#'   cells.highlight = TRUE,
#'   theme_use = "theme_blank"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub, features = c("Rbp4", "Sst"), reduction = "UMAP",
#'   title.color = c(Rbp4 = "#2A6F97", Sst = "#B14B28")
#' )
#'
#' # Add a density layer
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   reduction = "UMAP",
#'   label = TRUE,
#'   add_density = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   reduction = "UMAP",
#'   label = TRUE,
#'   add_density = TRUE,
#'   density_filled = TRUE
#' )
#'
#' # Chane the plot type from point to the hexagonal bin
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   reduction = "UMAP",
#'   hex = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Rbp4",
#'   reduction = "UMAP",
#'   hex = TRUE,
#'   hex.bins = 20
#' )
#'
#' # Show lineages on the plot based on the pseudotime
#' pancreas_sub <- RunSlingshot(
#'   pancreas_sub,
#'   group.by = "SubCellType",
#'   reduction = "UMAP"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Lineage2",
#'   reduction = "UMAP",
#'   lineages = "Lineage2"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Lineage2",
#'   reduction = "UMAP",
#'   lineages = "Lineage2",
#'   lineages_whiskers = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = "Lineage2",
#'   reduction = "UMAP",
#'   lineages = "Lineage2",
#'   lineages_span = 0.1
#' )
#'
#' # Input a named feature list
#' markers <- list(
#'   "Ductal" = c("Sox9", "Anxa2", "Bicc1"),
#'   "EPs" = c("Neurog3", "Hes6"),
#'   "Pre-endocrine" = c("Fev", "Neurod1"),
#'   "Endocrine" = c("Rbp4", "Pyy"),
#'   "Beta" = "Ins1",
#'   "Alpha" = "Gcg",
#'   "Delta" = "Sst",
#'   "Epsilon" = "Ghrl"
#' )
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = markers,
#'   reduction = "UMAP",
#'   theme_use = "theme_blank",
#'   theme_args = list(
#'     plot.subtitle = ggplot2::element_text(size = 10),
#'     strip.text = ggplot2::element_text(size = 8)
#'   )
#' )
#'
#' # Plot multiple features with different scales
#' endocrine_markers <- c(
#'   "Beta" = "Ins1",
#'   "Alpha" = "Gcg",
#'   "Delta" = "Sst",
#'   "Epsilon" = "Ghrl"
#' )
#' FeatureDimPlot(
#'   pancreas_sub,
#'   endocrine_markers,
#'   reduction = "UMAP"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   endocrine_markers,
#'   reduction = "UMAP",
#'   lower_quantile = 0,
#'   upper_quantile = 0.8
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   endocrine_markers,
#'   reduction = "UMAP",
#'   lower_cutoff = 1,
#'   upper_cutoff = 4
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   endocrine_markers,
#'   reduction = "UMAP",
#'   keep_scale = "all"
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   c("Delta" = "Sst", "Epsilon" = "Ghrl"),
#'   split.by = "Phase",
#'   reduction = "UMAP",
#'   keep_scale = "feature"
#' )
#'
#' # Plot multiple features on one picture
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = endocrine_markers,
#'   pt.size = 1,
#'   compare_features = TRUE,
#'   color_blend_mode = "blend",
#'   label = TRUE,
#'   label_insitu = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = c("S_score", "G2M_score"),
#'   pt.size = 1,
#'   palcolor = c("red", "green"),
#'   compare_features = TRUE,
#'   color_blend_mode = "blend",
#'   title = "blend",
#'   label = TRUE,
#'   label_insitu = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = c("S_score", "G2M_score"),
#'   pt.size = 1,
#'   palcolor = c("red", "green"),
#'   compare_features = TRUE,
#'   color_blend_mode = "average",
#'   title = "average",
#'   label = TRUE,
#'   label_insitu = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = c("S_score", "G2M_score"),
#'   pt.size = 1,
#'   palcolor = c("red", "green"),
#'   compare_features = TRUE,
#'   color_blend_mode = "screen",
#'   title = "screen",
#'   label = TRUE,
#'   label_insitu = TRUE
#' )
#'
#' FeatureDimPlot(
#'   pancreas_sub,
#'   features = c("S_score", "G2M_score"),
#'   pt.size = 1,
#'   palcolor = c("red", "green"),
#'   compare_features = TRUE,
#'   color_blend_mode = "multiply",
#'   title = "multiply",
#'   label = TRUE,
#'   label_insitu = TRUE
#' )
FeatureDimPlot <- function(
  object,
  features,
  reduction = NULL,
  dims = c(1, 2),
  split.by = NULL,
  cells = NULL,
  layer = "data",
  assay = NULL,
  show_stat = ifelse(identical(theme_use, "theme_blank"), FALSE, TRUE),
  palette = ifelse(isTRUE(compare_features), "Set1", "Spectral"),
  palcolor = NULL,
  pt.size = NULL,
  pt.alpha = 1,
  bg_cutoff = 0,
  bg_color = "grey80",
  keep_scale = "feature",
  lower_quantile = 0,
  upper_quantile = 0.99,
  lower_cutoff = NULL,
  upper_cutoff = NULL,
  add_density = FALSE,
  density_color = "grey80",
  density_filled = FALSE,
  density_filled_palette = "Greys",
  density_filled_palcolor = NULL,
  cells.highlight = NULL,
  cols.highlight = "black",
  sizes.highlight = 1,
  alpha.highlight = 1,
  stroke.highlight = 0.5,
  calculate_coexp = FALSE,
  compare_features = FALSE,
  color_blend_mode = c("blend", "average", "screen", "multiply"),
  label = FALSE,
  label.size = 4,
  label.fg = "white",
  label.bg = "black",
  label.bg.r = 0.1,
  label_insitu = FALSE,
  label_repel = FALSE,
  label_repulsion = 20,
  label_point_size = 1,
  label_point_color = "black",
  label_segment_color = "black",
  lineages = NULL,
  lineages_trim = c(0.01, 0.99),
  lineages_span = 0.75,
  lineages_palette = "Dark2",
  lineages_palcolor = NULL,
  lineages_arrow = grid::arrow(length = grid::unit(0.1, "inches")),
  lineages_linewidth = 1,
  lineages_line_bg = "white",
  lineages_line_bg_stroke = 0.5,
  lineages_whiskers = FALSE,
  lineages_whiskers_linewidth = 0.5,
  lineages_whiskers_alpha = 0.5,
  graph = NULL,
  edge_size = c(0.05, 0.5),
  edge_alpha = 0.1,
  edge_color = "grey40",
  hex = FALSE,
  hex.linewidth = 0.5,
  hex.color = "grey90",
  hex.bins = 50,
  hex.binwidth = NULL,
  raster = NULL,
  raster.dpi = c(512, 512),
  aspect.ratio = 1,
  title = NULL,
  subtitle = NULL,
  xlab = NULL,
  ylab = NULL,
  legend.position = "right",
  legend.direction = "vertical",
  legend.title = NULL,
  theme_use = "theme_scop",
  theme_args = list(),
  combine = TRUE,
  nrow = NULL,
  ncol = NULL,
  byrow = TRUE,
  force = FALSE,
  seed = 11,
  verbose = TRUE,
  srt = NULL,
  title.face = NULL,
  title.color = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  set.seed(seed)
  if (!is.null(title.face)) {
    title.face <- match.arg(title.face, c("plain", "bold", "italic", "bold.italic"))
  }
  if (!is.null(title.color)) {
    if (!is.character(title.color) || !length(title.color) || anyNA(title.color) ||
        (is.null(names(title.color)) && length(title.color) != 1L) ||
        (!is.null(names(title.color)) &&
          (anyNA(names(title.color)) || any(!nzchar(names(title.color))) ||
            anyDuplicated(names(title.color))))) {
      stop("title.color must be one unnamed color or a uniquely named feature-color vector.")
    }
    tryCatch(grDevices::col2rgb(title.color), error = function(e) {
      stop("title.color contains an invalid color.")
    })
  }
  color_blend_mode <- match.arg(color_blend_mode)
  if (!is.null(keep_scale)) {
    keep_scale <- match.arg(keep_scale, choices = c("feature", "all"))
  }

  if (is.list(features)) {
    if (is.null(names(features))) {
      features <- unlist(features)
    } else {
      features <- stats::setNames(
        unlist(features),
        nm = rep(names(features), sapply(features, length))
      )
    }
  }
  if (!inherits(features, "character")) {
    log_message(
      "'features' is not a character vectors",
      message_type = "error"
    )
  }

  assay <- assay %||% SeuratObject::DefaultAssay(srt)
  if (is.null(split.by)) {
    split.by <- "All.groups"
    srt@meta.data[[split.by]] <- factor("")
  }
  for (i in c(split.by)) {
    if (!i %in% colnames(srt@meta.data)) {
      log_message(
        "{.val {i}} is not in {.cls Seurat}",
        message_type = "error"
      )
    }
    if (!is.factor(srt@meta.data[[i]])) {
      srt@meta.data[[i]] <- factor(
        srt@meta.data[[i]],
        levels = unique(srt@meta.data[[i]])
      )
    }
  }
  for (l in lineages) {
    if (!l %in% colnames(srt@meta.data)) {
      log_message(
        "Lineage {.val {l}} is not in {.cls Seurat}",
        message_type = "error"
      )
    }
  }
  if (!is.null(graph) && !graph %in% names(srt@graphs)) {
    log_message(
      "Graph {.val {graph}} is not exist in {.cls Seurat}",
      message_type = "error"
    )
  }
  if (!is.null(graph)) {
    graph <- srt@graphs[[graph]]
  }
  if (is.null(reduction)) {
    reduction <- DefaultReduction(srt)
  } else {
    reduction <- DefaultReduction(srt, pattern = reduction)
  }
  if (!reduction %in% names(srt@reductions)) {
    log_message(
      "{.val {reduction}} is not in {.cls Seurat}",
      message_type = "error"
    )
  }
  if (!is.null(cells.highlight) && isFALSE(cells.highlight)) {
    if (!any(cells.highlight %in% colnames(srt@assays[[1]]))) {
      log_message(
        "No cells in {.val {cells.highlight}} found in {.cls Seurat}",
        message_type = "error"
      )
    }
    if (!all(cells.highlight %in% colnames(srt@assays[[1]]))) {
      log_message(
        "Some cells in {.val {cells.highlight}} not found in {.cls Seurat}",
        message_type = "warning",
        verbose = verbose
      )
    }
    cells.highlight <- intersect(cells.highlight, colnames(srt@assays[[1]]))
  }

  feature_input <- features
  features <- unique(features)
  embeddings <- lapply(srt@reductions, function(x) colnames(x@cell.embeddings))
  embeddings <- stats::setNames(
    rep(names(embeddings), sapply(embeddings, length)),
    nm = unlist(embeddings)
  )
  features_drop <- features[
    !features %in%
      c(
        rownames(srt@assays[[assay]]),
        colnames(srt@meta.data),
        names(embeddings)
      )
  ]
  if (length(features_drop) > 0) {
    log_message(
      "{.val {features_drop}} are not in the features of {.cls Seurat}",
      message_type = "warning",
      verbose = verbose
    )
    features <- features[!features %in% features_drop]
  }

  features_gene <- features[features %in% rownames(srt@assays[[assay]])]
  features_meta <- features[features %in% colnames(srt@meta.data)]
  features_embedding <- features[features %in% names(embeddings)]
  features_common <- intersect(features_gene, features_meta)
  if (length(features_common) > 0) {
    log_message(
      "Features appear in both gene names and metadata names: {.val {features_common}}",
      message_type = "warning",
      verbose = verbose
    )
  }
  if (length(c(features_gene, features_meta, features_embedding)) == 0) {
    log_message(
      "There are no valid features present.",
      message_type = "error"
    )
  }

  assay_data <- NULL
  if (isTRUE(calculate_coexp) && length(features_gene) > 0) {
    assay_data <- GetAssayData5(
      srt,
      assay = assay,
      layer = layer,
      features = features_gene
    )
    if (length(features_meta) > 0) {
      log_message(
        "{.val {features_meta}} is not used when calculating co-expression",
        "is not used when calculating co-expression",
        message_type = "warning",
        verbose = verbose
      )
    }
    status <- CheckDataType(srt, layer = layer, assay = assay)
    log_message("Data type detected in {.val {layer}} layer: {.val {status}}", verbose = verbose)
    if (status %in% c("raw_counts", "raw_normalized_counts")) {
      srt@meta.data[["CoExp"]] <- feature_cor_geometric_mean(
        assay_data[features_gene, , drop = FALSE],
        log_normalized = FALSE
      )
    } else if (status == "log_normalized_counts") {
      srt@meta.data[["CoExp"]] <- feature_cor_geometric_mean(
        assay_data[features_gene, , drop = FALSE],
        log_normalized = TRUE
      )
    } else {
      log_message(
        "Can not determine the data type",
        message_type = "error"
      )
    }
    features <- c(features, "CoExp")
    features_meta <- c(features_meta, "CoExp")
  }

  if (length(features_gene) > 0) {
    assay_data <- assay_data %||% GetAssayData5(
      srt,
      assay = assay,
      layer = layer,
      features = features_gene
    )
    if (all(rownames(srt@assays[[assay]]) %in% features_gene)) {
      dat_gene <- Matrix::t(
        as_matrix(
          assay_data
        )
      )
    } else {
      dat_gene <- Matrix::t(
        as_matrix(
          assay_data[features_gene, , drop = FALSE]
        )
      )
    }
  } else {
    dat_gene <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  if (length(features_meta) > 0) {
    dat_meta <- as_matrix(srt@meta.data[, features_meta, drop = FALSE])
  } else {
    dat_meta <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  if (length(features_embedding) > 0) {
    dat_embedding <- as_matrix(
      SeuratObject::FetchData(
        srt,
        vars = features_embedding
      )
    )
  } else {
    dat_embedding <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  dat_exp <- as_matrix(do.call(
    cbind,
    list(dat_gene, dat_meta, dat_embedding)
  ))
  features <- unique(features[
    features %in% c(features_gene, features_meta, features_embedding)
  ])

  if (!is.numeric(dat_exp) && !inherits(dat_exp, "Matrix")) {
    log_message(
      "{.arg features} must be type of numeric variable",
      message_type = "error"
    )
  }
  dat_exp[, features][dat_exp[, features] <= bg_cutoff] <- NA

  if (length(features) > 50 && isFALSE(force)) {
    log_message(
      "More than 50 {.arg features} to be plotted",
      message_type = "warning",
      verbose = verbose
    )
    if (interactive()) {
      answer <- utils::askYesNo("Are you sure to continue?", default = FALSE)
      if (isFALSE(answer)) {
        return(invisible(NULL))
      }
    }
  }

  if (is.null(subtitle)) {
    if (!is.null(names(feature_input))) {
      subtitle <- stats::setNames(names(feature_input), nm = feature_input)
    }
  } else {
    if (length(subtitle) == 1) {
      subtitle <- stats::setNames(rep(subtitle, length(features)), nm = features)
    } else if (length(subtitle) == length(features)) {
      subtitle <- stats::setNames(subtitle, nm = features)
    } else {
      log_message(
        "Subtitle length must be 1 or length of features({.val {length(features)}})",
        message_type = "error"
      )
    }
  }

  reduction_key <- srt@reductions[[reduction]]@key
  dat_dim <- srt@reductions[[reduction]]@cell.embeddings
  colnames(dat_dim) <- paste0(reduction_key, seq_len(ncol(dat_dim)))
  rownames(dat_dim) <- rownames(dat_dim) %||% colnames(srt@assays[[1]])
  dat_sp <- srt@meta.data[, split.by, drop = FALSE]
  dat_use <- cbind(dat_dim, dat_sp[row.names(dat_dim), , drop = FALSE])
  if (!is.null(cells)) {
    dat_use <- dat_use[intersect(rownames(dat_use), cells), , drop = FALSE]
  }

  point_config <- dim_plot_point_config(
    n = nrow(dat_use),
    pt.size = pt.size,
    raster = raster,
    raster.dpi = raster.dpi
  )
  pt.size <- point_config$pt.size
  raster <- point_config$raster
  raster_pt_size <- point_config$raster_pt_size
  raster.dpi <- point_config$raster.dpi
  if (isTRUE(raster)) {
    check_r("scattermore", verbose = FALSE)
  }

  if (!is.null(lineages)) {
    lineages_layers <- LineagePlot(
      srt,
      lineages = lineages,
      reduction = reduction,
      dims = dims,
      trim = lineages_trim,
      span = lineages_span,
      palette = lineages_palette,
      palcolor = lineages_palcolor,
      lineages_arrow = lineages_arrow,
      linewidth = lineages_linewidth,
      line_bg = lineages_line_bg,
      line_bg_stroke = lineages_line_bg_stroke,
      whiskers = lineages_whiskers,
      whiskers_linewidth = lineages_whiskers_linewidth,
      whiskers_alpha = lineages_whiskers_alpha,
      aspect.ratio = aspect.ratio,
      xlab = xlab,
      ylab = ylab,
      legend.position = legend.position,
      legend.direction = legend.direction,
      theme_use = theme_use,
      theme_args = theme_args,
      return_layer = TRUE
    )
    lineages_layers <- lineages_layers[
      !names(lineages_layers) %in% c("lab_layer", "theme_layer")
    ]
  }

  plist <- list()
  xlab <- xlab %||% paste0(reduction_key, dims[1])
  ylab <- ylab %||% paste0(reduction_key, dims[2])
  if (identical(theme_use, "theme_blank")) {
    theme_args[["xlab"]] <- xlab
    theme_args[["ylab"]] <- ylab
  }

  if (isTRUE(compare_features) && length(features) > 1) {
    dat_all <- cbind(
      dat_use,
      dat_exp[row.names(dat_use), features, drop = FALSE]
    )
    dat_split <- split.data.frame(dat_all, dat_all[[split.by]])
    plist <- lapply(
      levels(dat_sp[[split.by]]), function(s) {
        dat <- dat_split[[ifelse(split.by == "All.groups", 1, s)]][, ,
          drop = FALSE
        ]
        for (f in features) {
          if (any(is.infinite(dat[, f]))) {
            dat[, f][which(dat[, f] == max(dat[, f], na.rm = TRUE))] <- max(
              dat[, f][is.finite(dat[, f])],
              na.rm = TRUE
            )
            dat[, f][which(dat[, f] == min(dat[, f], na.rm = TRUE))] <- min(
              dat[, f][is.finite(dat[, f])],
              na.rm = TRUE
            )
          }
        }
        dat[["x"]] <- dat[[paste0(reduction_key, dims[1])]]
        dat[["y"]] <- dat[[paste0(reduction_key, dims[2])]]
        dat[, "split.by"] <- s
        dat[, "features"] <- paste(features, collapse = "|")
        subtitle_use <- paste0(subtitle, collapse = "|") %||% s
        colors <- palette_colors(
          features,
          type = "discrete",
          palette = palette,
          palcolor = palcolor
        )
        colors_list <- list()
        value_list <- list()
        pal_list <- list()
        temp_geom <- list()
        legend_list <- list()
        for (i in seq_along(colors)) {
          colors_list[[i]] <- palette_colors(
            dat[, names(colors)[i]],
            type = "continuous",
            NA_color = NA,
            NA_keep = TRUE,
            matched = TRUE,
            palcolor = c(adjcolors(colors[i], 0.1), colors[i])
          )
          pal_list[[i]] <- palette_colors(
            dat[, names(colors)[i]],
            type = "continuous",
            NA_color = NA,
            NA_keep = FALSE,
            matched = FALSE,
            palcolor = c(adjcolors(colors[i], 0.1), colors[i])
          )
          value_list[[i]] <- seq(
            min(dat[, names(colors)[i]], na.rm = TRUE),
            max(dat[, names(colors)[i]], na.rm = TRUE),
            length.out = 100
          )
          temp_geom[[i]] <- list(
            geom_point(
              data = dat,
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[[names(colors)[i]]]
              ),
              shape = "circle"
            )
          )
          if (all(is.na(colors_list[[i]]))) {
            temp_geom[[i]] <- append(
              temp_geom[[i]],
              scale_colour_gradient(
                na.value = bg_color,
                guide = guide_colorbar(
                  frame.colour = "black",
                  ticks.colour = "black",
                  title.hjust = 0
                )
              )
            )
          } else if (length(colors_list[[i]]) == 1) {
            temp_geom[[i]] <- append(
              temp_geom[[i]],
              scale_colour_gradient(
                low = colors_list[[i]],
                na.value = bg_color,
                guide = guide_colorbar(
                  frame.colour = "black",
                  ticks.colour = "black",
                  title.hjust = 0
                )
              )
            )
          } else {
            legend_title_use <- if (is.null(legend.title)) NULL else legend.title
            temp_geom[[i]] <- append(
              temp_geom[[i]],
              scale_color_gradientn(
                name = legend_title_use,
                colours = pal_list[[i]],
                values = scales::rescale(value_list[[i]]),
                na.value = bg_color,
                guide = guide_colorbar(
                  frame.colour = "black",
                  ticks.colour = "black",
                  title.hjust = 0
                )
              )
            )
          }
          legend_list[[i]] <- get_legend(
            ggplot(dat, aes(x = .data[["x"]], y = .data[["y"]])) +
              temp_geom[[i]] +
              apply_plot_theme(theme_use, theme_args) +
              theme(
                aspect.ratio = aspect.ratio,
                legend.position = "bottom",
                legend.direction = legend.direction
              )
          )
        }
        for (j in seq_len(nrow(dat))) {
          dat[j, "color_blend"] <- blendcolors(
            sapply(colors_list, function(x) x[j]),
            mode = color_blend_mode
          )
        }
        dat["color_value"] <- Matrix::colSums(grDevices::col2rgb(dat[, "color_blend"]))
        dat[
          Matrix::rowSums(is.na(dat[, names(colors)])) == length(colors),
          "color_value"
        ] <- NA
        dat <- dat[
          order(dat[, "color_value"], decreasing = TRUE, na.last = FALSE), ,
          drop = FALSE
        ]
        dat[
          Matrix::rowSums(is.na(dat[, names(colors)])) == length(colors),
          "color_blend"
        ] <- bg_color
        cells.highlight_use <- cells.highlight
        if (isTRUE(cells.highlight_use)) {
          cells.highlight_use <- rownames(dat)[dat[["color_blend"]] != bg_color]
        }
        net <- dim_plot_graph_layers(
          graph = graph,
          dat = dat,
          edge_color = edge_color,
          edge_alpha = edge_alpha,
          edge_size = edge_size
        )
        density <- dim_plot_density_layers(
          add_density = add_density,
          density_filled = density_filled,
          density_color = density_color,
          density_filled_palette = density_filled_palette,
          density_filled_palcolor = density_filled_palcolor
        )

        p <- ggplot(dat) +
          net +
          density +
          labs(title = title, subtitle = subtitle_use, x = xlab, y = ylab) +
          scale_x_continuous(
            limits = c(
              min(dat_use[, paste0(reduction_key, dims[1])], na.rm = TRUE),
              max(dat_use[, paste0(reduction_key, dims[1])], na.rm = TRUE)
            )
          ) +
          scale_y_continuous(
            limits = c(
              min(dat_use[, paste0(reduction_key, dims[2])], na.rm = TRUE),
              max(dat_use[, paste0(reduction_key, dims[2])], na.rm = TRUE)
            )
          )
        if (split.by == "All.groups") {
          p <- p + facet_grid(. ~ features)
        } else {
          p <- p + facet_grid(split.by ~ features)
        }
        p <- p +
          apply_plot_theme(theme_use, theme_args) +
          theme(
            aspect.ratio = aspect.ratio,
            legend.position = "none",
            legend.direction = legend.direction
          )

        if (isTRUE(raster)) {
          p <- p +
            scattermore::geom_scattermore(
              data = dat[dat[, "color_blend"] == bg_color, , drop = FALSE],
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["color_blend"]]
              ),
              pointsize = raster_pt_size,
              alpha = pt.alpha,
              pixels = raster.dpi
            ) +
            scattermore::geom_scattermore(
              data = dat[dat[, "color_blend"] != bg_color, , drop = FALSE],
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["color_blend"]]
              ),
              pointsize = raster_pt_size,
              alpha = pt.alpha,
              pixels = raster.dpi
            ) +
            scale_color_identity() +
            ggnewscale::new_scale_color()
        } else {
          p <- p +
            geom_point(
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["color_blend"]]
              ),
              shape = "circle",
              size = pt.size,
              stroke = 0,
              alpha = pt.alpha
            ) +
            scale_color_identity() +
            ggnewscale::new_scale_color()
        }

        if (!is.null(cells.highlight_use)) {
          cell_df <- subset(p$data, rownames(p$data) %in% cells.highlight_use)
          if (nrow(cell_df) > 0) {
            if (isTRUE(raster)) {
              p <- p +
                scattermore::geom_scattermore(
                  data = cell_df,
                  aes(x = .data[["x"]], y = .data[["y"]]),
                  color = cols.highlight,
                  pointsize = floor(sizes.highlight) + stroke.highlight,
                  alpha = alpha.highlight,
                  pixels = raster.dpi
                ) +
                scattermore::geom_scattermore(
                  data = cell_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    color = .data[["color_blend"]]
                  ),
                  pointsize = floor(sizes.highlight),
                  alpha = alpha.highlight,
                  pixels = raster.dpi
                ) +
                scale_color_identity() +
                ggnewscale::new_scale_color()
            } else {
              p <- p +
                geom_point(
                  data = cell_df,
                  aes(x = .data[["x"]], y = .data[["y"]]),
                  shape = "circle",
                  color = cols.highlight,
                  size = sizes.highlight + stroke.highlight,
                  alpha = alpha.highlight
                ) +
                geom_point(
                  data = cell_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    color = .data[["color_blend"]]
                  ),
                  shape = "circle",
                  size = sizes.highlight,
                  alpha = alpha.highlight
                ) +
                scale_color_identity() +
                ggnewscale::new_scale_color()
            }
          }
        }

        legend2 <- NULL
        if (isTRUE(label)) {
          label_df <- reshape2::melt(p$data, measure.vars = features)
          label_df <- label_df %>%
            dplyr::group_by(variable) %>%
            dplyr::filter(
              value >= stats::quantile(value[is.finite(value)], 0.95, na.rm = TRUE) &
                value <= stats::quantile(value[is.finite(value)], 0.99, na.rm = TRUE)
            ) %>%
            dplyr::reframe(
              x = stats::median(.data[["x"]]),
              y = stats::median(.data[["y"]])
            ) %>%
            as.data.frame()
          colnames(label_df)[1] <- "label"
          label_df <- label_df[!is.na(label_df[, "label"]), , drop = FALSE]
          label_df[, "rank"] <- seq_len(nrow(label_df))
          if (isTRUE(label_insitu)) {
            if (isTRUE(label_repel)) {
              p <- p +
                geom_point(
                  data = label_df,
                  mapping = aes(x = .data[["x"]], y = .data[["y"]]),
                  shape = "circle",
                  color = label_point_color,
                  size = label_point_size
                ) +
                ggrepel::geom_text_repel(
                  data = label_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    label = .data[["label"]],
                    color = .data[["label"]]
                  ),
                  fontface = "bold",
                  min.segment.length = 0,
                  segment.color = label_segment_color,
                  point.size = label_point_size,
                  max.overlaps = 100,
                  force = label_repulsion,
                  color = label.fg,
                  bg.color = label.bg,
                  bg.r = label.bg.r,
                  size = label.size,
                  inherit.aes = FALSE,
                  show.legend = FALSE
                )
            } else {
              p <- p +
                ggrepel::geom_text_repel(
                  data = label_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    label = .data[["label"]],
                    color = .data[["label"]]
                  ),
                  fontface = "bold",
                  min.segment.length = 0,
                  segment.color = label_segment_color,
                  point.size = NA,
                  max.overlaps = 100,
                  force = 0,
                  color = label.fg,
                  bg.color = label.bg,
                  bg.r = label.bg.r,
                  size = label.size,
                  inherit.aes = FALSE,
                  show.legend = FALSE
                )
            }
            p <- p +
              scale_color_manual(
                name = "Label:",
                values = adjcolors(colors[label_df$label], 0.5),
                labels = label_df$label,
                na.value = bg_color
              )
          } else {
            if (isTRUE(label_repel)) {
              p <- p +
                geom_point(
                  data = label_df,
                  mapping = aes(x = .data[["x"]], y = .data[["y"]]),
                  shape = "circle",
                  color = "black",
                  size = pt.size + 1
                ) +
                ggrepel::geom_text_repel(
                  data = label_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    label = .data[["rank"]],
                    color = .data[["label"]]
                  ),
                  fontface = "bold",
                  min.segment.length = 0,
                  segment.color = label_segment_color,
                  point.size = pt.size + 1,
                  max.overlaps = 100,
                  force = label_repulsion,
                  bg.color = label.bg,
                  bg.r = label.bg.r,
                  size = label.size,
                  inherit.aes = FALSE,
                  key_glyph = "point"
                )
            } else {
              p <- p +
                ggrepel::geom_text_repel(
                  data = label_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    label = .data[["rank"]],
                    color = .data[["label"]]
                  ),
                  fontface = "bold",
                  min.segment.length = 0,
                  segment.colour = label_segment_color,
                  point.size = NA,
                  max.overlaps = 100,
                  force = 0,
                  bg.color = label.bg,
                  bg.r = label.bg.r,
                  size = label.size,
                  inherit.aes = FALSE,
                  key_glyph = "point"
                )
            }
            p <- p +
              scale_color_manual(
                name = "Label:",
                values = adjcolors(colors[label_df$label], 0.5),
                labels = paste(label_df$rank, label_df$label, sep = ": "),
                na.value = bg_color
              ) +
              guides(
                colour = guide_legend(
                  override.aes = list(shape = "circle", color = colors[label_df$label]),
                  order = 1
                )
              ) +
              theme(legend.position = "none")
            legend2 <- get_legend(
              p +
                apply_plot_theme(theme_use, theme_args) +
                theme(
                  aspect.ratio = aspect.ratio,
                  legend.position = "bottom",
                  legend.direction = legend.direction
                )
            )
          }
        }

        legend_nrow <- min(ceiling(sqrt(length(legend_list))), 3)
        total <- length(legend_list)
        leg_list <- list()
        n <- 1
        for (i in 1:total) {
          if (i == 1 || is.null(leg)) {
            leg <- legend_list[[i]]
          } else {
            leg <- cbind(leg, legend_list[[i]])
          }
          if (i %% legend_nrow == 0) {
            leg_list[[n]] <- leg
            leg <- NULL
            n <- n + 1
          }
          if (i %% legend_nrow != 0 && i == total) {
            ncol_insert <- dim(leg_list[[n - 1]])[2] - dim(leg)[2]
            for (col_insert in 1:ncol_insert) {
              check_r("gtable", verbose = FALSE)
              leg <- gtable::gtable_add_cols(
                leg,
                sum(leg_list[[n - 1]]$widths) / ncol_insert,
                -1
              )
            }
            leg_list[[n]] <- leg
          }
        }
        legend <- do.call(rbind, leg_list)
        if (!is.null(lineages)) {
          lineages_layers <- c(
            list(ggnewscale::new_scale_color()), lineages_layers
          )
          suppressMessages({
            legend_curve <- get_legend(
              ggplot() +
                lineages_layers +
                theme_scop()
            )
          })
          legend <- add_grob(legend, legend_curve, "top")
          p <- suppressMessages({
            p + lineages_layers + theme(legend.position = "none")
          })
        }

        gtable <- as_grob(p)
        gtable <- add_grob(gtable, legend, legend.position)
        if (!is.null(legend2)) {
          gtable <- add_grob(gtable, legend2, legend.position)
        }
        p <- patchwork::wrap_plots(gtable)
        return(p)
      }
    )
    names(plist) <- paste0(
      levels(dat_sp[[split.by]]),
      ":",
      paste0(features, collapse = "|")
    )
  } else {
    comb <- expand.grid(
      split = levels(dat_sp[[split.by]]),
      feature = features,
      stringsAsFactors = FALSE
    )
    rownames(comb) <- paste0(comb[["split"]], ":", comb[["feature"]])
    dat_all <- cbind(
      dat_use,
      dat_exp[row.names(dat_use), features, drop = FALSE]
    )
    dat_split <- split.data.frame(dat_all, dat_all[[split.by]])
    colors <- palette_colors(
      type = "continuous",
      palette = palette,
      palcolor = palcolor
    )
    plist <- lapply(
      stats::setNames(rownames(comb), rownames(comb)), function(i) {
        f <- comb[i, "feature"]
        s <- comb[i, "split"]
        dat <- dat_split[[ifelse(split.by == "All.groups", 1, s)]][,
          c(colnames(dat_use), f),
          drop = FALSE
        ]
        if (any(is.infinite(dat[, f]))) {
          dat[, f][dat[, f] == max(dat[, f], na.rm = TRUE)] <- max(
            dat[, f][is.finite(dat[, f])],
            na.rm = TRUE
          )
          dat[, f][dat[, f] == min(dat[, f], na.rm = TRUE)] <- min(
            dat[, f][is.finite(dat[, f])],
            na.rm = TRUE
          )
        }
        dat[["x"]] <- dat[[paste0(reduction_key, dims[1])]]
        dat[["y"]] <- dat[[paste0(reduction_key, dims[2])]]
        dat[["value"]] <- dat[[f]]
        dat <- dat[
          order(
            dat[, "value"],
            method = "radix",
            decreasing = FALSE,
            na.last = FALSE
          ), ,
          drop = FALSE
        ]
        dat[, "features"] <- f
        cells.highlight_use <- cells.highlight
        if (isTRUE(cells.highlight_use)) {
          cells.highlight_use <- rownames(dat)[!is.na(dat[["value"]])]
        }
        legend_list <- list()
        if (isTRUE(show_stat)) {
          subtitle_use <- subtitle[f] %||%
            paste0(
              s,
              " nPos:",
              sum(dat[["value"]] > 0, na.rm = TRUE),
              ", ",
              round(sum(dat[["value"]] > 0, na.rm = TRUE) / nrow(dat) * 100, 2),
              "%"
            )
        } else {
          subtitle_use <- subtitle[f]
        }
        if (all(is.na(dat[["value"]]))) {
          colors_value <- rep(0, 100)
        } else {
          if (is.null(keep_scale)) {
            colors_value <- seq(
              lower_cutoff %||%
                stats::quantile(
                  dat[is.finite(dat[, "value"]), "value"],
                  lower_quantile,
                  na.rm = TRUE
                ),
              upper_cutoff %||%
                stats::quantile(
                  dat[is.finite(dat[, "value"]), "value"],
                  upper_quantile,
                  na.rm = TRUE
                ) +
                0.001,
              length.out = 100
            )
          } else {
            if (keep_scale == "feature") {
              colors_value <- seq(
                lower_cutoff %||%
                  stats::quantile(
                    dat_exp[is.finite(dat_exp[, f]), f],
                    lower_quantile,
                    na.rm = TRUE
                  ),
                upper_cutoff %||%
                  stats::quantile(
                    dat_exp[is.finite(dat_exp[, f]), f],
                    upper_quantile,
                    na.rm = TRUE
                  ) +
                  0.001,
                length.out = 100
              )
            }
            if (keep_scale == "all") {
              all_values <- as_matrix(dat_exp[, features])
              colors_value <- seq(
                lower_cutoff %||%
                  stats::quantile(
                    all_values[is.finite(all_values)],
                    lower_quantile,
                    na.rm = TRUE
                  ),
                upper_cutoff %||%
                  stats::quantile(all_values, upper_quantile, na.rm = TRUE) +
                  0.001,
                length.out = 100
              )
            }
          }
        }
        dat[
          which(dat[, "value"] > max(colors_value, na.rm = TRUE)),
          "value"
        ] <- max(colors_value, na.rm = TRUE)
        dat[
          which(dat[, "value"] < min(colors_value, na.rm = TRUE)),
          "value"
        ] <- min(colors_value, na.rm = TRUE)
        net <- dim_plot_graph_layers(
          graph = graph,
          dat = dat,
          edge_color = edge_color,
          edge_alpha = edge_alpha,
          edge_size = edge_size
        )
        density <- dim_plot_density_layers(
          add_density = add_density,
          density_filled = density_filled,
          density_color = density_color,
          density_filled_palette = density_filled_palette,
          density_filled_palcolor = density_filled_palcolor
        )
        p <- ggplot(dat) +
          net +
          density +
          labs(title = title, subtitle = subtitle_use, x = xlab, y = ylab) +
          scale_x_continuous(
            limits = c(
              min(dat_use[, paste0(reduction_key, dims[1])], na.rm = TRUE),
              max(dat_use[, paste0(reduction_key, dims[1])], na.rm = TRUE)
            )
          ) +
          scale_y_continuous(
            limits = c(
              min(dat_use[, paste0(reduction_key, dims[2])], na.rm = TRUE),
              max(dat_use[, paste0(reduction_key, dims[2])], na.rm = TRUE)
            )
          ) +
          apply_plot_theme(theme_use, theme_args) +
          theme(
            aspect.ratio = aspect.ratio,
            legend.position = legend.position,
            legend.direction = legend.direction
          )
        if (isTRUE(raster)) {
          p <- p +
            scattermore::geom_scattermore(
              data = dat[is.na(dat[, "value"]), , drop = FALSE],
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["value"]]
              ),
              pointsize = raster_pt_size,
              alpha = pt.alpha,
              pixels = raster.dpi
            ) +
            scattermore::geom_scattermore(
              data = dat[!is.na(dat[, "value"]), , drop = FALSE],
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["value"]]
              ),
              pointsize = raster_pt_size,
              alpha = pt.alpha,
              pixels = raster.dpi
            )
        } else if (isTRUE(hex)) {
          check_r("hexbin", verbose = FALSE)
          dat_na <- dat[is.na(dat[["value"]]), , drop = FALSE]
          dat_hex <- dat[!is.na(dat[["value"]]), , drop = FALSE]
          if (nrow(dat_na) > 0) {
            p <- p +
              geom_hex(
                data = dat[is.na(dat[["value"]]), , drop = FALSE],
                mapping = aes(x = .data[["x"]], y = .data[["y"]]),
                fill = bg_color,
                color = hex.color,
                linewidth = hex.linewidth,
                bins = hex.bins,
                binwidth = hex.binwidth
              )
          }
          if (nrow(dat_hex) > 0) {
            p <- p +
              stat_summary_hex(
                data = dat_hex,
                mapping = aes(
                  x = .data[["x"]],
                  y = .data[["y"]],
                  z = .data[["value"]]
                ),
                color = hex.color,
                linewidth = hex.linewidth,
                bins = hex.bins,
                binwidth = hex.binwidth
              )
            legend_title_use <- if (is.null(legend.title)) "" else legend.title
            if (all(is.na(dat[["value"]]))) {
              p <- p +
                scale_fill_gradient(
                  name = legend_title_use,
                  na.value = bg_color
                )
            } else {
              p <- p +
                scale_fill_gradientn(
                  name = legend_title_use,
                  colours = colors,
                  values = scales::rescale(colors_value),
                  limits = range(colors_value),
                  na.value = bg_color
                )
            }
            p <- p + ggnewscale::new_scale_fill()
          }
        } else {
          p <- p +
            geom_point(
              mapping = aes(
                x = .data[["x"]],
                y = .data[["y"]],
                color = .data[["value"]]
              ),
              shape = "circle",
              size = pt.size,
              stroke = 0,
              alpha = pt.alpha
            )
        }
        if (!is.null(cells.highlight_use) && isFALSE(hex)) {
          cell_df <- subset(p$data, rownames(p$data) %in% cells.highlight_use)
          if (nrow(cell_df) > 0) {
            if (isTRUE(raster)) {
              p <- p +
                scattermore::geom_scattermore(
                  data = cell_df,
                  aes(x = .data[["x"]], y = .data[["y"]]),
                  color = cols.highlight,
                  pointsize = floor(sizes.highlight) + stroke.highlight,
                  alpha = alpha.highlight,
                  pixels = raster.dpi
                ) +
                scattermore::geom_scattermore(
                  data = cell_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    color = .data[["value"]]
                  ),
                  pointsize = floor(sizes.highlight),
                  alpha = alpha.highlight,
                  pixels = raster.dpi
                )
            } else {
              p <- p +
                geom_point(
                  data = cell_df,
                  aes(x = .data[["x"]], y = .data[["y"]]),
                  shape = "circle",
                  color = cols.highlight,
                  size = sizes.highlight + stroke.highlight,
                  alpha = alpha.highlight
                ) +
                geom_point(
                  data = cell_df,
                  aes(
                    x = .data[["x"]],
                    y = .data[["y"]],
                    color = .data[["value"]]
                  ),
                  shape = "circle",
                  size = sizes.highlight,
                  alpha = alpha.highlight
                )
            }
          }
        }
        heading_color <- if (is.null(names(title.color))) {
          title.color
        } else if (f %in% names(title.color)) {
          unname(title.color[f])
        } else {
          NULL
        }
        p <- p + theme(strip.text.x = element_text(
          face = title.face %||% if (f %in% features_gene) "italic" else "plain",
          colour = heading_color
        ))
        if (nrow(dat) > 0) {
          if (split.by == "All.groups") {
            p <- p + facet_grid(. ~ features)
          } else {
            p <- p + facet_grid(stats::formula(paste0(split.by, "~features")))
          }
        }
        legend_title_use <- if (is.null(legend.title)) "" else legend.title
        if (all(is.na(dat[["value"]]))) {
          p <- p +
            scale_colour_gradient(
              name = legend_title_use,
              na.value = bg_color,
              aesthetics = c("color")
            )
        } else {
          p <- p +
            scale_color_gradientn(
              name = legend_title_use,
              colours = colors,
              values = scales::rescale(colors_value),
              limits = range(colors_value),
              na.value = bg_color,
              aesthetics = c("color")
            )
        }
        p <- p +
          guides(
            color = guide_colorbar(
              frame.colour = "black",
              ticks.colour = "black",
              title.hjust = 0,
              order = 1
            )
          )
        p_base <- p

        if (!is.null(lineages)) {
          lineages_layers <- c(
            list(
              ggnewscale::new_scale_color()
            ),
            lineages_layers
          )
          legend_list[["lineages"]] <- get_legend(
            ggplot() +
              lineages_layers +
              theme_scop(
                legend.position = "bottom",
                legend.direction = legend.direction
              )
          )
          p <- suppressWarnings({
            p + lineages_layers + theme(legend.position = "none")
          })
          if (is.null(legend_list[["lineages"]])) {
            legend_list["lineages"] <- list(NULL)
          }
        }

        if (isTRUE(label)) {
          label_df <- p$data %>%
            dplyr::filter(
              value >= stats::quantile(
                value[is.finite(value)], 0.95,
                na.rm = TRUE
              ) &
                value <= stats::quantile(
                  value[is.finite(value)], 0.99,
                  na.rm = TRUE
                )
            ) %>%
            dplyr::reframe(
              x = stats::median(.data[["x"]]),
              y = stats::median(.data[["y"]])
            ) %>%
            as.data.frame()
          label_df[, "label"] <- f
          label_df[, "rank"] <- seq_len(nrow(label_df))
          if (isTRUE(label_repel)) {
            p <- p +
              annotate(
                geom = "point",
                x = label_df[["x"]],
                y = label_df[["y"]],
                color = "black",
                size = pt.size + 1
              ) +
              annotate(
                geom = GeomTextRepel,
                x = label_df[["x"]],
                y = label_df[["y"]],
                label = label_df[["label"]],
                fontface = "bold",
                min.segment.length = 0,
                segment.color = label_segment_color,
                point.size = pt.size + 1,
                max.overlaps = 100,
                force = label_repulsion,
                color = label.fg,
                bg.color = label.bg,
                bg.r = label.bg.r,
                size = label.size
              )
          } else {
            p <- p +
              annotate(
                geom = GeomTextRepel,
                x = label_df[["x"]],
                y = label_df[["y"]],
                label = label_df[["label"]],
                fontface = "bold",
                point.size = NA,
                max.overlaps = 100,
                force = 0,
                color = label.fg,
                bg.color = label.bg,
                bg.r = label.bg.r,
                size = label.size
              )
          }
        }

        if (length(legend_list) > 0) {
          legend_list <- legend_list[!sapply(legend_list, is.null)]
          legend_base <- get_legend(
            p_base +
              theme(legend.position = "bottom")
          )
          if (legend.direction == "vertical") {
            legend <- do.call(cbind, c(list(base = legend_base), legend_list))
          } else {
            legend <- do.call(rbind, c(list(base = legend_base), legend_list))
          }
          gtable <- as_grob(p + theme(legend.position = "none"))
          gtable <- add_grob(gtable, legend, legend.position)
          p <- patchwork::wrap_plots(gtable)
        }

        return(p)
      }
    )
  }

  combine_plot_list(
    plist,
    combine = combine, nrow = nrow, ncol = ncol, byrow = byrow
  )
}

#' @title Feature values on a 3D reduction
#'
#' @md
#' @inheritParams FeatureDimPlot
#' @inheritParams CellDimPlot3D
#'
#' @seealso [FeatureDimPlot], [CellDimPlot3D]
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' FeatureDimPlot3D(
#'   pancreas_sub,
#'   features = c("Ghrl", "Ins1", "Gcg", "Ins2"),
#'   reduction = "StandardpcaUMAP3D"
#' )
FeatureDimPlot3D <- function(
  object,
  features,
  reduction = NULL,
  dims = c(1, 2, 3),
  axis_labs = NULL,
  split.by = NULL,
  layer = "data",
  assay = NULL,
  calculate_coexp = FALSE,
  pt.size = 1.5,
  cells.highlight = NULL,
  cols.highlight = "black",
  shape.highlight = "circle-open",
  sizes.highlight = 2,
  width = NULL,
  height = NULL,
  save = NULL,
  force = FALSE,
  verbose = TRUE,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  cols.highlight <- col2hex(cols.highlight)

  if (is.list(features)) {
    features <- unlist(features)
  }
  if (!inherits(features, "character")) {
    log_message(
      "'features' is not a character vectors",
      message_type = "error"
    )
  }

  assay <- assay %||% SeuratObject::DefaultAssay(srt)
  if (is.null(split.by)) {
    split.by <- "All.cells"
    srt@meta.data[[split.by]] <- factor("All.cells")
  }
  for (i in split.by) {
    if (!i %in% colnames(srt@meta.data)) {
      log_message(
        paste0(i, " is not in the meta.data of srt object."),
        message_type = "error"
      )
    }
    if (!is.factor(srt@meta.data[[i]])) {
      srt@meta.data[[i]] <- factor(
        srt@meta.data[[i]],
        levels = unique(srt@meta.data[[i]])
      )
    }
  }
  if (is.null(reduction)) {
    reduction <- DefaultReduction(srt, min_dim = 3)
  } else {
    reduction <- DefaultReduction(srt, pattern = reduction, min_dim = 3)
  }
  if (!reduction %in% names(srt@reductions)) {
    log_message(
      paste0(reduction, " is not in the srt reduction names."),
      message_type = "error"
    )
  }
  if (ncol(srt@reductions[[reduction]]@cell.embeddings) < 3) {
    log_message(
      "Reduction must be in three dimensions or higher.",
      message_type = "error"
    )
  }
  if (!is.null(cells.highlight) && isFALSE(cells.highlight)) {
    if (!any(cells.highlight %in% colnames(srt@assays[[1]]))) {
      log_message(
        "No cells in 'cells.highlight' found in srt.",
        message_type = "error"
      )
    }
    if (!all(cells.highlight %in% colnames(srt@assays[[1]]))) {
      log_message(
        "Some cells in 'cells.highlight' not found in srt.",
        message_type = "warning",
        verbose = verbose
      )
    }
    cells.highlight <- intersect(cells.highlight, colnames(srt@assays[[1]]))
  }
  if (isTRUE(cells.highlight)) {
    cells.highlight <- colnames(srt@assays[[1]])
  }
  reduction_key <- srt@reductions[[reduction]]@key
  if (is.null(axis_labs) || length(axis_labs) != 3) {
    xlab <- paste0(reduction_key, dims[1])
    ylab <- paste0(reduction_key, dims[2])
    zlab <- paste0(reduction_key, dims[3])
  } else {
    xlab <- axis_labs[1]
    ylab <- axis_labs[2]
    zlab <- axis_labs[3]
  }
  if ((!is.null(save) && is.character(save) && nchar(save) > 0)) {
    check_r("htmlwidgets", verbose = FALSE)
    if (!grepl(".html$", save)) {
      log_message(
        "{.arg save} must be a string with .html as a suffix",
        message_type = "error"
      )
    }
  }

  features <- unique(features)
  embeddings <- lapply(srt@reductions, function(x) colnames(x@cell.embeddings))
  embeddings <- stats::setNames(
    rep(names(embeddings), sapply(embeddings, length)),
    nm = unlist(embeddings)
  )
  features_drop <- features[
    !features %in%
      c(
        rownames(srt@assays[[assay]]),
        colnames(srt@meta.data),
        names(embeddings)
      )
  ]
  if (length(features_drop) > 0) {
    log_message(
      paste0(features_drop, collapse = ","),
      " are not in the features of srt.",
      message_type = "warning",
      verbose = verbose
    )
    features <- features[!features %in% features_drop]
  }

  features_gene <- features[features %in% rownames(srt@assays[[assay]])]
  features_meta <- features[features %in% colnames(srt@meta.data)]
  features_embedding <- features[features %in% names(embeddings)]
  if (length(intersect(features_gene, features_meta)) > 0) {
    log_message(
      "Features appear in both gene names and metadata names: ",
      paste0(intersect(features_gene, features_meta), collapse = ","),
      message_type = "warning",
      verbose = verbose
    )
  }
  if (length(c(features_gene, features_meta, features_embedding)) == 0) {
    log_message(
      "There are no valid features present.",
      message_type = "error"
    )
  }

  assay_data <- NULL
  if (isTRUE(calculate_coexp) && length(features_gene) > 0) {
    assay_data <- GetAssayData5(
      srt,
      assay = assay,
      layer = layer,
      features = features_gene
    )
    if (length(features_meta) > 0) {
      log_message(
        paste(features_meta, collapse = ","),
        "is not used when calculating co-expression",
        message_type = "warning",
        verbose = verbose
      )
    }
    status <- CheckDataType(srt, layer = layer, assay = assay)
    log_message("Data type detected in ", layer, " layer: ", status, verbose = verbose)
    if (status %in% c("raw_counts", "raw_normalized_counts")) {
      srt@meta.data[["CoExp"]] <- feature_cor_geometric_mean(
        assay_data[features_gene, , drop = FALSE],
        log_normalized = FALSE
      )
    } else if (status == "log_normalized_counts") {
      srt@meta.data[["CoExp"]] <- feature_cor_geometric_mean(
        assay_data[features_gene, , drop = FALSE],
        log_normalized = TRUE
      )
    } else {
      log_message(
        "Can not determine the data type.",
        message_type = "error"
      )
    }
    features <- c(features, "CoExp")
    features_meta <- c(features_meta, "CoExp")
  }

  if (length(features_gene) > 0) {
    assay_data <- assay_data %||% GetAssayData5(
      srt,
      assay = assay,
      layer = layer,
      features = features_gene
    )
    if (all(rownames(srt@assays[[assay]]) %in% features_gene)) {
      dat_gene <- Matrix::t(
        as_matrix(
          assay_data
        )
      )
    } else {
      dat_gene <- Matrix::t(
        as_matrix(
          assay_data[features_gene, , drop = FALSE]
        )
      )
    }
  } else {
    dat_gene <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  if (length(features_meta) > 0) {
    dat_meta <- as_matrix(srt@meta.data[, features_meta, drop = FALSE])
  } else {
    dat_meta <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  if (length(features_embedding) > 0) {
    dat_embedding <- as_matrix(
      SeuratObject::FetchData(
        srt,
        vars = features_embedding
      )
    )
  } else {
    dat_embedding <- matrix(nrow = ncol(srt@assays[[1]]), ncol = 0)
  }
  dat_exp <- as_matrix(do.call(
    cbind,
    list(dat_gene, dat_meta, dat_embedding)
  ))
  features <- unique(features[
    features %in% c(features_gene, features_meta, features_embedding)
  ])

  if (!is.numeric(dat_exp) && !inherits(dat_exp, "Matrix")) {
    log_message(
      "{.arg dat_exp} must be type of numeric variable",
      message_type = "error"
    )
  }
  if (length(features) > 50 && isFALSE(force)) {
    log_message(
      "More than 50 features to be plotted",
      message_type = "warning",
      verbose = verbose
    )
    if (interactive()) {
      answer <- utils::askYesNo("Are you sure to continue?", default = FALSE)
      if (isFALSE(answer)) {
        return(invisible(NULL))
      }
    }
  }

  dat_sp <- srt@meta.data[, split.by, drop = FALSE]
  dat_dim <- srt@reductions[[reduction]]@cell.embeddings
  colnames(dat_dim) <- paste0(reduction_key, seq_len(ncol(dat_dim)))
  rownames(dat_dim) <- rownames(dat_dim) %||% colnames(srt@assays[[1]])
  dat_use <- cbind(
    dat_exp,
    dat_dim[rownames(dat_exp), , drop = FALSE],
    dat_sp[rownames(dat_exp), , drop = FALSE]
  )

  dat_use[[paste0(reduction_key, dims[1], "All_cells")]] <- dat_use[[paste0(
    reduction_key,
    dims[1]
  )]]
  dat_use[[paste0(reduction_key, dims[2], "All_cells")]] <- dat_use[[paste0(
    reduction_key,
    dims[2]
  )]]
  dat_use[[paste0(reduction_key, dims[3], "All_cells")]] <- dat_use[[paste0(
    reduction_key,
    dims[3]
  )]]
  for (i in levels(dat_use[[split.by]])) {
    dat_use[[paste0(reduction_key, dims[1], i)]] <- ifelse(
      dat_use[[split.by]] == i,
      dat_use[[paste0(reduction_key, dims[1])]],
      NA
    )
    dat_use[[paste0(reduction_key, dims[2], i)]] <- ifelse(
      dat_use[[split.by]] == i,
      dat_use[[paste0(reduction_key, dims[2])]],
      NA
    )
    dat_use[[paste0(reduction_key, dims[3], i)]] <- ifelse(
      dat_use[[split.by]] == i,
      dat_use[[paste0(reduction_key, dims[3])]],
      NA
    )
  }
  if (!is.null(cells.highlight)) {
    cells.highlight <- cells.highlight[cells.highlight %in% rownames(dat_use)]
    dat_use_highlight <- dat_use[cells.highlight, , drop = FALSE]
    for (i in levels(dat_use_highlight[[split.by]])) {
      dat_use_highlight[[paste0(reduction_key, dims[1], i)]] <- ifelse(
        dat_use_highlight[[split.by]] == i,
        dat_use_highlight[[paste0(reduction_key, dims[1])]],
        NA
      )
      dat_use_highlight[[paste0(reduction_key, dims[2], i)]] <- ifelse(
        dat_use_highlight[[split.by]] == i,
        dat_use_highlight[[paste0(reduction_key, dims[2])]],
        NA
      )
      dat_use_highlight[[paste0(reduction_key, dims[3], i)]] <- ifelse(
        dat_use_highlight[[split.by]] == i,
        dat_use_highlight[[paste0(reduction_key, dims[3])]],
        NA
      )
    }
  }

  p <- plotly::plot_ly(data = dat_use, width = width, height = height)
  p <- plotly::add_trace(
    p = p,
    data = dat_use,
    x = dat_use[[paste0(reduction_key, dims[1], "All_cells")]],
    y = dat_use[[paste0(reduction_key, dims[2], "All_cells")]],
    z = dat_use[[paste0(reduction_key, dims[3], "All_cells")]],
    text = paste0(
      "Cell:",
      rownames(dat_use),
      "\nExp:",
      round(dat_use[[features[1]]], 3)
    ),
    type = "scatter3d",
    mode = "markers",
    marker = list(
      color = dat_use[[features[1]]],
      colorbar = list(
        title = list(
          text = features[1],
          font = list(color = "black", size = 14)
        ),
        len = 0.5
      ),
      size = pt.size,
      showscale = TRUE
    ),
    name = "All_cells",
    showlegend = TRUE,
    visible = TRUE
  )

  if (!is.null(cells.highlight)) {
    p <- plotly::add_trace(
      p = p,
      x = dat_use_highlight[[paste0(reduction_key, dims[1], "All_cells")]],
      y = dat_use_highlight[[paste0(reduction_key, dims[2], "All_cells")]],
      z = dat_use_highlight[[paste0(reduction_key, dims[3], "All_cells")]],
      text = paste0(
        "Cell:",
        rownames(dat_use_highlight),
        "\nExp:",
        round(dat_use_highlight[[features[1]]], 3)
      ),
      type = "scatter3d",
      mode = "markers",
      marker = list(
        size = sizes.highlight,
        color = cols.highlight,
        symbol = shape.highlight
      ),
      name = "highlight",
      showlegend = TRUE,
      visible = TRUE
    )
  }

  split_option <- list()
  genes_option <- list()
  for (i in 0:nlevels(dat_use[[split.by]])) {
    sp <- ifelse(i == 0, "All.cells", levels(dat_use[[split.by]])[i])
    ncells <- ifelse(i == 0, nrow(dat_use), table(dat_use[[split.by]])[sp])
    if (i != 0 && sp == "All.cells") {
      next
    }
    x <- list(dat_use[[paste0(reduction_key, dims[1], sp)]])
    y <- list(dat_use[[paste0(reduction_key, dims[2], sp)]])
    z <- list(dat_use[[paste0(reduction_key, dims[3], sp)]])
    name <- sp
    if (!is.null(cells.highlight)) {
      x <- c(x, list(dat_use_highlight[[paste0(reduction_key, dims[1], sp)]]))
      y <- c(y, list(dat_use_highlight[[paste0(reduction_key, dims[2], sp)]]))
      z <- c(z, list(dat_use_highlight[[paste0(reduction_key, dims[3], sp)]]))
      name <- c(sp, "highlight")
    }
    split_option[[i + 1]] <- list(
      method = "update",
      args = list(
        list(
          x = x,
          y = y,
          z = z,
          name = name,
          visible = TRUE
        ),
        list(
          title = list(
            text = paste0(sp, " (nCells:", ncells, ")"),
            font = list(size = 16, color = "black"),
            y = 0.95
          )
        )
      ),
      label = sp
    )
  }
  for (j in seq_along(features)) {
    marker <- list(
      color = dat_use[[features[j]]],
      colorbar = list(
        title = list(
          text = features[j],
          font = list(color = "black", size = 14)
        ),
        len = 0.5
      ),
      size = pt.size,
      showscale = TRUE
    )

    if (!is.null(cells.highlight)) {
      marker <- list(
        marker,
        list(
          size = sizes.highlight,
          color = cols.highlight,
          symbol = shape.highlight
        )
      )
    }
    genes_option[[j]] <- list(
      method = "update",
      args = list(list(
        text = list(paste0(
          "Cell:",
          rownames(dat_use),
          "\nExp:",
          round(dat_use[[features[j]]], 3)
        )),
        marker = marker
      )),
      label = features[j]
    )
  }

  p <- plotly::layout(
    p = p,
    title = list(
      text = paste0("All_cells", " (nCells:", nrow(dat_use), ")"),
      font = list(size = 16, color = "black"),
      y = 0.95
    ),
    showlegend = TRUE,
    legend = list(
      itemsizing = "constant",
      y = -0.2,
      x = 0.5,
      xanchor = "center"
    ),
    scene = list(
      xaxis = list(
        title = xlab,
        range = c(
          min(dat_use[[paste0(reduction_key, dims[1])]], na.rm = TRUE),
          max(dat_use[[paste0(reduction_key, dims[1])]], na.rm = TRUE)
        )
      ),
      yaxis = list(
        title = ylab,
        range = c(
          min(dat_use[[paste0(reduction_key, dims[2])]], na.rm = TRUE),
          max(dat_use[[paste0(reduction_key, dims[2])]], na.rm = TRUE)
        )
      ),
      zaxis = list(
        title = zlab,
        range = c(
          min(dat_use[[paste0(reduction_key, dims[3])]], na.rm = TRUE),
          max(dat_use[[paste0(reduction_key, dims[3])]], na.rm = TRUE)
        )
      ),
      aspectratio = list(x = 1, y = 1, z = 1)
    ),
    updatemenus = list(
      list(
        y = 0.67,
        buttons = split_option
      ),
      list(
        y = 0.33,
        buttons = genes_option
      )
    ),
    autosize = FALSE
  )

  if ((!is.null(save) && is.character(save) && nchar(save) > 0)) {
    htmlwidgets::saveWidget(
      widget = plotly::as_widget(p),
      file = save
    )
    unlink(gsub("\\.html", "_files", save), recursive = TRUE)
  }

  return(p)
}
