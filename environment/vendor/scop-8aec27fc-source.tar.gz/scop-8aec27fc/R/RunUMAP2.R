#' @title Run UMAP
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams FeatureDimPlot
#' @inheritParams scop-params
#' @param object A `Seurat` object, matrix-like object, `Neighbor`, or `Graph`.
#' @param reduction Linear reduction used as input.
#' @param dims Dimensions to use. Supply only one of `dims`, `features`,
#' `neighbor`, or `graph`.
#' @param features Features used instead of a reduction.
#' @param neighbor,graph Existing `Neighbor` or `Graph` object name.
#' @param umap.method `"uwot"` or `"naive"`.
#' @param spread Spread of the embedding (the effective scale of embedded
#' points).
#' @param reduction.model Pre-trained UMAP `DimReduc` used to embed new data.
#' @param return.model Store the UMAP model.
#' @param n.neighbors,n.components,metric,n.epochs UMAP layout parameters.
#' String `metric` values include `"euclidean"`, `"manhattan"`, `"cosine"`,
#' `"pearson"`, and `"pearson2"`.
#' @param cores Number of CPU cores.
#' @param min.dist Minimum embedding distance (how tightly points pack).
#' @param set.op.mix.ratio Mix of fuzzy union (`1`) and intersection (`0`).
#' @param local.connectivity,negative.sample.rate Fuzzy simplicial set and
#' optimization sampling.
#' @param a,b UMAP curve parameters. `NULL` estimates them automatically.
#' @param learning.rate,repulsion.strength Layout optimization rates.
#' @param reduction.name,reduction.key Stored reduction name and embedding prefix.
#' @param seed.use Random seed.
#' @param ... Passed to the UMAP implementation.
#'
#' @rdname RunUMAP2
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' pancreas_sub <- RunUMAP2(pancreas_sub, dims = 1:30)
#' CellDimPlot(
#'   pancreas_sub,
#'   group.by = "CellType",
#'   reduction = "umap"
#' )
RunUMAP2 <- function(object, ...) {
  UseMethod(generic = "RunUMAP2", object = object)
}

#' @rdname RunUMAP2
#' @method RunUMAP2 Seurat
#' @export
RunUMAP2.Seurat <- function(
  object,
  reduction = "pca",
  dims = NULL,
  features = NULL,
  neighbor = NULL,
  graph = NULL,
  assay = NULL,
  layer = "data",
  umap.method = "uwot",
  reduction.model = NULL,
  return.model = FALSE,
  n.neighbors = 30L,
  n.components = 2L,
  metric = "cosine",
  n.epochs = 200L,
  cores = 1,
  min.dist = 0.3,
  set.op.mix.ratio = 1,
  local.connectivity = 1L,
  negative.sample.rate = 5L,
  a = NULL,
  b = NULL,
  learning.rate = 1,
  repulsion.strength = 1,
  reduction.name = "umap",
  reduction.key = "UMAP_",
  verbose = TRUE,
  seed.use = 11,
  spread = 1,
  ...
) {
  if (
    sum(c(
      is.null(dims),
      is.null(features),
      is.null(neighbor),
      is.null(graph)
    )) ==
      4
  ) {
    log_message(
      "Please specify only one of the following arguments: {.val dims, features, neighbor or graph}",
      message_type = "error"
    )
  }
  if (!is.null(features)) {
    assay <- assay %||% DefaultAssay(object = object)
    data.use <- as_matrix(
      Matrix::t(
        GetAssayData5(
          object = object,
          layer = layer,
          assay = assay
        )[features, , drop = FALSE]
      )
    )
    if (ncol(data.use) < n.components) {
      log_message(
        "Please provide as many or more {.arg features} than {.arg n.components}: ",
        "{.val {length(features)}} features provided, ",
        "{.val {n.components}} UMAP components requested",
        message_type = "error"
      )
    }
  } else if (!is.null(dims)) {
    reduc_nm <- names(x = object@reductions)
    if (!length(reduc_nm) || !reduction %in% reduc_nm) {
      reduction <- DefaultReduction(
        object,
        pattern = reduction
      )
    }
    dims <- intersect(dims, seq_len(ncol(Embeddings(object[[reduction]]))))
    if (length(dims) == 0L) {
      log_message(
        "No valid dimensions remain for {.arg reduction = '{reduction}'}",
        message_type = "error"
      )
    }
    data.use <- as_matrix(Embeddings(object[[reduction]])[, dims])
    assay <- DefaultAssay(object = object[[reduction]])
    if (length(dims) < n.components) {
      log_message(
        "Please provide as many or more {.arg dims} than {.arg n.components}: ",
        "{.val {length(dims)}} dims provided, ",
        "{.val {n.components}} UMAP components requested",
        message_type = "error"
      )
    }
  } else if (!is.null(neighbor)) {
    if (!inherits(x = object[[neighbor]], what = "Neighbor")) {
      log_message(
        "Please specify a Neighbor object name, ",
        "instead of the name of a {.cls {class(object[[neighbor]])}}",
        message_type = "error"
      )
    }
    data.use <- object[[neighbor]]
  } else if (!is.null(graph)) {
    if (!inherits(x = object[[graph]], what = "Graph")) {
      log_message(
        "Please specify a Graph object name, ",
        "instead of the name of a {.cls {class(object[[graph]])}}",
        message_type = "error"
      )
    }
    data.use <- object[[graph]]
  } else {
    log_message(
      "Please specify one of {.arg dims, features, neighbor, graph} to compute UMAP",
      message_type = "error"
    )
  }
  object[[reduction.name]] <- RunUMAP2(
    object = data.use,
    assay = assay,
    umap.method = umap.method,
    reduction.model = reduction.model,
    return.model = return.model,
    n.neighbors = n.neighbors,
    n.components = n.components,
    metric = metric,
    n.epochs = n.epochs,
    cores = cores,
    min.dist = min.dist,
    spread = spread,
    set.op.mix.ratio = set.op.mix.ratio,
    local.connectivity = local.connectivity,
    negative.sample.rate = negative.sample.rate,
    a = a,
    b = b,
    learning.rate = learning.rate,
    repulsion.strength = repulsion.strength,
    seed.use = seed.use,
    verbose = verbose,
    reduction.key = reduction.key
  )
  object <- Seurat::LogSeuratCommand(object = object)
  return(object)
}

#' @rdname RunUMAP2
#' @method RunUMAP2 default
#' @export
RunUMAP2.default <- function(
  object,
  assay = NULL,
  umap.method = "uwot",
  reduction.model = NULL,
  return.model = FALSE,
  n.neighbors = 30L,
  n.components = 2L,
  metric = "cosine",
  n.epochs = 200L,
  cores = 1,
  min.dist = 0.3,
  set.op.mix.ratio = 1,
  local.connectivity = 1L,
  negative.sample.rate = 5L,
  a = NULL,
  b = NULL,
  learning.rate = 1,
  repulsion.strength = 1,
  reduction.key = "UMAP_",
  verbose = TRUE,
  seed.use = 11L,
  spread = 1,
  ...
) {
  if (!is.null(seed.use)) {
    set.seed(seed = seed.use)
  }
  object_size <- NA_integer_
  if (
    inherits(x = object, what = "matrix") ||
      inherits(x = object, what = "Matrix") ||
      inherits(x = object, what = "dist")
  ) {
    object_size <- nrow(object)
  } else if (inherits(x = object, what = "list")) {
    object_size <- nrow(object[["idx"]])
  } else if (inherits(x = object, what = "Graph")) {
    object_size <- nrow(object)
  }
  if (is.finite(object_size) && !is.na(object_size) && n.neighbors >= object_size) {
    n.neighbors_use <- max(1L, object_size - 1L)
    log_message(
      "Adjust {.arg n.neighbors} from {.val {n.neighbors}} to {.val {n.neighbors_use}} for small-sample UMAP",
      verbose = verbose
    )
    n.neighbors <- n.neighbors_use
  }
  if (return.model) {
    log_message(
      "UMAP will return its model",
      verbose = verbose
    )
  }
  if (!is.null(reduction.model)) {
    log_message(
      "Running UMAP projection",
      verbose = verbose
    )
    if (
      is.null(reduction.model) ||
        !inherits(x = reduction.model, what = "DimReduc")
    ) {
      log_message(
        "If running projection UMAP, please pass a DimReduc object with the model stored to reduction.model",
        message_type = "error"
      )
    }
    model <- SeuratObject::Misc(object = reduction.model, slot = "model")
    if (length(model) == 0) {
      log_message(
        "The provided reduction.model does not have a model stored",
        message_type = "error"
      )
    }
    umap.method <- ifelse(
      "layout" %in% names(model),
      "naive-predict",
      "uwot-predict"
    )
  }
  n.epochs <- as.integer(n.epochs)
  n.neighbors <- as.integer(n.neighbors)
  n.components <- as.integer(n.components)
  local.connectivity <- as.integer(local.connectivity)
  negative.sample.rate <- as.integer(negative.sample.rate)

  if (inherits(x = object, what = "Neighbor")) {
    object <- list(
      idx = SeuratObject::Indices(object),
      dist = SeuratObject::Distances(object)
    )
  }

  if (umap.method == "naive") {
    umap.config <- umap::umap.defaults
    umap.config$n_neighbors <- n.neighbors
    umap.config$n_components <- n.components
    umap.config$metric <- metric
    umap.config$n_epochs <- ifelse(is.null(n.epochs), 200, n.epochs)
    umap.config$spread <- spread
    umap.config$min_dist <- min.dist
    umap.config$set_op_mix_ratio <- set.op.mix.ratio
    umap.config$local_connectivity <- local.connectivity
    umap.config$a <- ifelse(is.null(a), NA, a)
    umap.config$b <- ifelse(is.null(b), NA, b)
    umap.config$gamma <- repulsion.strength
    umap.config$alpha <- learning.rate
    umap.config$negative_sample_rate <- negative.sample.rate
    umap.config$random_state <- seed.use
    umap.config$transform_state <- seed.use
    umap.config$verbose <- verbose
    if (is.na(umap.config$a) || is.na(umap.config$b)) {
      umap.config[c("a", "b")] <- get_namespace_fun(
        "umap", "find.ab.params"
      )(
        umap.config$spread,
        umap.config$min_dist
      )
      umap.config$min_dist <- umap::umap.defaults$min_dist
    }

    if (inherits(x = object, what = "dist")) {
      knn <- get_namespace_fun(
        "umap", "knn.from.dist"
      )(d = object, k = n.neighbors)
      out <- umap::umap(
        d = matrix(nrow = nrow(object)),
        config = umap.config,
        knn = knn
      )
      embeddings <- out$layout
      rownames(x = embeddings) <- attr(object, "Labels")
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
    if (inherits(x = object, what = "list")) {
      knn <- umap::umap.knn(
        indexes = object[["idx"]],
        distances = object[["dist"]]
      )
      out <- umap::umap(
        d = matrix(nrow = nrow(object[["idx"]])),
        config = umap.config,
        knn = knn
      )
      embeddings <- out$layout
      rownames(x = embeddings) <- rownames(object[["idx"]])
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
    if (inherits(x = object, what = "Graph")) {
      if (!inherits(object, "dgCMatrix")) {
        object <- SeuratObject::as.sparse(object[1:nrow(object), ])
      }
      diag(object) <- 0
      if (ncol(object) > 10000) {
        obs_sample <- sample(1:ncol(object), size = 10000)
      } else {
        obs_sample <- 1:ncol(object)
      }
      if (!Matrix::isSymmetric(object[obs_sample, obs_sample])) {
        log_message(
          "Graph must be a symmetric matrix.",
          message_type = "error"
        )
      }

      coo <- matrix(ncol = 3, nrow = length(object@x))
      coo[, 1] <- rep(1:ncol(object), diff(object@p))
      coo[, 2] <- object@i + 1
      coo[, 3] <- object@x
      colnames(coo) <- c("from", "to", "value")
      coo <- coo[order(coo[, 1], coo[, 2]), ]
      graph <- list(
        coo = coo,
        names = rownames(object),
        n.elements = nrow(object)
      )
      class(graph) <- "coo"

      umap.config$init <- "spectral"
      initial <- get_namespace_fun(
        "umap", "make.initial.embedding"
      )(
        V = graph$n.elements,
        config = umap.config,
        g = graph
      )
      embeddings <- get_namespace_fun(
        "umap", "naive.simplicial.set.embedding"
      )(
        g = graph,
        embedding = initial,
        config = umap.config
      )
      embeddings <- get_namespace_fun(
        "umap", "center.embedding"
      )(embeddings)
      rownames(x = embeddings) <- rownames(x = object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        log_message(
          "{.arg return.model} does not support 'Graph' input",
          message_type = "warning"
        )
      }
      return(reduction)
    }
    if (
      inherits(x = object, what = "matrix") ||
        inherits(x = object, what = "Matrix")
    ) {
      out <- umap::umap(d = object, config = umap.config, method = "naive")
      embeddings <- out$layout
      rownames(x = embeddings) <- rownames(object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
  }

  if (umap.method == "uwot") {
    if (inherits(x = object, what = "dist")) {
      embeddings <- uwot::umap(
        X = object,
        n_neighbors = n.neighbors,
        n_threads = cores,
        n_components = n.components,
        metric = metric,
        n_epochs = n.epochs,
        learning_rate = learning.rate,
        min_dist = min.dist,
        spread = spread,
        set_op_mix_ratio = set.op.mix.ratio,
        local_connectivity = local.connectivity,
        repulsion_strength = repulsion.strength,
        negative_sample_rate = negative.sample.rate,
        a = a,
        b = b,
        ret_model = FALSE
      )
      rownames(x = embeddings) <- attr(object, "Labels")
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        log_message(
          "{.arg return.model} does not support 'dist' input",
          message_type = "warning"
        )
      }
      return(reduction)
    }
    if (inherits(x = object, what = "list")) {
      out <- uwot::umap(
        X = NULL,
        nn_method = object,
        n_threads = cores,
        n_components = n.components,
        metric = metric,
        n_epochs = n.epochs,
        learning_rate = learning.rate,
        min_dist = min.dist,
        spread = spread,
        set_op_mix_ratio = set.op.mix.ratio,
        local_connectivity = local.connectivity,
        repulsion_strength = repulsion.strength,
        negative_sample_rate = negative.sample.rate,
        a = a,
        b = b,
        ret_model = return.model
      )
      if (return.model) {
        embeddings <- out$embedding
      } else {
        embeddings <- out
      }
      rownames(x = embeddings) <- row.names(object[["idx"]])
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        out$nn_index <- NULL
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
    if (inherits(x = object, what = "Graph")) {
      if (!inherits(object, "dgCMatrix")) {
        object <- SeuratObject::as.sparse(object[1:nrow(object), ])
      }
      diag(object) <- 0
      if (ncol(object) > 10000) {
        obs_sample <- sample(1:ncol(object), size = 10000)
      } else {
        obs_sample <- 1:ncol(object)
      }
      if (!Matrix::isSymmetric(object[obs_sample, obs_sample])) {
        log_message(
          "Graph must be a symmetric matrix.",
          message_type = "error"
        )
      }
      graph_topk <- thisutils::run_sparse_topk_stored(
        x = object,
        k = n.neighbors,
        by = "col",
        decreasing = TRUE
      )
      idx <- graph_topk[["idx"]]
      connectivity <- graph_topk[["value"]]
      missing_topk <- is.na(idx) | is.na(connectivity)
      idx[missing_topk] <- sample(
        1:nrow(object),
        size = sum(missing_topk),
        replace = TRUE
      )
      connectivity[missing_topk] <- 0
      nn <- list(
        idx = idx,
        dist = max(connectivity) -
          connectivity +
          min(diff(range(connectivity)), 1) / 1e50
      )
      out <- uwot::umap(
        X = NULL,
        nn_method = nn,
        n_threads = cores,
        n_components = n.components,
        metric = metric,
        n_epochs = n.epochs,
        learning_rate = learning.rate,
        min_dist = min.dist,
        spread = spread,
        set_op_mix_ratio = set.op.mix.ratio,
        local_connectivity = local.connectivity,
        repulsion_strength = repulsion.strength,
        negative_sample_rate = negative.sample.rate,
        a = a,
        b = b,
        ret_model = return.model
      )
      if (return.model) {
        embeddings <- out$embedding
      } else {
        embeddings <- out
      }

      rownames(x = embeddings) <- row.names(object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        out$nn_index <- NULL
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
    if (
      inherits(x = object, what = "matrix") ||
        inherits(x = object, what = "Matrix")
    ) {
      out <- uwot::umap(
        X = object,
        n_neighbors = n.neighbors,
        n_threads = cores,
        n_components = n.components,
        metric = metric,
        n_epochs = n.epochs,
        learning_rate = learning.rate,
        min_dist = min.dist,
        spread = spread,
        set_op_mix_ratio = set.op.mix.ratio,
        local_connectivity = local.connectivity,
        repulsion_strength = repulsion.strength,
        negative_sample_rate = negative.sample.rate,
        a = a,
        b = b,
        ret_model = return.model
      )
      if (return.model) {
        embeddings <- out$embedding
      } else {
        embeddings <- out
      }
      rownames(x = embeddings) <- row.names(object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      if (return.model) {
        out$nn_index <- NULL
        SeuratObject::Misc(reduction, slot = "model") <- out
      }
      return(reduction)
    }
  }

  if (umap.method == "naive-predict") {
    if (
      inherits(x = object, what = "matrix") ||
        inherits(x = object, what = "Matrix")
    ) {
      class(model) <- "umap"
      if (any(!colnames(model$data) %in% colnames(object))) {
        log_message(
          "query data must contain the same features with the model:\n",
          paste(utils::head(colnames(model$data), 10), collapse = ","),
          " ......",
          message_type = "error"
        )
      }
      embeddings <- stats::predict(model, object[, colnames(model$data)])
      rownames(x = embeddings) <- row.names(object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      return(reduction)
    } else {
      log_message(
        "naive umap model only support 'matrix' input.",
        message_type = "error"
      )
    }
  }

  if (umap.method == "uwot-predict") {
    if (inherits(x = object, what = "list")) {
      if (ncol(object[["idx"]]) != model$n_neighbors) {
        log_message(
          "Number of neighbors between query and reference is not equal to the number of neighbros within reference",
          message_type = "warning"
        )
        model$n_neighbors <- ncol(object[["idx"]])
      }
      if (
        is.null(model$num_precomputed_nns) || model$num_precomputed_nns == 0
      ) {
        model$num_precomputed_nns <- 1
      }
      embeddings <- uwot::umap_transform(
        X = NULL,
        nn_method = object,
        model = model,
        n_epochs = n.epochs,
        n_threads = cores,
        verbose = FALSE
      )
      rownames(x = embeddings) <- row.names(object[["idx"]])
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      return(reduction)
    }
    if (inherits(x = object, what = "Graph")) {
      graph_topk <- thisutils::run_sparse_topk_stored(
        x = object,
        k = n.neighbors,
        by = "col",
        decreasing = TRUE
      )
      match_k <- graph_topk[["idx"]]
      match_k_connectivity <- graph_topk[["value"]]
      missing_topk <- is.na(match_k) | is.na(match_k_connectivity)
      match_k[missing_topk] <- sample(
        1:nrow(object),
        size = sum(missing_topk),
        replace = TRUE
      )
      match_k_connectivity[missing_topk] <- 0
      object <- list(
        idx = match_k,
        dist = max(match_k_connectivity) - match_k_connectivity
      )
      if (
        is.null(model$num_precomputed_nns) || model$num_precomputed_nns == 0
      ) {
        model$num_precomputed_nns <- 1
      }
      embeddings <- uwot::umap_transform(
        X = NULL,
        nn_method = object,
        model = model,
        n_epochs = n.epochs,
        n_threads = cores,
        verbose = FALSE
      )
      rownames(x = embeddings) <- row.names(object[["idx"]])
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      return(reduction)
    }
    if (
      inherits(x = object, what = "matrix") ||
        inherits(x = object, what = "Matrix")
    ) {
      embeddings <- uwot::umap_transform(
        X = object,
        model = model,
        n_epochs = n.epochs,
        n_threads = cores,
        verbose = FALSE
      )
      rownames(x = embeddings) <- row.names(object)
      colnames(x = embeddings) <- paste0(reduction.key, 1:n.components)
      reduction <- SeuratObject::CreateDimReducObject(
        embeddings = embeddings,
        key = reduction.key,
        assay = assay,
        global = TRUE
      )
      return(reduction)
    }
  }
}
