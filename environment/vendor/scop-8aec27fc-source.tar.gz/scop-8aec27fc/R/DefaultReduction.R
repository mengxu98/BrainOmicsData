#' @title Find the default reduction name in a Seurat object
#'
#' @inheritParams RunStandardWorkflow
#' @param pattern Character string containing a regular expression to search for.
#' @param min_dim Minimum dimension threshold.
#' @param max_distance Maximum distance allowed for a match.
#'
#' @return Default reduction name.
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' names(pancreas_sub@reductions)
#'
#' DefaultReduction(pancreas_sub)
#'
#' DefaultReduction(pancreas_sub, pattern = "pca")
#'
#' DefaultReduction(pancreas_sub, pattern = "umap")
DefaultReduction <- function(
  object,
  pattern = NULL,
  min_dim = 2,
  max_distance = 0.1,
  verbose = TRUE,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  if (length(srt@reductions) == 0) {
    log_message(
      "Unable to find any reductions",
      message_type = "error"
    )
  }
  pattern_default <- c(
    "WNNUMAP",
    "WNN",
    "MultiomeUMAP",
    "Multiome",
    "ATACUMAP",
    "ATAC",
    "SpatialUMAP",
    "Spatial",
    "umap",
    "tsne",
    "dm",
    "phate",
    "pacmap",
    "trimap",
    "largevis",
    "fr",
    "pca",
    "svd",
    "ica",
    "nmf",
    "mds",
    "glmpca"
  )
  pattern_dim <- c("2D", "3D")
  reduc_all <- names(srt@reductions)
  reduc_all <- reduc_all[unlist(lapply(reduc_all, function(x) {
    dim(srt@reductions[[x]]@cell.embeddings)[2] >= min_dim
  }))]
  if (length(reduc_all) == 0) {
    log_message(
      "No dimensional reduction found in {.cls Seurat}",
      message_type = "error"
    )
  }
  if (length(reduc_all) == 1) {
    return(reduc_all)
  }

  pattern_original <- pattern
  if (is.null(pattern)) {
    if (("Default_reduction" %in% names(srt@misc))) {
      pattern <- srt@misc[["Default_reduction"]]
    } else {
      pattern <- pattern_default
    }
  }

  pattern <- c(pattern, paste0(pattern, min_dim, "D"))
  if (any(pattern %in% reduc_all)) {
    return(pattern[pattern %in% reduc_all][1])
  }
  index <- c(unlist(sapply(pattern, function(pat) {
    grep(pattern = pat, x = reduc_all, ignore.case = TRUE)
  })))
  if (length(index) > 0) {
    default_reduc <- reduc_all[index]
  } else {
    index <- c(
      unlist(
        sapply(
          pattern, function(pat) {
            agrep(
              pattern = pat,
              x = reduc_all,
              max.distance = max_distance,
              ignore.case = TRUE
            )
          }
        )
      )
    )
    if (length(index) > 0) {
      default_reduc <- reduc_all[index]
    } else {
      default_reduc <- reduc_all
    }
  }
  if (length(default_reduc) > 1) {
    pattern_match <- if (!is.null(pattern_original) && length(pattern_original) == 1) {
      pattern_default[tolower(pattern_default) == tolower(pattern_original)]
    } else {
      character()
    }
    if (!is.null(pattern_original) && length(pattern_original) == 1 &&
      length(pattern_match) > 0L) {
      other_reductions <- setdiff(pattern_default, pattern_match[[1]])
      default_reduc_clean <- default_reduc[!sapply(default_reduc, function(x) {
        any(sapply(other_reductions, function(pr) {
          grepl(pattern = pr, x = x, ignore.case = TRUE)
        }))
      })]
      if (length(default_reduc_clean) > 0) {
        default_reduc <- default_reduc_clean
      }
    }

    if (length(default_reduc) > 1) {
      default_reduc <- default_reduc[unlist(sapply(
        c(pattern_default, pattern_dim),
        function(pat) {
          grep(pattern = pat, x = default_reduc, ignore.case = TRUE)
        }
      ))]
      default_reduc <- default_reduc[which.min(sapply(
        default_reduc,
        function(x) dim(srt@reductions[[x]])[2]
      ))]
    }
  }
  return(default_reduc)
}
