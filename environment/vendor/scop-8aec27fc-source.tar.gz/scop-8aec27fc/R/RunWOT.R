#' @title Run WOT analysis
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams RunCellRank
#' @param time_field Column name in `adata.obs` or `srt@meta.data` that contains the time information.
#' @param growth_iters A number of growth iterations to perform during the OT Model computation.
#' @param tmap_out Path to store the computed transport maps.
#' @param time_from The starting time point for trajectory and fate analysis.
#' @param time_to The ending time point for trajectory and fate analysis.
#' If not provided, only trajectory and fate analysis for the specified `time_from` will be performed.
#' @param get_coupling Whether to compute and store the coupling matrix between the specified `time_from` and `time_to`.
#' @param recalculate Whether to recalculate the transport maps even if they already exist at the specified `tmap_out` location.
#'
#' @export
#'
#' @references
#' Schiebinger G, Shu J, Tabaka M, et al. (2019). Optimal-Transport Analysis of
#' Single-Cell Gene Expression Identifies Developmental Trajectories in
#' Reprogramming. Cell, 176(4), 928-943. doi:10.1016/j.cell.2019.01.006
#'
#' [GitHub](https://github.com/broadinstitute/wot)
#'
#' @examples
#' \dontrun{
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#' pancreas_sub <- RunSlingshot(
#'   pancreas_sub,
#'   group.by = "SubCellType",
#'   reduction = "UMAP"
#' )
#'
#' print(range(pancreas_sub$Lineage1, na.rm = TRUE))
#'
#' pancreas_sub <- RunWOT(
#'   pancreas_sub,
#'   group.by = "SubCellType",
#'   time_field = "Lineage1",
#'   time_from = min(pancreas_sub$Lineage1, na.rm = TRUE),
#'   time_to = max(pancreas_sub$Lineage1, na.rm = TRUE),
#'   get_coupling = TRUE,
#'   tmap_out = "tmaps/lineage_tmap"
#' )
#'
#' pancreas_sub$Custom_Time <- sample(
#'   1:10,
#'   ncol(pancreas_sub),
#'   replace = TRUE
#' )
#' pancreas_sub <- RunWOT(
#'   pancreas_sub,
#'   group.by = "CellType",
#'   time_field = "Custom_Time",
#'   time_from = 1,
#'   time_to = 10,
#'   tmap_out = "tmaps/custom_tmap"
#' )
#' }
RunWOT <- function(
  object = NULL,
  assay_x = "RNA",
  layer_x = "counts",
  assay_y = c("spliced", "unspliced"),
  layer_y = "counts",
  adata = NULL,
  group.by = NULL,
  time_field = "Time",
  growth_iters = 3L,
  tmap_out = "tmaps/tmap_out",
  time_from = NULL,
  time_to = NULL,
  get_coupling = FALSE,
  recalculate = FALSE,
  palette = "Chinese",
  palcolor = NULL,
  show_plot = FALSE,
  save_plot = FALSE,
  plot_format = c("pdf", "png", "svg"),
  plot_dpi = 300,
  plot_prefix = "wot",
  dirpath = "./",
  return_seurat = !is.null(srt),
  verbose = TRUE,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  PrepareEnv(modules = "wot")
  check_python("wot")
  if (all(is.null(srt), is.null(adata))) {
    log_message(
      "One of {.arg srt} or {.arg adata} must be provided",
      message_type = "error"
    )
  }
  if (is.null(group.by)) {
    log_message(
      "{.arg group.by} must be provided",
      message_type = "error"
    )
  }
  if (is.null(time_field)) {
    log_message(
      "{.arg time_field} must be provided",
      message_type = "error"
    )
  }
  if (is.null(time_from)) {
    log_message(
      "{.arg time_from} must be provided",
      message_type = "error"
    )
  }
  if (isTRUE(get_coupling) && is.null(time_to)) {
    log_message(
      "The {.arg get_coupling} paramter is only valid when {.arg time_to} is specified",
      message_type = "warning"
    )
  }

  args <- mget(names(formals()))
  args <- lapply(
    args, function(x) {
      if (is.numeric(x)) {
        y <- ifelse(
          grepl("\\.", as.character(x)), as.double(x), as.integer(x)
        )
      } else {
        y <- x
      }
      return(y)
    }
  )
  call.envir <- parent.frame(1)
  args <- lapply(
    args, function(arg) {
      if (is.symbol(arg)) {
        eval(arg, envir = call.envir)
      } else if (is.call(arg)) {
        eval(arg, envir = call.envir)
      } else {
        arg
      }
    }
  )

  args[["save"]] <- save_plot
  args[["dpi"]] <- plot_dpi
  args[["fileprefix"]] <- plot_prefix

  params <- c(
    "srt",
    "object",
    "assay_x",
    "layer_x",
    "assay_y",
    "layer_y",
    "return_seurat",
    "palette",
    "palcolor",
    "save_plot",
    "plot_dpi",
    "plot_prefix",
    "plot_format"
  )
  args <- args[!names(args) %in% params]

  if (!is.null(srt)) {
    args[["adata"]] <- srt_to_adata(
      object = srt,
      assay_x = assay_x,
      layer_x = layer_x,
      assay_y = assay_y,
      layer_y = layer_y
    )
  }
  if ("group.by" %in% names(args)) {
    args[["group_by"]] <- args[["group.by"]]
    args[["group.by"]] <- NULL
  }
  groups <- py_to_r2(args[["adata"]]$obs)[[group.by]]
  args[["palette"]] <- palette_colors(
    levels(groups) %||% unique(groups),
    palette = palette,
    palcolor = palcolor
  )

  functions <- scop_python_import("functions", convert = TRUE)
  adata <- do.call(functions$WOT, args)

  if (isTRUE(return_seurat)) {
    srt_out <- adata_to_srt(adata)
    if (is.null(srt)) {
      return(srt_out)
    } else {
      srt_out1 <- srt_append(srt_raw = srt, srt_append = srt_out)
      srt_out2 <- srt_append(
        srt_raw = srt_out1,
        srt_append = srt_out,
        pattern = "(trajectory_)|(fates_)|(transition_)|(coupling_)",
        overwrite = TRUE,
        verbose = FALSE
      )
      return(srt_out2)
    }
  } else {
    return(adata)
  }
}
