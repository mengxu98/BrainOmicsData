#' @title Heatmap plot for dynamic features along lineages
#'
#' @md
#' @inheritParams GroupHeatmap
#' @inheritParams RunDynamicFeatures
#' @inheritParams scop-params
#' @inheritParams thisutils::parallelize_fun
#' @param features Features to plot.
#' By default, this parameter is set to NULL, and the dynamic features will be determined by the parameters
#' `min_expcells`, `r.sq`, `dev.expl`, `padjust` and `num_intersections`.
#' @param use_fitted Whether to use fitted values.
#' @param min_expcells The minimum number of expected cells.
#' @param r.sq The R-squared threshold.
#' @param dev.expl The deviance explained threshold.
#' @param padjust The p-value adjustment threshold.
#' @param num_intersections This parameter is a numeric vector used to determine the number of intersections among lineages.
#' It helps in selecting which dynamic features will be used.
#' By default, when this parameter is set to `NULL`,
#' all dynamic features that pass the specified threshold will be used for each lineage.
#' @param cell_density The cell density within each cell bin.
#' By default, this parameter is set to `1`, which means that all cells will be included within each cell bin.
#' @param cell_bins The number of cell bins.
#' @param order_by The order of the heatmap.
#' @param cluster_features_by Which lineage to use when clustering features.
#' By default, this parameter is set to `NULL`, which means that all lineages will be used.
#' @param pseudotime_label The pseudotime label.
#' @param pseudotime_label_color The pseudotime label color.
#' @param pseudotime_label_linetype The pseudotime label line type.
#' @param pseudotime_label_linewidth The pseudotime label line width.
#' @param pseudotime_palette The color palette to use for pseudotime.
#' @param pseudotime_palcolor The colors to use for the pseudotime in the heatmap.
#' @param separate_annotation Names of the annotations to be displayed in separate annotation blocks.
#' Each name should match a column name in the metadata of the `Seurat` object.
#' @param separate_annotation_palette The color palette to use for separate annotations.
#' @param separate_annotation_palcolor The colors to use for each level of the separate annotations.
#' @param separate_annotation_params Other parameters to [ComplexHeatmap::HeatmapAnnotation] when creating a separate annotation blocks.
#' @param reverse_ht Whether to reverse the heatmap.
#'
#' @seealso
#' [RunDynamicFeatures], [RunDynamicEnrichment]
#'
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' pancreas_sub <- RunStandardWorkflow(pancreas_sub)
#'
#' pancreas_sub <- RunSlingshot(
#'   pancreas_sub,
#'   group.by = "SubCellType",
#'   reduction = "UMAP"
#' )
#' pancreas_sub <- RunDynamicFeatures(
#'   pancreas_sub,
#'   lineages = c("Lineage1", "Lineage2"), ,
#'   fit_method = "pretsa",
#'   n_candidates = 200
#' )
#'
#' ht1 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = "Lineage1",
#'   n_split = 5,
#'   split_method = "kmeans-peaktime",
#'   cell_annotation = "SubCellType",
#'   width = 2,
#'   height = 3
#' )
#' ht1$plot
#'
#' thisplot::panel_fix(ht1$plot, raster = TRUE, dpi = 50)
#'
#' ht2 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = "Lineage1",
#'   features = c(
#'     "Sox9",
#'     "Neurod2",
#'     "Isl1",
#'     "Rbp4",
#'     "Pyy",
#'     "S_score",
#'     "G2M_score"
#'   ),
#'   cell_annotation = "SubCellType"
#' )
#' ht2$plot
#'
#' ht3 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = c("Lineage1", "Lineage2"),
#'   n_split = 5,
#'   nlabel = 10,
#'   split_method = "kmeans",
#'   cluster_rows = TRUE,
#'   cell_annotation = "SubCellType",
#'   width = 1,
#'   height = 2
#' )
#' ht3$plot
#'
#' ht4 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = c("Lineage1", "Lineage2"),
#'   reverse_ht = "Lineage1",
#'   cell_annotation = "SubCellType",
#'   n_split = 3,
#'   nlabel = 10,
#'   split_method = "mfuzz",
#'   species = "Mus_musculus",
#'   db = "GO_BP",
#'   anno_terms = TRUE,
#'   width = 1,
#'   height = 2
#' )
#'
#' ht5 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = "Lineage1",
#'   cell_annotation = "SubCellType",
#'   n_split = 2,
#'   split_method = "mfuzz",
#'   species = "Mus_musculus",
#'   db = "GO_BP",
#'   cores = 2,
#'   nlabel = 10,
#'   anno_terms = TRUE,
#'   anno_keys = TRUE,
#'   anno_features = TRUE,
#'   width = 1,
#'   height = 2,
#'   terms_width = grid::unit(1, "in"),
#'   terms_fontsize = 6,
#'   keys_width = grid::unit(0.5, "in"),
#'   keys_fontsize = c(3, 6),
#'   features_width = grid::unit(0.5, "in"),
#'   features_fontsize = c(3, 6)
#' )
#'
#' pancreas_sub <- AnnotateFeatures(
#'   pancreas_sub,
#'   species = "Mus_musculus",
#'   db = c("CSPA", "TF")
#' )
#' ht6 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = c("Lineage1", "Lineage2"),
#'   reverse_ht = "Lineage1",
#'   use_fitted = TRUE,
#'   n_split = 3,
#'   nlabel = 10,
#'   split_method = "mfuzz",
#'   heatmap_palette = "viridis",
#'   cell_annotation = c(
#'     "SubCellType", "Phase", "G2M_score"
#'   ),
#'   cell_annotation_palette = c(
#'     "Chinese", "simspec", "Purples"
#'   ),
#'   separate_annotation = list(
#'     "SubCellType", c("Arxes1", "Ncoa2")
#'   ),
#'   separate_annotation_palette = c(
#'     "Chinese", "Set1"
#'   ),
#'   separate_annotation_params = list(
#'     height = grid::unit(10, "mm")
#'   ),
#'   feature_annotation = c("TF", "CSPA"),
#'   feature_annotation_palcolor = list(
#'     c("gold", "steelblue"),
#'     c("forestgreen")
#'   ),
#'   pseudotime_label = 25,
#'   pseudotime_label_color = "red",
#'   width = 1,
#'   height = 2
#' )
#'
#' ht7 <- DynamicHeatmap(
#'   pancreas_sub,
#'   exp_legend_title = "Z-score",
#'   lineages = c("Lineage1", "Lineage2"),
#'   reverse_ht = "Lineage1",
#'   use_fitted = TRUE,
#'   n_split = 3,
#'   nlabel = 10,
#'   split_method = "mfuzz",
#'   heatmap_palette = "viridis",
#'   cell_annotation = c(
#'     "SubCellType", "Phase", "G2M_score"
#'   ),
#'   cell_annotation_palette = c(
#'     "Chinese", "simspec", "Purples"
#'   ),
#'   separate_annotation = list(
#'     "SubCellType", c("Arxes1", "Ncoa2")
#'   ),
#'   separate_annotation_palette = c("Chinese", "Set1"),
#'   separate_annotation_params = list(width = grid::unit(10, "mm")),
#'   feature_annotation = c("TF", "CSPA"),
#'   feature_annotation_palcolor = list(
#'     c("gold", "steelblue"),
#'     c("forestgreen")
#'   ),
#'   pseudotime_label = 25,
#'   pseudotime_label_color = "red",
#'   flip = TRUE,
#'   column_title_rot = 90,
#'   width = 2,
#'   height = 1
#' )
DynamicHeatmap <- function(
  object,
  lineages,
  features = NULL,
  use_fitted = FALSE,
  border = TRUE,
  heatmap_border = NULL,
  cell_annotation_border = NULL,
  feature_annotation_border = NULL,
  heatmap_border_palcolor = "black",
  cell_annotation_border_palcolor = "black",
  feature_annotation_border_palcolor = "black",
  heatmap_border_size = 1,
  cell_annotation_border_size = 1,
  feature_annotation_border_size = 1,
  flip = FALSE,
  min_expcells = 20,
  r.sq = 0.2,
  dev.expl = 0.2,
  padjust = 0.05,
  num_intersections = NULL,
  cell_density = 1,
  cell_bins = 100,
  order_by = c("peaktime", "valleytime"),
  layer = "counts",
  assay = NULL,
  exp_method = c("zscore", "raw", "fc", "log2fc", "log1p"),
  exp_legend_title = NULL,
  limits = NULL,
  lib_normalize = identical(layer, "counts"),
  libsize = NULL,
  family = NULL,
  suffix = lineages,
  n_candidates = 1000,
  minfreq = 5,
  fit_method = c("gam", "pretsa"),
  knot = 0,
  max_knot_allowed = 10,
  padjust_method = "fdr",
  cluster_features_by = NULL,
  cluster_rows = FALSE,
  cluster_row_slices = FALSE,
  cluster_columns = FALSE,
  cluster_column_slices = FALSE,
  show_row_names = FALSE,
  show_column_names = FALSE,
  row_names_side = ifelse(flip, "left", "right"),
  column_names_side = ifelse(flip, "bottom", "top"),
  row_names_rot = 0,
  column_names_rot = 90,
  row_title = NULL,
  column_title = NULL,
  row_title_side = "left",
  column_title_side = "top",
  row_title_rot = 0,
  column_title_rot = ifelse(flip, 90, 0),
  feature_split = NULL,
  feature_split_by = NULL,
  n_split = NULL,
  split_order = NULL,
  split_method = c("mfuzz", "kmeans", "kmeans-peaktime", "hclust", "hclust-peaktime"),
  decreasing = FALSE,
  fuzzification = NULL,
  anno_terms = FALSE,
  anno_keys = FALSE,
  anno_features = FALSE,
  terms_width = grid::unit(4, "in"),
  terms_stat_width = grid::unit(1.35, "in"),
  terms_fontsize = 8,
  terms_stat = "none",
  terms_stat_digits = 2,
  terms_stat_label = "value",
  terms_stat_axis = FALSE,
  terms_stat_background_palcolor = NULL,
  terms_stat_border = NULL,
  terms_stat_border_palcolor = NULL,
  terms_stat_border_size = NULL,
  terms_stat_label_palcolor = NULL,
  terms_group_background = FALSE,
  terms_background_palcolor = "grey98",
  terms_background_alpha = 1,
  terms_border = TRUE,
  terms_border_palcolor = "black",
  terms_border_size = 0.8,
  terms_text_palcolor = NULL,
  terms_bar_palcolor = NULL,
  keys_width = grid::unit(2, "in"),
  keys_fontsize = c(6, 10),
  features_width = grid::unit(2, "in"),
  features_fontsize = c(6, 10),
  IDtype = "symbol",
  species = "Homo_sapiens",
  db_update = FALSE,
  db_version = "latest",
  db_combine = FALSE,
  convert_species = FALSE,
  Ensembl_version = NULL,
  mirror = NULL,
  db = "GO_BP",
  TERM2GENE = NULL,
  TERM2NAME = NULL,
  minGSSize = 10,
  maxGSSize = 500,
  GO_simplify = FALSE,
  GO_simplify_cutoff = "p.adjust < 0.05",
  simplify_method = "Wang",
  simplify_similarityCutoff = 0.7,
  pvalueCutoff = NULL,
  padjustCutoff = 0.05,
  topTerm = 5,
  show_termid = FALSE,
  topWord = 20,
  words_excluded = NULL,
  nlabel = 20,
  features_label = NULL,
  label_size = 10,
  label_color = "black",
  pseudotime_label = NULL,
  pseudotime_label_color = "black",
  pseudotime_label_linetype = 2,
  pseudotime_label_linewidth = 3,
  heatmap_palette = "viridis",
  heatmap_palcolor = NULL,
  pseudotime_palette = "cividis",
  pseudotime_palcolor = NULL,
  feature_split_palette = "simspec",
  feature_split_palcolor = NULL,
  cell_annotation = NULL,
  cell_annotation_palette = "Chinese",
  cell_annotation_palcolor = NULL,
  cell_annotation_params = if (flip) {
    list(width = grid::unit(5, "mm"))
  } else {
    list(height = grid::unit(5, "mm"))
  },
  feature_annotation = NULL,
  feature_annotation_palette = "Dark2",
  feature_annotation_palcolor = NULL,
  feature_annotation_params = if (flip) {
    list(height = grid::unit(5, "mm"))
  } else {
    list(width = grid::unit(5, "mm"))
  },
  separate_annotation = NULL,
  separate_annotation_palette = "Chinese",
  separate_annotation_palcolor = NULL,
  separate_annotation_params = if (flip) {
    list(width = grid::unit(10, "mm"))
  } else {
    list(height = grid::unit(10, "mm"))
  },
  reverse_ht = NULL,
  use_raster = NULL,
  raster_device = "png",
  raster_by_magick = TRUE,
  height = NULL,
  width = NULL,
  units = "inch",
  cores = 1,
  verbose = TRUE,
  seed = 11,
  legend.position = "right",
  ht_params = list(),
  ...,
  srt = NULL
) {
  srt <- resolve_deprecated_srt(object, srt, missing(object))
  set.seed(seed)
  heatmap_border <- heatmap_border %||% border
  cell_annotation_border <- cell_annotation_border %||% border
  feature_annotation_border <- feature_annotation_border %||% border
  heatmap_border_color <- heatmap_border_color(
    heatmap_border,
    heatmap_border_palcolor
  )
  cell_annotation_border_color <- heatmap_border_color(
    cell_annotation_border,
    cell_annotation_border_palcolor
  )
  feature_annotation_border_color <- heatmap_border_color(
    feature_annotation_border,
    feature_annotation_border_palcolor
  )
  heatmap_border_size <- heatmap_border_size_value(heatmap_border_size)
  cell_annotation_border_size <- heatmap_border_size_value(cell_annotation_border_size)
  feature_annotation_border_size <- heatmap_border_size_value(feature_annotation_border_size)
  heatmap_border <- heatmap_border_enabled(heatmap_border)
  cell_annotation_border <- heatmap_border_enabled(cell_annotation_border)
  feature_annotation_border <- heatmap_border_enabled(feature_annotation_border)
  if (isTRUE(raster_by_magick)) {
    check_r("magick", verbose = FALSE)
  }

  split_method <- match.arg(split_method)
  order_by <- match.arg(order_by)
  data_nm <- c(
    ifelse(isTRUE(lib_normalize), "normalized", ""), layer
  )
  data_nm <- paste(data_nm[data_nm != ""], collapse = " ")
  if (length(exp_method) == 1 && is.function(exp_method)) {
    exp_name <- paste0(
      as.character(x = formals()$exp_method),
      "(",
      data_nm,
      ")"
    )
  } else {
    exp_method <- match.arg(exp_method)
    exp_name <- paste0(exp_method, "(", data_nm, ")")
  }
  exp_name <- exp_legend_title %||% exp_name

  assay <- assay %||% SeuratObject::DefaultAssay(srt)
  if (any(!lineages %in% colnames(srt@meta.data))) {
    lineages_missing <- lineages[!lineages %in% colnames(srt@meta.data)]
    for (l in lineages_missing) {
      if (paste0("DynamicFeatures_", l) %in% names(srt@tools)) {
        pseudotime <- srt@tools[[paste0("DynamicFeatures_", l)]][["lineages"]]
        srt@meta.data[[l]] <- srt@meta.data[[pseudotime]]
      } else {
        log_message(
          "lineages: ", l, " is not in the meta data of {.cls Seurat}",
          message_type = "error"
        )
      }
    }
  }

  if (is.null(feature_split_by)) {
    feature_split_by <- lineages
  }

  if (any(!feature_split_by %in% lineages)) {
    log_message(
      "'feature_split_by' must be a subset of lineages",
      message_type = "error"
    )
  }
  if (
    !split_method %in%
      c("mfuzz", "kmeans", "kmeans-peaktime", "hclust", "hclust-peaktime")
  ) {
    log_message(
      "'split_method' must be one of 'mfuzz', 'kmeans', 'kmeans-peaktime', 'hclust', 'hclust-peaktime'.",
      message_type = "error"
    )
  }

  if (!is.null(feature_split) && is.null(names(feature_split))) {
    log_message(
      "'feature_split' must be named.",
      message_type = "error"
    )
  }
  if (!is.null(feature_split) && !is.factor(feature_split)) {
    feature_split <- factor(feature_split, levels = unique(feature_split))
  }
  if (is.numeric(pseudotime_label)) {
    if (length(pseudotime_label_color) == 1) {
      pseudotime_label_color <- rep(
        pseudotime_label_color,
        length(pseudotime_label)
      )
    }
    if (length(pseudotime_label_linetype) == 1) {
      pseudotime_label_linetype <- rep(
        pseudotime_label_linetype,
        length(pseudotime_label)
      )
    }
    if (length(pseudotime_label_linewidth) == 1) {
      pseudotime_label_linewidth <- rep(
        pseudotime_label_linewidth,
        length(pseudotime_label)
      )
    }
    npal <- unique(c(
      length(pseudotime_label),
      length(pseudotime_label_color),
      length(pseudotime_label_linetype),
      length(pseudotime_label_linewidth)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "Parameters for the pseudotime_label must be the same length!",
        message_type = "error"
      )
    }
  }

  if (!is.null(cell_annotation)) {
    if (length(cell_annotation_palette) == 1) {
      cell_annotation_palette <- rep(
        cell_annotation_palette,
        length(cell_annotation)
      )
    }
    if (length(cell_annotation_palcolor) == 1) {
      cell_annotation_palcolor <- rep(
        cell_annotation_palcolor,
        length(cell_annotation)
      )
    }
    npal <- unique(c(
      length(cell_annotation_palette),
      length(cell_annotation_palcolor),
      length(cell_annotation)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "cell_annotation_palette and cell_annotation_palcolor must be the same length as cell_annotation",
        message_type = "error"
      )
    }
    if (
      any(
        !cell_annotation %in%
          c(colnames(srt@meta.data), rownames(srt@assays[[assay]]))
      )
    ) {
      log_message(
        "cell_annotation: ",
        paste0(
          cell_annotation[
            !cell_annotation %in%
              c(colnames(srt@meta.data), rownames(srt@assays[[assay]]))
          ],
          collapse = ","
        ),
        " is not in {.cls Seurat}."
      )
    }
  }

  if (!is.null(feature_annotation)) {
    if (length(feature_annotation_palette) == 1) {
      feature_annotation_palette <- rep(
        feature_annotation_palette,
        length(feature_annotation)
      )
    }
    if (length(feature_annotation_palcolor) == 1) {
      feature_annotation_palcolor <- rep(
        feature_annotation_palcolor,
        length(feature_annotation)
      )
    }
    npal <- unique(c(
      length(feature_annotation_palette),
      length(feature_annotation_palcolor),
      length(feature_annotation)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "feature_annotation_palette and feature_annotation_palcolor must be the same length as feature_annotation",
        message_type = "error"
      )
    }
    srt_assay_features <- GetFeaturesData(srt@assays[[assay]])
    if (
      any(!feature_annotation %in% colnames(srt_assay_features))
    ) {
      log_message(
        "feature_annotation: ",
        paste0(
          feature_annotation[
            !feature_annotation %in% colnames(srt_assay_features)
          ],
          collapse = ","
        ),
        " is not in the meta data of the ",
        assay,
        " assay in {.cls Seurat}.",
        message_type = "error"
      )
    }
  }

  if (!is.null(separate_annotation)) {
    if (length(separate_annotation_palette) == 1) {
      separate_annotation_palette <- rep(
        separate_annotation_palette,
        length(separate_annotation)
      )
    }
    if (length(separate_annotation_palcolor) == 1) {
      separate_annotation_palcolor <- rep(
        separate_annotation_palcolor,
        length(separate_annotation)
      )
    }
    npal <- unique(c(
      length(separate_annotation_palette),
      length(separate_annotation_palcolor),
      length(separate_annotation)
    ))
    if (length(npal[npal != 0]) > 1) {
      log_message(
        "separate_annotation_palette and separate_annotation_palcolor must be the same length as separate_annotation",
        message_type = "error"
      )
    }
    if (
      any(
        !unique(unlist(separate_annotation)) %in%
          c(colnames(srt@meta.data), rownames(srt@assays[[assay]]))
      )
    ) {
      log_message(
        "separate_annotation: ",
        paste0(
          unique(unlist(separate_annotation))[
            !unique(unlist(separate_annotation)) %in%
              c(colnames(srt@meta.data), rownames(srt@assays[[assay]]))
          ],
          collapse = ","
        ),
        " is not in {.cls Seurat}.",
        message_type = "error"
      )
    }
  }

  if (length(width) == 1) {
    width <- rep(width, length(lineages))
  }
  if (length(height) == 1) {
    height <- rep(height, length(lineages))
  }
  if (length(width) >= 1) {
    names(width) <- lineages
  }
  if (length(height) >= 1) {
    names(height) <- lineages
  }

  column_split <- NULL
  if (isTRUE(flip)) {
    cluster_rows_raw <- cluster_rows
    cluster_columns_raw <- cluster_columns
    cluster_row_slices_raw <- cluster_row_slices
    cluster_column_slices_raw <- cluster_column_slices
    cluster_rows <- cluster_columns_raw
    cluster_columns <- cluster_rows_raw
    cluster_row_slices <- cluster_column_slices_raw
    cluster_column_slices <- cluster_row_slices_raw
  }

  cell_union <- dynamic_heatmap_cell_union(
    cells = colnames(srt@assays[[1]]),
    metadata = srt@meta.data,
    lineages = lineages
  )
  Pseudotime_assign <- Matrix::rowMeans(
    srt@meta.data[cell_union, lineages, drop = FALSE],
    na.rm = TRUE
  )
  cell_metadata <- cbind.data.frame(
    data.frame(row.names = cell_union, cells = cell_union),
    Pseudotime_assign = Pseudotime_assign,
    srt@meta.data[cell_union, lineages, drop = FALSE]
  )
  if (cell_density != 1) {
    bins <- cut(
      Pseudotime_assign,
      breaks = seq(
        min(Pseudotime_assign, na.rm = TRUE),
        max(Pseudotime_assign, na.rm = TRUE),
        length.out = cell_bins
      ),
      include.lowest = TRUE
    )
    ncells <- ceiling(max(table(bins), na.rm = TRUE) * cell_density)
    log_message("ncell/bin=", ncells, "(", cell_bins, "bins)")
    cell_keep <- unlist(sapply(levels(bins), function(x) {
      cells <- names(Pseudotime_assign)[bins == x]
      out <- sample(cells, size = min(length(cells), ncells))
      return(out)
    }))
    cell_metadata <- cell_metadata[cell_keep, , drop = FALSE]
  }
  cell_order_list <- list()
  for (l in lineages) {
    if (
      !is.null(reverse_ht) && (l %in% lineages[reverse_ht] || l %in% reverse_ht)
    ) {
      cell_metadata_sub <- stats::na.omit(cell_metadata[, l, drop = FALSE])
      cell_metadata_sub <- cell_metadata_sub[
        order(cell_metadata_sub[[l]], decreasing = TRUE), ,
        drop = FALSE
      ]
    } else {
      cell_metadata_sub <- stats::na.omit(cell_metadata[, l, drop = FALSE])
      cell_metadata_sub <- cell_metadata_sub[
        order(cell_metadata_sub[[l]], decreasing = FALSE), ,
        drop = FALSE
      ]
    }
    cell_order_list[[l]] <- paste0(rownames(cell_metadata_sub), l)
  }

  if (!is.null(cell_annotation)) {
    cell_annotation_meta <- intersect(cell_annotation, colnames(srt@meta.data))
    cell_annotation_feature <- setdiff(
      intersect(cell_annotation, rownames(srt@assays[[assay]])),
      cell_annotation_meta
    )
    cell_metadata <- cbind.data.frame(
      cell_metadata,
      cbind.data.frame(
        srt@meta.data[
          rownames(cell_metadata),
          cell_annotation_meta,
          drop = FALSE
        ],
        Matrix::t(
          if (length(cell_annotation_feature) > 0) {
            GetAssayData5(
              srt,
              assay = assay,
              layer = "data",
              features = cell_annotation_feature,
              cells = rownames(cell_metadata)
            )[
              cell_annotation_feature,
              rownames(cell_metadata),
              drop = FALSE
            ]
          } else {
            matrix(0, nrow = 0, ncol = nrow(cell_metadata), dimnames = list(character(0), rownames(cell_metadata)))
          }
        )
      )
    )
  }

  dynamic <- list()
  if (is.null(features)) {
    for (l in lineages) {
      DynamicFeatures <- srt@tools[[paste0("DynamicFeatures_", l)]][[
        "DynamicFeatures"
      ]]
      if (is.null(DynamicFeatures)) {
        log_message(
          "DynamicFeatures result for ",
          l,
          " found in the srt object. Should perform RunDynamicFeatures first!",
          message_type = "error"
        )
      }
      DynamicFeatures <- DynamicFeatures[
        DynamicFeatures$exp_ncells > min_expcells &
          DynamicFeatures$r.sq > r.sq &
          DynamicFeatures$dev.expl > dev.expl &
          DynamicFeatures$padjust < padjust, ,
        drop = FALSE
      ]
      dynamic[[l]] <- DynamicFeatures
      features <- c(features, DynamicFeatures[["features"]])
    }
    log_message(
      length(unique(features)),
      " features from ",
      paste0(lineages, collapse = ","),
      " passed the threshold (exp_ncells>",
      min_expcells,
      " & r.sq>",
      r.sq,
      " & dev.expl>",
      dev.expl,
      " & padjust<",
      padjust,
      "): \n",
      paste0(utils::head(features, 10), collapse = ","),
      "..."
    )
  } else {
    for (l in lineages) {
      DynamicFeatures <- srt@tools[[paste0("DynamicFeatures_", l)]][[
        "DynamicFeatures"
      ]]
      if (is.null(DynamicFeatures)) {
        srt <- RunDynamicFeatures(
          srt,
          lineages = l,
          features = features,
          suffix = suffix,
          n_candidates = n_candidates,
          minfreq = minfreq,
          family = family,
          layer = layer,
          assay = assay,
          libsize = libsize,
          fit_method = fit_method,
          knot = knot,
          max_knot_allowed = max_knot_allowed,
          padjust_method = padjust_method,
          cores = cores,
          verbose = verbose,
          seed = seed
        )
        DynamicFeatures <- srt@tools[[paste0("DynamicFeatures_", l)]][[
          "DynamicFeatures"
        ]]
      }
      if (any(!features %in% rownames(DynamicFeatures))) {
        srt <- RunDynamicFeatures(
          srt,
          lineages = l,
          features = features[!features %in% rownames(DynamicFeatures)],
          suffix = suffix,
          n_candidates = n_candidates,
          minfreq = minfreq,
          family = family,
          layer = layer,
          assay = assay,
          libsize = libsize,
          fit_method = fit_method,
          knot = knot,
          max_knot_allowed = max_knot_allowed,
          padjust_method = padjust_method,
          cores = cores,
          verbose = verbose,
          seed = seed
        )
        DynamicFeatures <- rbind(
          DynamicFeatures,
          srt@tools[[paste0("DynamicFeatures_", l)]][["DynamicFeatures"]]
        )
      }
      DynamicFeatures <- DynamicFeatures[features, , drop = FALSE]
      dynamic[[l]] <- DynamicFeatures
    }
  }

  all_calculated <- Reduce(
    intersect,
    lapply(
      lineages,
      function(l) {
        rownames(
          srt@tools[[paste0("DynamicFeatures_", l)]][["DynamicFeatures"]]
        )
      }
    )
  )

  features_tab <- table(features)
  features <- names(features_tab)[which(
    features_tab %in% (num_intersections %||% seq_along(lineages))
  )]
  if (!all(features %in% all_calculated)) {
    log_message(
      "Some features were missing in at least one lineage: \n",
      paste0(utils::head(features[!features %in% all_calculated], 10), collapse = ","),
      "..."
    )
    features <- intersect(features, all_calculated)
  }

  gene <- features[features %in% rownames(srt@assays[[assay]])]
  meta <- features[features %in% colnames(srt@meta.data)]
  if (length(gene) == 0 && length(meta) == 0) {
    log_message(
      "No dynamic features found in the meta.data or in the assay: ", assay,
      message_type = "error"
    )
  }
  feature_metadata <- data.frame(
    row.names = features,
    features = features
  )
  for (l in lineages) {
    feature_metadata[rownames(dynamic[[l]]), paste0(l, order_by)] <- dynamic[[
      l
    ]][, order_by]
    feature_metadata[
      rownames(dynamic[[l]]),
      paste0(l, "exp_ncells")
    ] <- dynamic[[l]][, "exp_ncells"]
    feature_metadata[rownames(dynamic[[l]]), paste0(l, "r.sq")] <- dynamic[[
      l
    ]][, "r.sq"]
    feature_metadata[rownames(dynamic[[l]]), paste0(l, "dev.expl")] <- dynamic[[
      l
    ]][, "dev.expl"]
    feature_metadata[rownames(dynamic[[l]]), paste0(l, "padjust")] <- dynamic[[
      l
    ]][, "padjust"]
  }
  feature_metadata[, order_by] <- apply(
    feature_metadata[, paste0(lineages, order_by), drop = FALSE],
    1,
    max,
    na.rm = TRUE
  )
  feature_metadata <- feature_metadata[
    order(feature_metadata[, order_by], decreasing = decreasing), ,
    drop = FALSE
  ]
  feature_metadata <- feature_metadata[
    rownames(feature_metadata) %in% features, ,
    drop = FALSE
  ]
  features <- rownames(feature_metadata)
  if (!flip && show_row_names && !is.null(features)) {
    row_name_gp <- ht_params$row_names_gp %||% grid::gpar(fontsize = 10)
    fontsize <- row_name_gp$fontsize %||% 10
    max_nchar_val <- max(nchar(features), na.rm = TRUE)
    row_name_width_inch <- max_nchar_val * fontsize * 0.6 / 72
  } else {
    row_name_width_inch <- 0
  }
  if (!is.null(feature_annotation)) {
    feature_metadata <- cbind.data.frame(
      feature_metadata,
      GetFeaturesData(srt, assay = assay)[
        rownames(feature_metadata),
        feature_annotation,
        drop = FALSE
      ]
    )
  }

  if (isTRUE(use_fitted)) {
    mat_list <- list()
    for (l in lineages) {
      fitted_matrix <- srt@tools[[paste0("DynamicFeatures_", l)]][[
        "fitted_matrix"
      ]][, -1]
      rownames(fitted_matrix) <- paste0(rownames(fitted_matrix), l)
      mat_list[[l]] <- Matrix::t(fitted_matrix[, features])
    }
    mat_raw <- do.call(cbind, mat_list)
  } else {
    mat_list <- list()
    count_col <- paste0("nCount_", assay)
    y_libsize <- if (count_col %in% colnames(srt@meta.data)) {
      stats::setNames(srt@meta.data[[count_col]], rownames(srt@meta.data))
    } else {
      Matrix::colSums(
        GetAssayData5(
          srt,
          assay = assay,
          layer = "counts"
        )
      )
    }

    gene_mat_all <- if (length(gene) > 0) {
      GetAssayData5(
        srt,
        assay = assay,
        layer = layer,
        features = gene
      )
    } else {
      matrix(0, nrow = 0, ncol = ncol(srt), dimnames = list(character(0), colnames(srt)))
    }

    for (l in lineages) {
      cells <- dynamic_heatmap_lineage_cells(
        cell_order_list[[l]],
        l,
        available = colnames(srt)
      )
      mat_tmp <- as_matrix(
        rbind(
          gene_mat_all[gene, cells, drop = FALSE],
          Matrix::t(
            srt@meta.data[cells, meta, drop = FALSE]
          )
        )
      )[features, , drop = FALSE]
      if (isTRUE(lib_normalize) && min(mat_tmp, na.rm = TRUE) >= 0) {
        if (!is.null(libsize)) {
          libsize_use <- libsize
        } else {
          libsize_use <- y_libsize[colnames(mat_tmp)]
          isfloat <- any(libsize_use %% 1 != 0, na.rm = TRUE)
          if (isTRUE(isfloat)) {
            libsize_use <- rep(1, length(libsize_use))
            log_message(
              "The values in the 'counts' layer are non-integer. Set the library size to 1.",
              message_type = "warning"
            )
          }
        }
        mat_tmp[gene, ] <- Matrix::t(
          Matrix::t(
            mat_tmp[gene, , drop = FALSE]
          ) /
            libsize_use *
            stats::median(y_libsize)
        )
      }
      colnames(mat_tmp) <- paste0(colnames(mat_tmp), l)
      mat_list[[l]] <- mat_tmp
    }
    mat_raw <- do.call(cbind, mat_list)
  }

  mat <- matrix_process(mat_raw, method = exp_method)
  mat[is.infinite(mat)] <- max(abs(mat[!is.infinite(mat)]), na.rm = TRUE) *
    ifelse(mat[is.infinite(mat)] > 0, 1, -1)
  mat[is.na(mat)] <- mean(mat, na.rm = TRUE)

  mat_split <- mat[, unlist(cell_order_list[feature_split_by]), drop = FALSE]

  if (is.null(limits)) {
    if (!is.function(exp_method) && exp_method %in% c("zscore", "log2fc")) {
      b <- ceiling(
        min(abs(stats::quantile(mat, c(0.01, 0.99), na.rm = TRUE)), na.rm = TRUE) * 2
      ) /
        2
      colors <- circlize::colorRamp2(
        seq(-b, b, length = 100),
        palette_colors(
          palette = heatmap_palette,
          palcolor = heatmap_palcolor
        )
      )
    } else {
      b <- stats::quantile(mat, c(0.01, 0.99), na.rm = TRUE)
      colors <- circlize::colorRamp2(
        seq(b[1], b[2], length = 100),
        palette_colors(
          palette = heatmap_palette,
          palcolor = heatmap_palcolor
        )
      )
    }
  } else {
    colors <- circlize::colorRamp2(
      seq(limits[1], limits[2], length = 100),
      palette_colors(
        palette = heatmap_palette,
        palcolor = heatmap_palcolor
      )
    )
  }

  lgd <- list()
  lgd[["ht"]] <- ComplexHeatmap::Legend(
    title = exp_name,
    col_fun = colors,
    legend_gp = heatmap_border_gp(
      heatmap_border,
      heatmap_border_color,
      heatmap_border_size
    ),
    border = heatmap_legend_border(
      heatmap_border,
      heatmap_border_color
    )
  )

  ha_top_list <- list()
  pseudotime <- stats::na.omit(unlist(cell_metadata[, lineages]))
  pseudotime_col <- circlize::colorRamp2(
    breaks = seq(
      min(pseudotime, na.rm = TRUE),
      max(pseudotime, na.rm = TRUE),
      length = 100
    ),
    colors = palette_colors(
      palette = pseudotime_palette,
      palcolor = pseudotime_palcolor
    )
  )

  for (l in lineages) {
    ha_top_list[[l]] <- ComplexHeatmap::HeatmapAnnotation(
      Pseudotime = ComplexHeatmap::anno_simple(
        x = cell_metadata[
          dynamic_heatmap_lineage_cells(
            cell_order_list[[l]],
            l,
            available = rownames(cell_metadata)
          ),
          l
        ],
        col = pseudotime_col,
        which = ifelse(flip, "row", "column"),
        na_col = "transparent",
        border = FALSE
      ),
      which = ifelse(flip, "row", "column"),
      show_annotation_name = l == lineages[1],
      annotation_name_side = ifelse(flip, "top", "left"),
      border = FALSE
    )
  }

  lgd[["pseudotime"]] <- ComplexHeatmap::Legend(
    title = "Pseudotime",
    col_fun = pseudotime_col,
    legend_gp = heatmap_border_gp(
      cell_annotation_border,
      cell_annotation_border_color,
      cell_annotation_border_size
    ),
    border = heatmap_legend_border(
      cell_annotation_border,
      cell_annotation_border_color
    )
  )

  if (!is.null(cell_annotation)) {
    for (i in seq_along(cell_annotation)) {
      cellan <- cell_annotation[i]
      palette <- cell_annotation_palette[i]
      palcolor <- cell_annotation_palcolor[[i]]
      cell_anno <- cell_metadata[[cellan]]
      names(cell_anno) <- rownames(cell_metadata)
      if (!is.numeric(cell_anno) || cellan == "RNA_snn_res.0.8") {
        if (is.logical(cell_anno)) {
          cell_anno <- factor(cell_anno, levels = c(TRUE, FALSE))
        } else if (!is.factor(cell_anno)) {
          cell_anno <- factor(
            as.character(cell_anno),
            levels = unique(as.character(cell_anno[!is.na(cell_anno)]))
          )
        }
        cell_anno_cols <- palette_colors(
          levels(cell_anno),
          palette = palette,
          palcolor = palcolor
        )
        for (l in lineages) {
          lineage_cells <- dynamic_heatmap_lineage_cells(
            cell_order_list[[l]],
            l,
            available = names(cell_anno)
          )
          lineage_idx <- match(lineage_cells, rownames(cell_metadata))
          cell_anno_lineage <- unname(as.character(cell_anno[lineage_idx]))
          ha_cell <- list()
          ha_cell[[cellan]] <- ComplexHeatmap::anno_simple(
            x = cell_anno_lineage,
            col = cell_anno_cols,
            which = ifelse(flip, "row", "column"),
            na_col = "transparent",
            border = FALSE
          )
          anno_args <- c(
            ha_cell,
            list(
              which = ifelse(flip, "row", "column"),
              show_legend = FALSE,
              show_annotation_name = l == lineages[1],
              annotation_name_side = ifelse(flip, "top", "left"),
              border = FALSE
            )
          )
          anno_args <- c(
            anno_args,
            cell_annotation_params[setdiff(
              names(cell_annotation_params),
              names(anno_args)
            )]
          )
          ha_top <- do.call(ComplexHeatmap::HeatmapAnnotation, args = anno_args)
          if (is.null(ha_top_list[[l]])) {
            ha_top_list[[l]] <- ha_top
          } else {
            ha_top_list[[l]] <- c(ha_top_list[[l]], ha_top)
          }
        }
        lgd[[cellan]] <- ComplexHeatmap::Legend(
          title = cellan,
          labels = levels(cell_anno),
          legend_gp = grid::gpar(
            fill = cell_anno_cols,
            col = cell_annotation_border_color,
            lwd = cell_annotation_border_size
          ),
          border = heatmap_legend_border(
            cell_annotation_border,
            cell_annotation_border_color
          )
        )
      } else {
        col_fun <- circlize::colorRamp2(
          breaks = seq(
            min(cell_anno, na.rm = TRUE),
            max(cell_anno, na.rm = TRUE),
            length = 100
          ),
          colors = palette_colors(palette = palette, palcolor = palcolor)
        )
        for (l in lineages) {
          lineage_cells <- dynamic_heatmap_lineage_cells(
            cell_order_list[[l]],
            l,
            available = names(cell_anno)
          )
          lineage_idx <- match(lineage_cells, rownames(cell_metadata))
          ha_cell <- list()
          ha_cell[[cellan]] <- ComplexHeatmap::anno_simple(
            x = unname(cell_anno[lineage_idx]),
            col = col_fun,
            which = ifelse(flip, "row", "column"),
            na_col = "transparent",
            border = FALSE
          )
          anno_args <- c(
            ha_cell,
            which = ifelse(flip, "row", "column"),
            show_annotation_name = l == lineages[1],
            annotation_name_side = ifelse(flip, "top", "left"),
            border = FALSE
          )
          anno_args <- c(
            anno_args,
            cell_annotation_params[setdiff(
              names(cell_annotation_params),
              names(anno_args)
            )]
          )
          ha_top <- do.call(ComplexHeatmap::HeatmapAnnotation, args = anno_args)
          if (is.null(ha_top_list[[l]])) {
            ha_top_list[[l]] <- ha_top
          } else {
            ha_top_list[[l]] <- c(ha_top_list[[l]], ha_top)
          }
        }
        lgd[[cellan]] <- ComplexHeatmap::Legend(
          title = cellan,
          col_fun = col_fun,
          legend_gp = heatmap_border_gp(
            cell_annotation_border,
            cell_annotation_border_color,
            cell_annotation_border_size
          ),
          border = heatmap_legend_border(
            cell_annotation_border,
            cell_annotation_border_color
          )
        )
      }
    }
  }

  if (!is.null(separate_annotation)) {
    for (i in seq_along(separate_annotation)) {
      cellan <- separate_annotation[[i]]
      palette <- separate_annotation_palette[i]
      palcolor <- separate_annotation_palcolor[[i]]
      is_metadata_annotation <- length(cellan) == 1 &&
        cellan %in% colnames(srt@meta.data)
      if (isTRUE(is_metadata_annotation)) {
        cell_anno <- srt@meta.data[[cellan]]
      } else {
        cell_anno <- numeric()
      }
      if (
        isTRUE(is_metadata_annotation) &&
          (!is.numeric(cell_anno) || cellan == "RNA_snn_res.0.8")
      ) {
        if (is.logical(cell_anno)) {
          cell_anno <- factor(cell_anno, levels = c(TRUE, FALSE))
        } else if (!is.factor(cell_anno)) {
          cell_anno <- factor(
            as.character(cell_anno),
            levels = unique(as.character(cell_anno[!is.na(cell_anno)]))
          )
        }
        srt_anno <- srt
        srt_anno@meta.data[[cellan]] <- cell_anno
        for (l in lineages) {
          lineage_cells <- dynamic_heatmap_lineage_cells(
            cell_order_list[[l]],
            l,
            available = colnames(srt)
          )
          subplots <- CellDensityPlot(
            object = srt_anno,
            cells = lineage_cells,
            group.by = cellan,
            features = l,
            decreasing = TRUE,
            x_order = "rank",
            palette = palette,
            palcolor = palcolor,
            flip = flip,
            reverse = l %in% lineages[reverse_ht] || l %in% reverse_ht
          ) +
            theme_void()
          nm <- paste0(cellan, ":", l)
          block_graphics <- thisplot::annotation_block_graphics(
            subplot = subplots,
            name = nm,
            border = cell_annotation_border,
            border_color = cell_annotation_border_color,
            border_size = cell_annotation_border_size
          )

          ha_cell <- list()
          ha_cell[[paste0(cellan, "\n(separate)")]] <- ComplexHeatmap::anno_block(
            panel_fun = block_graphics,
            which = ifelse(flip, "row", "column"),
            show_name = l == lineages[1]
          )
          anno_args <- c(
            ha_cell,
            which = ifelse(flip, "row", "column"),
            show_annotation_name = l == lineages[1],
            annotation_name_side = ifelse(flip, "top", "left")
          )
          anno_args <- c(
            anno_args,
            separate_annotation_params[setdiff(
              names(separate_annotation_params),
              names(anno_args)
            )]
          )
          ha_top <- do.call(ComplexHeatmap::HeatmapAnnotation, args = anno_args)
          if (is.null(ha_top_list[[l]])) {
            ha_top_list[[l]] <- ha_top
          } else {
            ha_top_list[[l]] <- c(ha_top_list[[l]], ha_top)
          }
        }
        lgd[[paste0("separate:", cellan)]] <- ComplexHeatmap::Legend(
          title = paste0(cellan, "\n(separate)"),
          labels = levels(cell_anno),
          legend_gp = grid::gpar(
            fill = palette_colors(
              cell_anno,
              palette = palette,
              palcolor = palcolor
            ),
            col = cell_annotation_border_color,
            lwd = cell_annotation_border_size
          ),
          border = heatmap_legend_border(
            cell_annotation_border,
            cell_annotation_border_color
          )
        )
      } else {
        for (l in lineages) {
          lineage_cells <- dynamic_heatmap_lineage_cells(
            cell_order_list[[l]],
            l,
            available = colnames(srt)
          )
          subplots <- DynamicPlot(
            object = srt,
            cells = lineage_cells,
            lineages = l,
            group.by = NULL,
            features = cellan,
            line_palette = palette,
            line_palcolor = palcolor,
            add_rug = FALSE,
            legend.position = "none",
            compare_features = TRUE,
            x_order = "rank",
            flip = flip,
            reverse = l %in% lineages[reverse_ht] || l %in% reverse_ht
          ) +
            theme_void()
          nm <- paste0(paste0(cellan, collapse = ","), ":", l)
          block_graphics <- thisplot::annotation_block_graphics(
            subplot = subplots,
            name = nm,
            border = cell_annotation_border,
            border_color = cell_annotation_border_color,
            border_size = cell_annotation_border_size
          )

          ha_cell <- list()
          ha_cell[[paste0(
            paste0(cellan, collapse = ","),
            "\n(separate)"
          )]] <- ComplexHeatmap::anno_block(
            panel_fun = block_graphics,
            which = ifelse(flip, "row", "column"),
            show_name = l == lineages[1]
          )
          anno_args <- c(
            ha_cell,
            which = ifelse(flip, "row", "column"),
            show_annotation_name = l == lineages[1],
            annotation_name_side = ifelse(flip, "top", "left")
          )
          anno_args <- c(
            anno_args,
            separate_annotation_params[setdiff(
              names(separate_annotation_params),
              names(anno_args)
            )]
          )
          ha_top <- do.call(ComplexHeatmap::HeatmapAnnotation, args = anno_args)
          if (is.null(ha_top_list[[l]])) {
            ha_top_list[[l]] <- ha_top
          } else {
            ha_top_list[[l]] <- c(ha_top_list[[l]], ha_top)
          }
        }
        lgd[[paste0("separate:", paste0(cellan, collapse = ","))]] <- ComplexHeatmap::Legend(
          title = "Features\n(separate)",
          labels = cellan,
          legend_gp = grid::gpar(
            fill = palette_colors(cellan, palette = palette, palcolor = palcolor),
            col = cell_annotation_border_color,
            lwd = cell_annotation_border_size
          ),
          border = heatmap_legend_border(
            cell_annotation_border,
            cell_annotation_border_color
          )
        )
      }
    }
  }

  if (is.null(feature_split)) {
    if (is.null(n_split) || isTRUE(nrow(mat) <= n_split)) {
      row_split_raw <- row_split <- feature_split <- NULL
    } else {
      if (n_split == 1) {
        row_split_raw <- row_split <- feature_split <- stats::setNames(
          rep(1, nrow(mat_split)),
          rownames(mat_split)
        )
      } else {
        if (split_method == "mfuzz") {
          check_r("e1071", verbose = FALSE)
          mat_split_tmp <- mat_split
          colnames(mat_split_tmp) <- make.unique(colnames(mat_split_tmp))
          mat_split_tmp <- standardise(mat_split_tmp)
          min_fuzzification <- mestimate(mat_split_tmp)
          if (is.null(fuzzification)) {
            fuzzification <- min_fuzzification + 0.1
          } else {
            if (fuzzification <= min_fuzzification) {
              log_message(
                "fuzzification value is samller than estimated:",
                round(min_fuzzification, 2),
                message_type = "warning"
              )
            }
          }
          cl <- e1071::cmeans(
            mat_split_tmp,
            centers = n_split,
            method = "cmeans",
            m = fuzzification
          )
          if (length(cl$cluster) == 0) {
            log_message(
              "Clustering with mfuzz failed (fuzzification=",
              round(fuzzification, 2),
              "). Please set a larger fuzzification parameter manually.",
              message_type = "error"
            )
          }
          row_split <- feature_split <- cl$cluster
        }
        if (split_method == "kmeans") {
          km <- stats::kmeans(
            mat_split,
            centers = n_split,
            iter.max = 1e4,
            nstart = 20
          )
          row_split <- feature_split <- km$cluster
        }
        if (split_method == "kmeans-peaktime") {
          feature_y <- feature_metadata[rownames(mat_split), order_by]
          names(feature_y) <- rownames(mat_split)
          km <- stats::kmeans(
            feature_y,
            centers = n_split,
            iter.max = 1e4,
            nstart = 20
          )
          row_split <- feature_split <- km$cluster
        }
        if (split_method == "hclust") {
          hc <- stats::hclust(
            stats::as.dist(
              proxyC::dist(mat_split)
            )
          )
          row_split <- feature_split <- stats::cutree(hc, k = n_split)
        }
        if (split_method == "hclust-peaktime") {
          feature_y <- feature_metadata[rownames(mat_split), order_by]
          names(feature_y) <- rownames(mat_split)
          hc <- stats::hclust(
            stats::as.dist(
              proxyC::dist(feature_y)
            )
          )
          row_split <- feature_split <- stats::cutree(hc, k = n_split)
        }
      }
      df <- data.frame(
        row_split = row_split,
        order_by = feature_metadata[names(row_split), order_by]
      )
      df_order <- stats::aggregate(df, by = list(row_split), FUN = mean)
      df_order <- df_order[
        order(df_order[["order_by"]], decreasing = decreasing), ,
        drop = FALSE
      ]
      if (!is.null(split_order)) {
        df_order <- df_order[split_order, , drop = FALSE]
      }
      split_levels <- c()
      for (i in seq_len(nrow(df_order))) {
        raw_nm <- df_order[i, "row_split"]
        feature_split[feature_split == raw_nm] <- paste0("C", i)
        level <- paste0("C", i, "(", sum(row_split == raw_nm), ")")
        row_split[row_split == raw_nm] <- level
        split_levels <- c(split_levels, level)
      }
      row_split_raw <- row_split <- factor(row_split, levels = split_levels)
      feature_split <- factor(
        feature_split,
        levels = paste0("C", seq_len(nrow(df_order)))
      )
    }
  } else {
    row_split_raw <- row_split <- feature_split <- feature_split[row.names(mat)]
  }
  if (!is.null(feature_split)) {
    feature_metadata[["feature_split"]] <- feature_split
  } else {
    feature_metadata[["feature_split"]] <- NA
  }

  ha_left <- NULL
  if (!is.null(row_split)) {
    if (isTRUE(cluster_row_slices)) {
      if (isFALSE(cluster_rows)) {
        dend <- ComplexHeatmap::cluster_within_group(
          Matrix::t(mat_split),
          row_split_raw
        )
        cluster_rows <- dend
        row_split <- length(unique(row_split_raw))
      }
    }
    block_graphics <- thisplot::annotation_block_fill_graphics(
      levels = levels(row_split_raw),
      palette = feature_split_palette,
      palcolor = unlist(feature_split_palcolor),
      border = feature_annotation_border,
      border_color = feature_annotation_border_color,
      border_size = feature_annotation_border_size
    )
    ha_clusters <- ComplexHeatmap::HeatmapAnnotation(
      features_split = ComplexHeatmap::anno_block(
        align_to = split(seq_along(row_split_raw), row_split_raw),
        panel_fun = block_graphics,
        width = grid::unit(0.1, "in"),
        height = grid::unit(0.1, "in"),
        show_name = FALSE,
        which = ifelse(flip, "column", "row")
      ),
      which = ifelse(flip, "column", "row"),
      border = feature_annotation_border,
      gp = heatmap_border_gp(
        feature_annotation_border,
        feature_annotation_border_color,
        feature_annotation_border_size
      )
    )
    if (is.null(ha_left)) {
      ha_left <- ha_clusters
    } else {
      ha_left <- c(ha_left, ha_clusters)
    }
    lgd[["Cluster"]] <- ComplexHeatmap::Legend(
      title = "Cluster",
      labels = intersect(levels(row_split_raw), row_split_raw),
      legend_gp = grid::gpar(
        fill = palette_colors(
          intersect(levels(row_split_raw), row_split_raw),
          type = "discrete",
          palette = feature_split_palette,
          palcolor = feature_split_palcolor,
          matched = TRUE
        ),
        col = feature_annotation_border_color,
        lwd = feature_annotation_border_size
      ),
      border = heatmap_legend_border(
        feature_annotation_border,
        feature_annotation_border_color
      )
    )
  }

  if (isTRUE(cluster_rows) && !is.null(cluster_features_by)) {
    mat_cluster <- mat[,
      unlist(cell_order_list[cluster_features_by]),
      drop = FALSE
    ]
    if (is.null(row_split)) {
      dend <- stats::as.dendrogram(
        stats::hclust(
          stats::as.dist(
            proxyC::dist(mat_cluster)
          )
        )
      )
      dend_ordered <- stats::reorder(
        dend,
        wts = colMeans(mat_cluster),
        agglo.FUN = mean
      )
      cluster_rows <- dend_ordered
    } else {
      row_split <- length(unique(row_split_raw))
      dend <- cluster_within_group2(
        Matrix::t(mat_cluster),
        row_split_raw
      )
      cluster_rows <- dend
    }
  }

  need_feature_order <- !is.null(features_label) || nlabel > 0
  if (isTRUE(need_feature_order)) {
    l <- lineages[1]
    ht_args <- list(
      matrix = mat[, cell_order_list[[l]], drop = FALSE],
      col = colors,
      row_split = row_split,
      cluster_rows = cluster_rows,
      cluster_row_slices = cluster_row_slices,
      column_split = column_split,
      cluster_columns = cluster_columns,
      cluster_column_slices = cluster_column_slices,
      use_raster = TRUE
    )
    ht_args <- c(ht_args, ht_params[setdiff(names(ht_params), names(ht_args))])
    ht_list <- do.call(ComplexHeatmap::Heatmap, args = ht_args)
    features_ordered <- rownames(mat)[unlist(
      suppressWarnings(
        ComplexHeatmap::row_order(
          ht_list
        )
      )
    )]
  } else {
    features_ordered <- rownames(mat)
  }
  feature_metadata[["index"]] <- stats::setNames(
    object = seq_along(features_ordered),
    nm = features_ordered
  )[rownames(feature_metadata)]

  if (is.null(features_label)) {
    if (nlabel > 0) {
      if (length(features) > nlabel) {
        index_from <- ceiling((length(features_ordered) / nlabel) / 2)
        index_to <- length(features_ordered)
        index <- unique(
          round(
            seq(
              from = index_from,
              to = index_to,
              length.out = nlabel
            )
          )
        )
      } else {
        index <- seq_along(features_ordered)
      }
    } else {
      index <- NULL
    }
  } else {
    index <- which(features_ordered %in% features_label)
    drop <- setdiff(features_label, features_ordered)
    if (length(drop) > 0) {
      log_message(
        paste0(paste0(drop, collapse = ","), "was not found in the features"),
        message_type = "warning"
      )
    }
  }
  if (length(index) > 0) {
    ha_mark <- ComplexHeatmap::HeatmapAnnotation(
      gene = ComplexHeatmap::anno_mark(
        at = which(rownames(feature_metadata) %in% features_ordered[index]),
        labels = feature_metadata[
          which(rownames(feature_metadata) %in% features_ordered[index]),
          "features"
        ],
        side = ifelse(flip, "top", "left"),
        labels_gp = grid::gpar(fontsize = label_size, col = label_color),
        link_gp = grid::gpar(fontsize = label_size, col = label_color),
        which = ifelse(flip, "column", "row")
      ),
      which = ifelse(flip, "column", "row"),
      show_annotation_name = FALSE
    )
    if (is.null(ha_left)) {
      ha_left <- ha_mark
    } else {
      ha_left <- c(ha_mark, ha_left)
    }
  }

  ha_right <- NULL
  if (length(lineages) > 1) {
    ha_list <- list()
    for (l in lineages) {
      ha_list[[l]] <- ComplexHeatmap::anno_simple(
        x = is.na(feature_metadata[, paste0(l, order_by)]) + 0,
        col = c("0" = "#181830", "1" = "transparent"),
        width = grid::unit(5, "mm"),
        height = grid::unit(5, "mm"),
        which = ifelse(flip, "column", "row")
      )
    }
    ha_lineage <- do.call(
      ComplexHeatmap::HeatmapAnnotation,
      args = c(
        ha_list,
        which = ifelse(flip, "column", "row"),
        annotation_name_side = ifelse(flip, "left", "top"),
        border = feature_annotation_border
      )
    )
    if (is.null(ha_right)) {
      ha_right <- ha_lineage
    } else {
      ha_right <- c(ha_right, ha_lineage)
    }
  }
  if (!is.null(feature_annotation)) {
    for (i in seq_along(feature_annotation)) {
      featan <- feature_annotation[i]
      palette <- feature_annotation_palette[i]
      palcolor <- feature_annotation_palcolor[[i]]
      feature <- build_heatmap_feature_annotation(
        annotation_name = featan,
        values = feature_metadata[, featan],
        palette = palette,
        palcolor = palcolor,
        flip = flip,
        border = feature_annotation_border,
        annotation_border = FALSE,
        border_color = feature_annotation_border_color,
        border_size = feature_annotation_border_size,
        discrete_legend_border = heatmap_legend_border(
          feature_annotation_border,
          feature_annotation_border_color
        ),
        discrete_legend_gp_border = TRUE,
        params = feature_annotation_params
      )
      ha_right <- if (is.null(ha_right)) {
        feature$annotation
      } else {
        c(ha_right, feature$annotation)
      }
      lgd[[featan]] <- feature$legend
    }
  }

  enrichment <- heatmap_enrichment(
    geneID = feature_metadata[["features"]],
    geneID_groups = feature_metadata[["feature_split"]],
    feature_split_palette = feature_split_palette,
    feature_split_palcolor = feature_split_palcolor,
    ha_right = ha_right,
    flip = flip,
    anno_terms = anno_terms,
    anno_keys = anno_keys,
    anno_features = anno_features,
    terms_width = terms_width,
    terms_stat_width = terms_stat_width,
    terms_fontsize = terms_fontsize,
    terms_stat = terms_stat,
    terms_stat_digits = terms_stat_digits,
    terms_stat_label = terms_stat_label,
    terms_stat_axis = terms_stat_axis,
    terms_stat_background_palcolor = terms_stat_background_palcolor,
    terms_stat_border = terms_stat_border,
    terms_stat_border_palcolor = terms_stat_border_palcolor,
    terms_stat_border_size = terms_stat_border_size,
    terms_stat_label_palcolor = terms_stat_label_palcolor,
    terms_group_background = terms_group_background,
    terms_background_palcolor = terms_background_palcolor,
    terms_background_alpha = terms_background_alpha,
    terms_border = terms_border,
    terms_border_palcolor = terms_border_palcolor,
    terms_border_size = terms_border_size,
    terms_text_palcolor = terms_text_palcolor,
    terms_bar_palcolor = terms_bar_palcolor,
    keys_width = keys_width,
    keys_fontsize = keys_fontsize,
    features_width = features_width,
    features_fontsize = features_fontsize,
    IDtype = IDtype,
    species = species,
    db_update = db_update,
    db_version = db_version,
    db_combine = db_combine,
    convert_species = convert_species,
    Ensembl_version = Ensembl_version,
    mirror = mirror,
    db = db,
    TERM2GENE = TERM2GENE,
    TERM2NAME = TERM2NAME,
    minGSSize = minGSSize,
    maxGSSize = maxGSSize,
    GO_simplify = GO_simplify,
    GO_simplify_cutoff = GO_simplify_cutoff,
    simplify_method = simplify_method,
    simplify_similarityCutoff = simplify_similarityCutoff,
    pvalueCutoff = pvalueCutoff,
    padjustCutoff = padjustCutoff,
    topTerm = topTerm,
    show_termid = show_termid,
    topWord = topWord,
    words_excluded = words_excluded,
    ...
  )
  res <- enrichment$res
  ha_right <- enrichment$ha_right
  lgd <- c(lgd, enrichment$lgd)

  ht_list <- NULL
  for (l in lineages) {
    if (l == lineages[1]) {
      left_annotation <- ha_left
    } else {
      left_annotation <- NULL
    }
    if (l == lineages[length(lineages)]) {
      right_annotation <- ha_right
    } else {
      right_annotation <- NULL
    }
    ht_args <- list(
      name = l,
      matrix = if (flip) {
        Matrix::t(mat[, cell_order_list[[l]], drop = FALSE])
      } else {
        mat[, cell_order_list[[l]], drop = FALSE]
      },
      col = colors,
      row_title = row_title %||% if (flip) l else character(0),
      row_title_side = row_title_side,
      column_title = column_title %||% if (flip) character(0) else l,
      column_title_side = if (flip) "top" else column_title_side,
      row_title_rot = row_title_rot,
      column_title_rot = column_title_rot,
      row_split = if (flip) column_split else row_split,
      column_split = if (flip) row_split else column_split,
      cluster_rows = if (flip) cluster_columns else cluster_rows,
      cluster_columns = if (flip) cluster_rows else cluster_columns,
      cluster_row_slices = if (flip) {
        cluster_column_slices
      } else {
        cluster_row_slices
      },
      cluster_column_slices = if (flip) {
        cluster_row_slices
      } else {
        cluster_column_slices
      },
      show_row_names = show_row_names,
      show_column_names = show_column_names,
      row_names_side = row_names_side,
      column_names_side = column_names_side,
      row_names_rot = row_names_rot,
      column_names_rot = column_names_rot,
      top_annotation = if (flip) left_annotation else ha_top_list[[l]],
      left_annotation = if (flip) ha_top_list[[l]] else left_annotation,
      bottom_annotation = if (flip) right_annotation else NULL,
      right_annotation = if (flip) NULL else right_annotation,
      show_heatmap_legend = FALSE,
      border = heatmap_border,
      border_gp = heatmap_border_gp(heatmap_border, heatmap_border_color, heatmap_border_size),
      use_raster = use_raster,
      raster_device = raster_device,
      raster_by_magick = raster_by_magick,
      width = if (is.numeric(width[l])) grid::unit(width[l], units = units) else NULL,
      height = if (is.numeric(height[l])) {
        grid::unit(height[l], units = units)
      } else {
        NULL
      }
    )
    if (any(names(ht_params) %in% names(ht_args))) {
      log_message(
        "ht_params: ",
        paste0(intersect(names(ht_params), names(ht_args)), collapse = ","),
        " were duplicated and will not be used.",
        message_type = "warning"
      )
    }
    ht_args <- c(ht_args, ht_params[setdiff(names(ht_params), names(ht_args))])
    if (isTRUE(flip)) {
      if (is.null(ht_list)) {
        ht_list <- do.call(ComplexHeatmap::Heatmap, args = ht_args)
      } else {
        ht_list <- ht_list %v% do.call(ComplexHeatmap::Heatmap, args = ht_args)
      }
    } else {
      ht_list <- ht_list + do.call(ComplexHeatmap::Heatmap, args = ht_args)
    }
  }

  if (
    (!is.null(row_split) && length(index) > 0) ||
      any(c(anno_terms, anno_keys, anno_features)) ||
      !is.null(width) ||
      !is.null(height)
  ) {
    fix <- TRUE
    if (is.null(width) || is.null(height)) {
      log_message(
        "\nThe size of the heatmap is fixed because certain elements are not scalable.\nThe width and height of the heatmap are determined by the size of the current viewport.\nIf you want to have more control over the size, you can manually set the parameters 'width' and 'height'.\n"
      )
    }
  } else {
    fix <- FALSE
  }
  rendersize <- heatmap_rendersize(
    width = width,
    height = height,
    units = units,
    ha_top_list = ha_top_list,
    ha_left = ha_left,
    ha_right = ha_right,
    ht_list = ht_list,
    legend_list = lgd,
    flip = flip
  )
  width_sum <- rendersize[["width_sum"]]
  height_sum <- rendersize[["height_sum"]]
  pseudotime_slices <- 1L
  if (!is.null(row_split)) {
    pseudotime_slices <- if (length(row_split) == 1L && is.numeric(row_split)) {
      seq_len(max(as.integer(row_split), 1L))
    } else {
      seq_len(max(length(unique(row_split[!is.na(row_split)])), 1L))
    }
  }

  if (isTRUE(fix)) {
    fixsize_env <- new.env(parent = emptyenv())
    invisible(grid::grid.grabExpr({
      fixsize_env[["value"]] <- heatmap_fixsize(
        width = width,
        width_sum = width_sum,
        height = height,
        height_sum = height_sum,
        units = units,
        ht_list = ht_list,
        legend_list = lgd
      )
    }))
    fixsize <- fixsize_env[["value"]]
    rm(fixsize_env)
    ht_width <- fixsize[["ht_width"]]
    ht_height <- fixsize[["ht_height"]]

    g_tree <- grid::grid.grabExpr(
      {
        ComplexHeatmap::draw(ht_list,
          annotation_legend_list = lgd,
          annotation_legend_side = legend.position
        )
        dynamic_heatmap_decorate_borders(
          cell_annotation_names = c("Pseudotime", cell_annotation),
          cell_annotation_border = cell_annotation_border,
          cell_annotation_border_color = cell_annotation_border_color,
          cell_annotation_border_size = cell_annotation_border_size,
          feature_annotation_names = c(
            "features_split",
            if (length(lineages) > 1) lineages else NULL,
            feature_annotation
          ),
          feature_annotation_border = feature_annotation_border,
          feature_annotation_border_color = feature_annotation_border_color,
          feature_annotation_border_size = feature_annotation_border_size
        )
        for (enrich in db) {
          enrich_anno <- names(ha_right)[grep(
            paste0("_split_", enrich),
            names(ha_right)
          )]
          if (length(enrich_anno) > 0) {
            for (enrich_anno_element in enrich_anno) {
              enrich_obj <- strsplit(enrich_anno_element, "_split_")[[1]][1]
              ComplexHeatmap::decorate_annotation(
                enrich_anno_element,
                slice = 1,
                {
                  grid::grid.text(
                    paste0(enrich, " (", enrich_obj, ")"),
                    x = grid::unit(1, "npc"),
                    y = grid::unit(1, "npc") + grid::unit(2.5, "mm"),
                    just = c("left", "bottom")
                  )
                }
              )
            }
          }
        }
        if (is.numeric(pseudotime_label)) {
          for (n in seq_along(pseudotime_label)) {
            pse <- pseudotime_label[n]
            col <- pseudotime_label_color[n]
            lty <- pseudotime_label_linetype[n]
            lwd <- pseudotime_label_linewidth[n]
            for (l in lineages) {
              for (slice in pseudotime_slices) {
                ComplexHeatmap::decorate_heatmap_body(
                  l,
                  {
                    pseudotime <- cell_metadata[
                      dynamic_heatmap_lineage_cells(
                        cell_order_list[[l]],
                        l,
                        available = rownames(cell_metadata)
                      ),
                      l
                    ]
                    i <- which.min(abs(pseudotime - pse))
                    if (flip) {
                      x <- 1 - (i / length(pseudotime))
                      grid::grid.lines(
                        c(0, 1),
                        c(x, x),
                        gp = grid::gpar(lty = lty, lwd = lwd, col = col)
                      )
                    } else {
                      i <- which.min(abs(pseudotime - pse))
                      x <- i / length(pseudotime)
                      grid::grid.lines(
                        c(x, x),
                        c(0, 1),
                        gp = grid::gpar(lty = lty, lwd = lwd, col = col)
                      )
                    }
                  },
                  row_slice = ifelse(flip, 1, slice),
                  column_slice = ifelse(flip, slice, 1)
                )
              }
            }
          }
        }
      },
      width = ht_width,
      height = ht_height,
      wrap = TRUE,
      wrap.grobs = TRUE
    )
  } else {
    ht_width <- grid::unit(width_sum, units = units)
    ht_height <- grid::unit(height_sum, units = units)
    g_tree <- grid::grid.grabExpr(
      {
        ComplexHeatmap::draw(ht_list,
          annotation_legend_list = lgd,
          annotation_legend_side = legend.position
        )
        dynamic_heatmap_decorate_borders(
          cell_annotation_names = c("Pseudotime", cell_annotation),
          cell_annotation_border = cell_annotation_border,
          cell_annotation_border_color = cell_annotation_border_color,
          cell_annotation_border_size = cell_annotation_border_size,
          feature_annotation_names = c(
            "features_split",
            if (length(lineages) > 1) lineages else NULL,
            feature_annotation
          ),
          feature_annotation_border = feature_annotation_border,
          feature_annotation_border_color = feature_annotation_border_color,
          feature_annotation_border_size = feature_annotation_border_size
        )
        for (enrich in db) {
          enrich_anno <- names(ha_right)[grep(
            paste0("_split_", enrich),
            names(ha_right)
          )]
          if (length(enrich_anno) > 0) {
            for (enrich_anno_element in enrich_anno) {
              enrich_obj <- strsplit(enrich_anno_element, "_split_")[[1]][1]
              ComplexHeatmap::decorate_annotation(
                enrich_anno_element,
                slice = 1,
                {
                  grid::grid.text(
                    paste0(enrich, " (", enrich_obj, ")"),
                    x = grid::unit(1, "npc"),
                    y = grid::unit(1, "npc") + grid::unit(2.5, "mm"),
                    just = c("left", "bottom")
                  )
                }
              )
            }
          }
        }
        if (is.numeric(pseudotime_label)) {
          for (n in seq_along(pseudotime_label)) {
            pse <- pseudotime_label[n]
            col <- pseudotime_label_color[n]
            lty <- pseudotime_label_linetype[n]
            lwd <- pseudotime_label_linewidth[n]
            for (l in lineages) {
              for (slice in pseudotime_slices) {
                ComplexHeatmap::decorate_heatmap_body(
                  l,
                  {
                    pseudotime <- cell_metadata[
                      dynamic_heatmap_lineage_cells(
                        cell_order_list[[l]],
                        l,
                        available = rownames(cell_metadata)
                      ),
                      l
                    ]
                    i <- which.min(abs(pseudotime - pse))
                    if (flip) {
                      x <- 1 - (i / length(pseudotime))
                      grid::grid.lines(
                        c(0, 1),
                        c(x, x),
                        gp = grid::gpar(lty = lty, lwd = lwd, col = col)
                      )
                    } else {
                      i <- which.min(abs(pseudotime - pse))
                      x <- i / length(pseudotime)
                      grid::grid.lines(
                        c(x, x),
                        c(0, 1),
                        gp = grid::gpar(lty = lty, lwd = lwd, col = col)
                      )
                    }
                  },
                  row_slice = ifelse(flip, 1, slice),
                  column_slice = ifelse(flip, slice, 1)
                )
              }
            }
          }
        }
      },
      width = ht_width,
      height = ht_height,
      wrap = TRUE,
      wrap.grobs = TRUE
    )
  }

  if (isTRUE(fix)) {
    p <- panel_fix_overall(
      g_tree,
      width = as.numeric(ht_width),
      height = as.numeric(ht_height),
      units = units
    )
  } else {
    p <- patchwork::wrap_plots(g_tree)
  }

  return(
    list(
      plot = p,
      matrix = mat,
      cell_order = cell_order_list,
      feature_split = feature_split,
      cell_metadata = cell_metadata,
      feature_metadata = feature_metadata,
      enrichment = res
    )
  )
}

dynamic_heatmap_lineage_cells <- function(x, lineage, available = NULL) {
  out <- dynamic_heatmap_strip_lineage_suffix(x, lineage)
  if (!is.null(available) && !any(out %in% available)) {
    fallback <- gsub(
      pattern = lineage,
      replacement = "",
      x = x,
      fixed = TRUE
    )
    if (any(fallback %in% available)) {
      out <- fallback
    }
  }
  out
}

dynamic_heatmap_cell_union <- function(cells, metadata, lineages) {
  lineage_values <- metadata[, lineages, drop = FALSE]
  unique(cells[rowSums(!is.na(lineage_values)) > 0L])
}

dynamic_heatmap_strip_lineage_suffix <- function(x, lineage) {
  suffix_width <- nchar(lineage, type = "chars")
  has_suffix <- substr(x, nchar(x, type = "chars") - suffix_width + 1L, nchar(x, type = "chars")) == lineage
  out <- x
  out[has_suffix] <- substr(
    x[has_suffix],
    1L,
    nchar(x[has_suffix], type = "chars") - suffix_width
  )
  out
}

dynamic_heatmap_decorate_borders <- function(
  cell_annotation_names,
  cell_annotation_border,
  cell_annotation_border_color,
  cell_annotation_border_size,
  feature_annotation_names,
  feature_annotation_border,
  feature_annotation_border_color,
  feature_annotation_border_size
) {
  draw_annotation_border <- function(annotation, border, color, size) {
    if (!isTRUE(border) || is.na(annotation) || !nzchar(annotation)) {
      return(invisible(NULL))
    }
    try(
      ComplexHeatmap::decorate_annotation(annotation, slice = 1, {
        grid::grid.rect(
          gp = grid::gpar(fill = "transparent", col = color, lwd = size)
        )
      }),
      silent = TRUE
    )
    invisible(NULL)
  }
  for (annotation in unique(as.character(cell_annotation_names))) {
    draw_annotation_border(
      annotation,
      cell_annotation_border,
      cell_annotation_border_color,
      cell_annotation_border_size
    )
  }
  for (annotation in unique(as.character(feature_annotation_names))) {
    draw_annotation_border(
      annotation,
      feature_annotation_border,
      feature_annotation_border_color,
      feature_annotation_border_size
    )
  }
  invisible(NULL)
}
